                              1 	.title	Test of Z280 assembler
                              2 	.module	tz280x.asm
                              3 
                              4 	; To test asz280 with .con and .lst defined:
                              5     	; Constants / Internal symbols mode.
                              6 	; Verifies assembler output.
                              7 	;
                              8 	;	asz280 -lbcoxff -p tz280x_CL asz280_CL tz280x 
                              9 	;	asxscn tz280x_CL.lst
                             10 	;
                             11 	;
                             12 	; To test asz280 with .con and .rst defined:
                             13     	; Constants / Internal symbols mode.
                             14 	; Verifies linked code.
                             15 	;
                             16 	;	asz280 -lbcoxff -p tz280x_CR asz280_CR tz280x 
                             17 	;	aslink -nf tz280x_CR
                             18 	;	asxscn tz280x_CR.rst
                             19 	;
                             20 	;
                             21 	; To test asz280 with .ext and .lst defined:
                             22     	; Constants with External symbols mode.
                             23 	; Verifies assembler output.
                             24 	;
                             25 	;	asz280 -lbcoxff -p tz280x_XL asz280_XL tz280x 
                             26 	;	asxscn tz280x_XL.lst
                             27 	;
                             28 	;
                             29 	; To test asz280 with .ext and .rst defined:
                             30     	; Constants with External symbols mode.
                             31 	; Verifies linked code.
                             32 	;
                             33 	;	asz280 -lbcoxff -p tz280x_XR asz280_XR tz280x 
                             34 	;	aslink -nf tz280x_XR
                             35 	;	asxscn tz280x_XR.rst
                             36 	;
                             37 	; To test asz280 with .ext and .lst defined:
                             38 	; Full external symbol mode. (.EXLR defined)
                             39 	; Verifies assembler output.
                             40 	;
                             41 	;	asz280 -lbcoxff -p tz280x_EXL asz280_EXL tz280x 
                             42 	;	asxscn tz280x_EXL.lst
                             43 	;
                             44 	;
                             45 	; To test asz280 with .ext and .rst defined:
                             46 	; Full external symbol mode. (.EXLR defined)
                             47 	; Verifies linked code.
                             48 	;
                             49 	;	asz280 -lbcoxff -p tz280x_EXR asz280_EXR tz280x 
                             50 	;	aslink -nf tz280x_EXR
                             51 	;	asxscn tz280x_EXR.rst
                             52 	;
                             53 
                     0009    85 	CXLR = CXLR	; .con / .ext / .lst / .rst
                             86 
                             90 	; Assembled with .con option.
                            105 	; Assembled with .rst option.
                            114     	; Constants + External Symbols Mode. (.EXLR not defined)
                            118 
                     0000   119 	C_LR = 0x08 - (CXLR & 0x08)	; = 0  if .con with either .lst/.rst
                     0004   120 	_XLR = 0x04 - (CXLR & 0x04)	; = 0  if .ext with either .lst/.rst
                     0002   121 	CXL_ = 0x02 - (CXLR & 0x02)	; = 0  if .lst with either .con/.ext
                     0000   122 	CX_R = 0x01 - (CXLR & 0x01)	; = 0  if .rst with either .con/.ext
                     0001   123 	C_L_ = 0x0A - CXLR		; = 0  if .con and .lst
                     0000   124 	C__R = 0x09 - CXLR		; = 0  if .con and .rst
                     FFFD   125 	_XL_ = 0x06 - CXLR		; = 0  if .ext and .lst
                     FFFC   126 	_X_R = 0x05 - CXLR		; = 0  if .ext and .rst
                            127 
                            131 
                            132 ;*******************************************************************	
                            133 ;*******************************************************************
                            134 
                     0055   135 	offset	=	0x55		;arbitrary constants
                     0020   136 	n	=	0x20
                     0584   137 	nn	=	0x0584
                            138 
                     0055   139 	sxoff	=	0x55		; SX offset (-128..127)
                     1122   140 	lxoff	=	0x1122		;  X offset
                     1234   141 	raoff	=	0x1234		; RA address/offset
                     3344   142 	daddr	=	0x3344		; DA address
                            143 
                     0055   144 	offsetc	==	offset		;arbitrary constants
                     0020   145 	nc	==	n
                     0584   146 	nnc	==	nn
                            147 
                     0055   148 	sxofc	==	sxoff		; SX offset (-128..127)
                     1122   149 	lxofc	==	lxoff		;  X offset
                     1234   150 	raofc	==	raoff		; RA address/offset
                     3344   151 	daddc	==	daddr		; DA address
                            152 
                            248 
                            249 	.macro	.pcr_ofst A,B
                            250           .nval	_dot_, .
                            251 	  .ifb B
                            252  	    pcr_ofst = A + _dot_ + 4
                            253 	  .else
                            254  	    pcr_ofst = A + _dot_ + B
                            255 	  .endif
                            256 	.endm
                            257 
                            258 
                     0000   259 ODDBALL_SHIFT_ROTATE	=	0	; prefer this set to 0
                            260 
                            261 	.area	_code
                            262 	
                            263 	.z80
   0000 83                  264 	.byte	.__.CPU.	; 83
                            265 	.z80u
   0001 87                  266 	.byte	.__.CPU.	; 87
                            267 	.z180
   0002 8B                  268 	.byte	.__.CPU.	; 8B
                            269 	.hd64
   0003 8B                  270 	.byte	.__.CPU.	; 8B
                            271 	.z280
   0004 33                  272 	.byte	.__.CPU.	; 33
                            273 	.z280n
   0005 11                  274 	.byte	.__.CPU.	; 11
                            275 	.z280p
   0006 F3                  276 	.byte	.__.CPU.	; F3
                            277 
                     0000   278 	. = . - 7
                            279 
                            280 ;*******************************************************************	
                            281 ;*******************************************************************
                            282 ;	Start test of addressing syntax	
                            283 ;*******************************************************************	
                            284 ;*******************************************************************	
                            285 	;***********************************************************
                            286 	; add with carry
                            287 	.z280
   0000 8E                  288 	adc	a,(hl)			;8E
   0001 DD 89               289 	adc	a,(hl+ix)		;DD 89
   0003 DD 8A               290 	adc	a,(hl+iy)		;DD 8A
   0005 FD 8B 22 11         310 	adc	a,(hl+lxoff)		;FD 8B 22 11
   0009 FD 8B 55 00         311 	adc	a,(hl+sxoff)		;FD 8B 55 00
   000D FD 8B 22 11         312 	adc	a,lxoff(hl)		;FD 8B 22 11
   0011 FD 8B 55 00         313 	adc	a,sxoff(hl)		;FD 8B 55 00
   0015 DD 8B               317 	adc	a,(ix+iy)		;DD 8B
   0017 DD 8E 00            318 	adc	a,(ix)			;DD 8E 00
   001A FD 89 22 11         356 	adc	a,(ix+lxoff)		;FD 89 22 11
   001E FD 89 22 11         357 	adc	a,lxoff(ix)		;FD 89 22 11
   0022 FD 89 DE EE         358 	adc	a,(ix-lxoff)		;FD 89 DE EE
   0026 FD 89 DE EE         359 	adc	a,-lxoff(ix)		;FD 89 DE EE
   002A DD 8E 55            402 	adc	a,(ix+sxoff)		;DD 8E 55
   002D DD 8E 55            403 	adc	a,sxoff(ix)		;DD 8E 55
   0030 DD 8E AB            404 	adc	a,(ix-sxoff)		;DD 8E AB
   0033 DD 8E AB            405 	adc	a,-sxoff(ix)		;DD 8E AB
   0036 FD 8E 00            409 	adc	a,(iy)			;FD 8E 00
   0039 FD 8A 22 11         447 	adc	a,(iy+lxoff)		;FD 8A 22 11
   003D FD 8A 22 11         448 	adc	a,lxoff(iy)		;FD 8A 22 11
   0041 FD 8A DE EE         449 	adc	a,(iy-lxoff)		;FD 8A DE EE
   0045 FD 8A DE EE         450 	adc	a,-lxoff(iy)		;FD 8A DE EE
   0049 FD 8E 55            491 	adc	a,(iy+sxoff)		;FD 8E 55
   004C FD 8E 55            492 	adc	a,sxoff(iy)		;FD 8E 55
   004F FD 8E AB            493 	adc	a,(iy-sxoff)		;FD 8E AB
   0052 FD 8E AB            494 	adc	a,-sxoff(iy)		;FD 8E AB
   0055 FD 88 22 11         671 	adc	a,pcr_ofst(pc)		;FD 88 22 11
   0059 FD 88 22 11         675 	adc	a,(pc+pcr_ofst)		;FD 88 22 11
   005D FD 88 22 11         679 	adc	a,[pcr_ofst]		;FD 88 22 11
   0061 FD 88 55 00         683 	adc	a,pcr_ofst(pc)		;FD 88 55 00
   0065 FD 88 55 00         687 	adc	a,(pc+pcr_ofst)		;FD 88 55 00
   0069 FD 88 55 00         691 	adc	a,[pcr_ofst]		;FD 88 55 00
   006D FD 88 34 12         695 	adc	a,pcr_ofst(pc)		;FD 88 34 12
   0071 FD 88 34 12         699 	adc	a,(pc+pcr_ofst)		;FD 88 34 12
   0075 FD 88 34 12         703 	adc	a,[pcr_ofst]		;FD 88 34 12
   0079 FD 88 FC FF         707 	adc	a,[.]			;FD 88 FC FF
   007D DD 88 22 11         725 	adc	a,(sp+lxoff)		;DD 88 22 11
   0081 DD 88 22 11         726 	adc	a,lxoff(sp)		;DD 88 22 11
   0085 DD 8F 44 33         727 	adc	a,(daddr)		;DD 8F 44 33
   0089 88                  731 	adc	a,b			;88
   008A 89                  732 	adc	a,c			;89
   008B 8A                  733 	adc	a,d			;8A
   008C 8B                  734 	adc	a,e			;8B
   008D 8C                  735 	adc	a,h			;8C
   008E 8D                  736 	adc	a,l			;8D
   008F 8E                  737 	adc	a,(hl)			;8E
   0090 8F                  738 	adc	a,a			;8F
   0091 DD 8C               739 	adc	a,ixh			;DD 8C
   0093 DD 8D               740 	adc	a,ixl			;DD 8D
   0095 FD 8C               741 	adc	a,iyh			;FD 8C
   0097 FD 8D               742 	adc	a,iyl			;FD 8D
   0099 CE 20               760 	adc	a,#n			;CE 20
   009B CE 20               761 	adc	a, n			;CE 20
   009D CE 22               762 	adc	a,lxoff			;CE 22
   009F ED 4A               766 	adc	hl,bc			;ED 4A
   00A1 ED 5A               767 	adc	hl,de			;ED 5A
   00A3 ED 6A               768 	adc	hl,hl			;ED 6A
   00A5 ED 7A               769 	adc	hl,sp			;ED 7A
   00A7 DD ED 4A            770 	adc	ix,bc			;DD ED 4A
   00AA DD ED 5A            771 	adc	ix,de			;DD ED 5A
   00AD DD ED 6A            772 	adc	ix,ix			;DD ED 6A
   00B0 DD ED 7A            773 	adc	ix,sp			;DD ED 7A
   00B3 FD ED 4A            774 	adc	iy,bc			;FD ED 4A
   00B6 FD ED 5A            775 	adc	iy,de			;FD ED 5A
   00B9 FD ED 6A            776 	adc	iy,iy			;FD ED 6A
   00BC FD ED 7A            777 	adc	iy,sp			;FD ED 7A
                            778 	
                            779 	
                            780 ;*******************************************************************
                            781 ;*******************************************************************
                            782 ;	End test of addressing syntax	
                            783 ;*******************************************************************
                            784 ;*******************************************************************
                            785 ;*******************************************************************
                            786 
                            787 
                            788 ;*******************************************************************
                            789 ;	ADC	
                            790 ;		Leading 'a' operand is optional.
                            791 ;		If offset is ommitted 0 is assumed.
                            792 ;*******************************************************************
                            793 	;***********************************************************
                            794 	; add with carry to 'a'
                            795 	.z80
   00BF 8E                  796 	adc	a,(hl)			;8E
   00C0 DD 8E 55            816 	adc	a,offset(ix)		;DD 8E 55
   00C3 FD 8E 55            817 	adc	a,offset(iy)		;FD 8E 55
   00C6 DD 8E 55            818 	adc	a,(ix+offset)		;DD 8E 55
   00C9 FD 8E 55            819 	adc	a,(iy+offset)		;FD 8E 55
   00CC DD 8E 00            823 	adc	a,(ix)			;DD 8E 00
   00CF FD 8E 00            824 	adc	a,(iy)			;FD 8E 00
   00D2 8F                  825 	adc	a,a			;8F
   00D3 88                  826 	adc	a,b			;88
   00D4 89                  827 	adc	a,c			;89
   00D5 8A                  828 	adc	a,d			;8A
   00D6 8B                  829 	adc	a,e			;8B
   00D7 8C                  830 	adc	a,h			;8C
   00D8 8D                  831 	adc	a,l			;8D
   00D9 CE 20               847 	adc	a,#n			;CE 20
   00DB CE 20               848 	adc	a, n			;CE 20
                            852 	;***********************************************************
   00DD 8E                  853 	adc	(hl)			;8E
   00DE DD 8E 55            873 	adc	offset(ix)		;DD 8E 55
   00E1 FD 8E 55            874 	adc	offset(iy)		;FD 8E 55
   00E4 DD 8E 55            875 	adc	(ix+offset)		;DD 8E 55
   00E7 FD 8E 55            876 	adc	(iy+offset)		;FD 8E 55
   00EA DD 8E 00            880 	adc	(ix)			;DD 8E 00
   00ED FD 8E 00            881 	adc	(iy)			;FD 8E 00
   00F0 8F                  882 	adc	a			;8F
   00F1 88                  883 	adc	b			;88
   00F2 89                  884 	adc	c			;89
   00F3 8A                  885 	adc	d			;8A
   00F4 8B                  886 	adc	e			;8B
   00F5 8C                  887 	adc	h			;8C
   00F6 8D                  888 	adc	l			;8D
   00F7 CE 20               904 	adc	#n			;CE 20
   00F9 CE 20               905 	adc	 n			;CE 20
                            909 	;***********************************************************
                            910 	; add with carry register pair to 'hl'
   00FB ED 4A               911 	adc	hl,bc			;ED 4A
   00FD ED 5A               912 	adc	hl,de			;ED 5A
   00FF ED 6A               913 	adc	hl,hl			;ED 6A
   0101 ED 7A               914 	adc	hl,sp			;ED 7A
                            915 	;***********************************************************
                            916 	; add with carry to accumulator with 'a'
                            917 	.z280
   0103 DD 8F 8A 05         971 	adc	a,(nn+6)		;DD 8F 8A 05
   0107 FD 89 84 05         972 	adc	a,(ix+nn)		;FD 89 84 05
   010B FD 8A 84 05         973 	adc	a,(iy+nn)		;FD 8A 84 05
   010F DD 88 84 05         974 	adc	a,(sp+nn)		;DD 88 84 05
   0113 DD 8E 55            985 	adc	a,sxoff(ix)		;DD 8E 55
   0116 DD 8E 55            986 	adc	a,(ix+sxoff)		;DD 8E 55
   0119 FD 8E 55            987 	adc	a,sxoff(iy)		;FD 8E 55
   011C FD 8E 55            988 	adc	a,(iy+sxoff)		;FD 8E 55
   011F FD 8B 55 00         992 	adc	a,sxoff(hl)		;FD 8B 55 00
   0123 FD 8B 55 00         993 	adc	a,(hl+sxoff)		;FD 8B 55 00
   0127 DD 88 55 00         994 	adc	a,sxoff(sp)		;DD 88 55 00
   012B DD 88 55 00         995 	adc	a,(sp+sxoff)		;DD 88 55 00
   012F FD 89 22 11         996 	adc	a,lxoff(ix)		;FD 89 22 11
   0133 FD 89 22 11         997 	adc	a,(ix+lxoff)		;FD 89 22 11
   0137 FD 8A 22 11         998 	adc	a,lxoff(iy)		;FD 8A 22 11
   013B FD 8A 22 11         999 	adc	a,(iy+lxoff)		;FD 8A 22 11
   013F FD 8B 22 11        1000 	adc	a,lxoff(hl)		;FD 8B 22 11
   0143 FD 8B 22 11        1001 	adc	a,(hl+lxoff)		;FD 8B 22 11
   0147 DD 88 22 11        1002 	adc	a,lxoff(sp)		;DD 88 22 11
   014B DD 88 22 11        1003 	adc	a,(sp+lxoff)		;DD 88 22 11
   014F DD 8E 00           1007 	adc	a,(ix)			;DD 8E 00
   0152 FD 8E 00           1008 	adc	a,(iy)			;FD 8E 00
   0155 8E                 1009 	adc	a,(hl)			;8E
   0156 DD 88 00 00        1010 	adc	a,(sp)			;DD 88 00 00
   015A FD 88 34 12        1082 	adc	a,pcr_ofst(pc)		;FD 88 34 12
   015E FD 88 34 12        1086 	adc	a,(pc+pcr_ofst)		;FD 88 34 12
   0162 FD 88 34 12        1090 	adc	a,[pcr_ofst]		;FD 88 34 12
   0166 FD 88 1C 00        1094 	adc	a,[.+32]		;FD 88 1C 00
   016A DD 89              1095 	adc	a,(hl+ix)		;DD 89
   016C DD 8A              1096 	adc	a,(hl+iy)		;DD 8A
   016E DD 8B              1097 	adc	a,(ix+iy)		;DD 8B
                           1098 	;***********************************************************
                           1099 	; add with carry to accumulator without 'a'
                           1100 	.z280
   0170 DD 8F 8A 05        1156 	adc	(nn+6)			;DD 8F 8A 05
   0174 FD 89 84 05        1157 	adc	(ix+nn)			;FD 89 84 05
   0178 FD 8A 84 05        1158 	adc	(iy+nn)			;FD 8A 84 05
   017C DD 88 84 05        1159 	adc	(sp+nn)			;DD 88 84 05
   0180 DD 8E 55           1170 	adc	sxoff(ix)		;DD 8E 55
   0183 DD 8E 55           1171 	adc	(ix+sxoff)		;DD 8E 55
   0186 FD 8E 55           1172 	adc	sxoff(iy)		;FD 8E 55
   0189 FD 8E 55           1173 	adc	(iy+sxoff)		;FD 8E 55
   018C FD 8B 55 00        1177 	adc	sxoff(hl)		;FD 8B 55 00
   0190 FD 8B 55 00        1178 	adc	(hl+sxoff)		;FD 8B 55 00
   0194 DD 88 55 00        1179 	adc	sxoff(sp)		;DD 88 55 00
   0198 DD 88 55 00        1180 	adc	(sp+sxoff)		;DD 88 55 00
   019C FD 89 22 11        1181 	adc	lxoff(ix)		;FD 89 22 11
   01A0 FD 89 22 11        1182 	adc	(ix+lxoff)		;FD 89 22 11
   01A4 FD 8A 22 11        1183 	adc	lxoff(iy)		;FD 8A 22 11
   01A8 FD 8A 22 11        1184 	adc	(iy+lxoff)		;FD 8A 22 11
   01AC FD 8B 22 11        1185 	adc	lxoff(hl)		;FD 8B 22 11
   01B0 FD 8B 22 11        1186 	adc	(hl+lxoff)		;FD 8B 22 11
   01B4 DD 88 22 11        1187 	adc	lxoff(sp)		;DD 88 22 11
   01B8 DD 88 22 11        1188 	adc	(sp+lxoff)		;DD 88 22 11
   01BC DD 8E 00           1192 	adc	(ix)			;DD 8E 00
   01BF FD 8E 00           1193 	adc	(iy)			;FD 8E 00
   01C2 8E                 1194 	adc	(hl)			;8E
   01C3 DD 88 00 00        1195 	adc	(sp)			;DD 88 00 00
   01C7 FD 88 34 12        1267 	adc	pcr_ofst(pc)		;FD 88 34 12
   01CB FD 88 34 12        1271 	adc	(pc+pcr_ofst)		;FD 88 34 12
   01CF FD 88 34 12        1275 	adc	[pcr_ofst]		;FD 88 34 12
   01D3 FD 88 1C 00        1279 	adc	[.+32]			;FD 88 1C 00
   01D7 DD 89              1280 	adc	(hl+ix)			;DD 89
   01D9 DD 8A              1281 	adc	(hl+iy)			;DD 8A
   01DB DD 8B              1282 	adc	(ix+iy)			;DD 8B
                           1283 	;***********************************************************
                           1284 	; add with carry to register IX, IY
   01DD DD ED 4A           1285 	adc	ix,bc			;DD ED 4A
   01E0 DD ED 5A           1286 	adc	ix,de			;DD ED 5A
   01E3 DD ED 6A           1287 	adc	ix,ix			;DD ED 6A
   01E6 DD ED 7A           1288 	adc	ix,sp			;DD ED 7A
   01E9 FD ED 4A           1289 	adc	iy,bc			;FD ED 4A
   01EC FD ED 5A           1290 	adc	iy,de			;FD ED 5A
   01EF FD ED 6A           1291 	adc	iy,iy			;FD ED 6A
   01F2 FD ED 7A           1292 	adc	iy,sp			;FD ED 7A
                           1293 		
                           1294 ;*******************************************************************
                           1295 ;	ADD	
                           1296 ;		Leading 'a' operand is optional.
                           1297 ;		If offset is ommitted 0 is assumed.
                           1298 ;*******************************************************************
                           1299 	;***********************************************************
                           1300 	; add operand to 'a' with 'a'
                           1301 	.z80
   01F5 86                 1302 	add	a,(hl)			;86
   01F6 DD 86 55           1322 	add	a,offset(ix)		;DD 86 55
   01F9 FD 86 55           1323 	add	a,offset(iy)		;FD 86 55
   01FC DD 86 55           1324 	add	a,(ix+offset)		;DD 86 55
   01FF FD 86 55           1325 	add	a,(iy+offset)		;FD 86 55
   0202 87                 1329 	add	a,a			;87
   0203 80                 1330 	add	a,b			;80
   0204 81                 1331 	add	a,c			;81
   0205 82                 1332 	add	a,d			;82
   0206 83                 1333 	add	a,e			;83
   0207 84                 1334 	add	a,h			;84
   0208 85                 1335 	add	a,l			;85
   0209 C6 20              1351 	add	a,#n			;C6 20
   020B C6 20              1352 	add	a, n			;C6 20
                           1356 	;***********************************************************
                           1357 	; add operand to 'a' without 'a'
   020D 86                 1358 	add	(hl)			;86	
   020E DD 86 55           1378 	add	offset(ix)		;DD 86 55
   0211 FD 86 55           1379 	add	offset(iy)		;FD 86 55
   0214 DD 86 55           1380 	add	(ix+offset)		;DD 86 55
   0217 FD 86 55           1381 	add	(iy+offset)		;FD 86 55
   021A 87                 1385 	add	a			;87
   021B 80                 1386 	add	b			;80
   021C 81                 1387 	add	c			;81
   021D 82                 1388 	add	d			;82
   021E 83                 1389 	add	e			;83
   021F 84                 1390 	add	h			;84
   0220 85                 1391 	add	l			;85
   0221 C6 20              1407 	add	#n			;C6 20
   0223 C6 20              1408 	add	 n			;C6 20
                           1412 	;***********************************************************
                           1413 	; add register pair to 'hl'
   0225 09                 1414 	add	hl,bc			;09
   0226 19                 1415 	add	hl,de			;19
   0227 29                 1416 	add	hl,hl			;29
   0228 39                 1417 	add	hl,sp			;39
                           1418 	;***********************************************************
                           1419 	; add register pair to 'ix'
   0229 DD 09              1420 	add	ix,bc			;DD 09
   022B DD 19              1421 	add	ix,de			;DD 19
   022D DD 29              1422 	add	ix,ix			;DD 29
   022F DD 39              1423 	add	ix,sp			;DD 39
                           1424 	;***********************************************************
                           1425 	; add register pair to 'iy'
   0231 FD 09              1426 	add	iy,bc			;FD 09
   0233 FD 19              1427 	add	iy,de			;FD 19
   0235 FD 29              1428 	add	iy,iy			;FD 29
   0237 FD 39              1429 	add	iy,sp			;FD 39
                           1430 	;***********************************************************
                           1431 	; add operand to 'a' with 'a'
                           1432 	;  p. 5-16
                           1433 	.z280
   0239 DD 84              1434 	add	a,ixh			;DD 84
   023B DD 85              1435 	add	a,ixl			;DD 85
   023D FD 84              1436 	add	a,iyh			;FD 84
   023F FD 85              1437 	add	a,iyl			;FD 85
   0241 DD 87 8A 05        1491 	add	a,(nn+6)		;DD 87 8A 05
   0245 FD 81 84 05        1492 	add	a,(ix+nn)		;FD 81 84 05
   0249 FD 82 84 05        1493 	add	a,(iy+nn)		;FD 82 84 05
   024D FD 83 84 05        1494 	add	a,(hl+nn)		;FD 83 84 05
   0251 DD 80 84 05        1495 	add	a,(sp+nn)		;DD 80 84 05
   0255 DD 86 55           1506 	add	a,sxoff(ix)		;DD 86 55
   0258 DD 86 55           1507 	add	a,(ix+sxoff)		;DD 86 55
   025B FD 86 55           1508 	add	a,sxoff(iy)		;FD 86 55
   025E FD 86 55           1509 	add	a,(iy+sxoff)		;FD 86 55
   0261 FD 83 55 00        1513 	add	a,sxoff(hl)		;FD 83 55 00
   0265 FD 83 55 00        1514 	add	a,(hl+sxoff)		;FD 83 55 00
   0269 DD 80 55 00        1515 	add	a,sxoff(sp)		;DD 80 55 00
   026D DD 80 55 00        1516 	add	a,(sp+sxoff)		;DD 80 55 00
   0271 FD 81 22 11        1517 	add	a,lxoff(ix)		;FD 81 22 11
   0275 FD 81 22 11        1518 	add	a,(ix+lxoff)		;FD 81 22 11
   0279 FD 82 22 11        1519 	add	a,lxoff(iy)		;FD 82 22 11
   027D FD 82 22 11        1520 	add	a,(iy+lxoff)		;FD 82 22 11
   0281 FD 83 22 11        1521 	add	a,lxoff(hl)		;FD 83 22 11
   0285 FD 83 22 11        1522 	add	a,(hl+lxoff)		;FD 83 22 11
   0289 DD 80 22 11        1523 	add	a,lxoff(sp)		;DD 80 22 11
   028D DD 80 22 11        1524 	add	a,(sp+lxoff)		;DD 80 22 11
   0291 DD 86 00           1528 	add	a,(ix)			;DD 86 00
   0294 FD 86 00           1529 	add	a,(iy)			;FD 86 00
   0297 86                 1530 	add	a,(hl)			;86
   0298 DD 80 00 00        1531 	add	a,(sp)			;DD 80 00 00
   029C FD 80 34 12        1603 	add	a,pcr_ofst(pc)		;FD 80 34 12
   02A0 FD 80 34 12        1607 	add	a,(pc+pcr_ofst)		;FD 80 34 12
   02A4 FD 80 34 12        1611 	add	a,[pcr_ofst]		;FD 80 34 12
   02A8 FD 80 30 12        1615 	add	a,[.+raofc]		;FD 80 30 12
   02AC DD 81              1616 	add	a,(hl+ix)		;DD 81
   02AE DD 82              1617 	add	a,(hl+iy)		;DD 82
   02B0 DD 83              1618 	add	a,(ix+iy)		;DD 83
                           1619 	;***********************************************************
                           1620 	; add operand to 'a' without 'a'
                           1621 	.z280
   02B2 DD 84              1622 	add	ixh			;DD 84
   02B4 DD 85              1623 	add	ixl			;DD 85
   02B6 FD 84              1624 	add	iyh			;FD 84
   02B8 FD 85              1625 	add	iyl			;FD 85
   02BA DD 87 8A 05        1679 	add	(nn+6)			;DD 87 8A 05
   02BE FD 81 84 05        1680 	add	(ix+nn)			;FD 81 84 05
   02C2 FD 82 84 05        1681 	add	(iy+nn)			;FD 82 84 05
   02C6 FD 83 84 05        1682 	add	(hl+nn)			;FD 83 84 05
   02CA DD 80 84 05        1683 	add	(sp+nn)			;DD 80 84 05
   02CE DD 86 55           1694 	add	sxoff(ix)		;DD 86 55
   02D1 DD 86 55           1695 	add	(ix+sxoff)		;DD 86 55
   02D4 FD 86 55           1696 	add	sxoff(iy)		;FD 86 55
   02D7 FD 86 55           1697 	add	(iy+sxoff)		;FD 86 55
   02DA FD 83 55 00        1701 	add	sxoff(hl)		;FD 83 55 00
   02DE FD 83 55 00        1702 	add	(hl+sxoff)		;FD 83 55 00
   02E2 DD 80 55 00        1703 	add	sxoff(sp)		;DD 80 55 00
   02E6 DD 80 55 00        1704 	add	(sp+sxoff)		;DD 80 55 00
   02EA FD 81 22 11        1705 	add	lxoff(ix)		;FD 81 22 11
   02EE FD 81 22 11        1706 	add	(ix+lxoff)		;FD 81 22 11
   02F2 FD 82 22 11        1707 	add	lxoff(iy)		;FD 82 22 11
   02F6 FD 82 22 11        1708 	add	(iy+lxoff)		;FD 82 22 11
   02FA FD 83 22 11        1709 	add	lxoff(hl)		;FD 83 22 11
   02FE FD 83 22 11        1710 	add	(hl+lxoff)		;FD 83 22 11
   0302 DD 80 22 11        1711 	add	lxoff(sp)		;DD 80 22 11
   0306 DD 80 22 11        1712 	add	(sp+lxoff)		;DD 80 22 11
   030A DD 86 00           1716 	add	(ix)			;DD 86 00
   030D FD 86 00           1717 	add	(iy)			;FD 86 00
   0310 86                 1718 	add	(hl)			;86
   0311 DD 80 00 00        1719 	add	(sp)			;DD 80 00 00
   0315 FD 80 34 12        1791 	add	pcr_ofst(pc)		;FD 80 34 12
   0319 FD 80 34 12        1795 	add	(pc+pcr_ofst)		;FD 80 34 12
   031D FD 80 34 12        1799 	add	[pcr_ofst]		;FD 80 34 12
   0321 FD 80 30 12        1803 	add	[.+raofc]		;FD 80 30 12
   0325 DD 81              1804 	add	(hl+ix)			;DD 81
   0327 DD 82              1805 	add	(hl+iy)			;DD 82
   0329 DD 83              1806 	add	(ix+iy)			;DD 83
                           1807 	;***********************************************************
   032B ED 6D              1808 	add	hl,a			;ED 6D
   032D DD ED 6D           1809 	add	ix,a			;DD ED 6D
   0330 FD ED 6D           1810 	add	iy,a			;FD ED 6D
                           1811 
                           1812 ;*******************************************************************
                           1813 ;	ADDW	
                           1814 ;*******************************************************************
                           1815 	;***********************************************************
                           1816 	.z280
   0333 FD ED F6 20 00     1850 	addw	hl,#n			;FD ED F6 20 00
   0338 FD ED F6 44 33     1851 	addw	hl,#daddr		;FD ED F6 44 33
   033D DD ED D6 44 33     1852 	addw	hl,(daddr)		;DD ED D6 44 33
   0342 FD ED C6 55 00     1853 	addw	hl,sxoff(ix)		;FD ED C6 55 00
   0347 FD ED C6 55 00     1854 	addw	hl,(ix+sxoff)		;FD ED C6 55 00
   034C FD ED C6 22 11     1855 	addw	hl,lxoff(ix)		;FD ED C6 22 11
   0351 FD ED C6 22 11     1856 	addw	hl,(ix+lxoff)		;FD ED C6 22 11
   0356 FD ED D6 55 00     1857 	addw	hl,sxoff(iy)		;FD ED D6 55 00
   035B FD ED D6 55 00     1858 	addw	hl,(iy+sxoff)		;FD ED D6 55 00
   0360 FD ED D6 22 11     1859 	addw	hl,lxoff(iy)		;FD ED D6 22 11
   0365 FD ED D6 22 11     1860 	addw	hl,(iy+lxoff)		;FD ED D6 22 11
   036A DD ED C6           1864 	addw	hl,(hl)			;DD ED C6
                           1865 	;***********************************************************
                           1866 	; add register pair to 'hl'
   036D 09                 1867 	addw	hl,bc			;09
   036E 19                 1868 	addw	hl,de			;19
   036F 29                 1869 	addw	hl,hl			;29
   0370 39                 1870 	addw	hl,sp			;39
                           1871 	;***********************************************************
   0371 DD ED F6 34 12     1943 	addw	hl,pcr_ofst(pc)		;DD ED F6 34 12
   0376 DD ED F6 34 12     1947 	addw	hl,(pc+pcr_ofst)	;DD ED F6 34 12
   037B DD ED F6 34 12     1951 	addw	hl,[pcr_ofst]		;DD ED F6 34 12
   0380 DD ED F6 1B 00     1955 	addw	hl,[.+nc]		;DD ED F6 1B 00
                           1956 
                           1957 	;***********************************************************
                           1958 	; Equivalent to addw
                           1959 	;  p. 5-18
   0385 FD ED F6 20 00     1993 	add	hl,#n			;FD ED F6 20 00
   038A FD ED F6 44 33     1994 	add	hl,#daddr		;FD ED F6 44 33
   038F DD ED D6 44 33     1995 	add	hl,(daddr)		;DD ED D6 44 33
   0394 FD ED C6 55 00     1996 	add	hl,sxoff(ix)		;FD ED C6 55 00
   0399 FD ED C6 55 00     1997 	add	hl,(ix+sxoff)		;FD ED C6 55 00
   039E FD ED C6 22 11     1998 	add	hl,lxoff(ix)		;FD ED C6 22 11
   03A3 FD ED C6 22 11     1999 	add	hl,(ix+lxoff)		;FD ED C6 22 11
   03A8 FD ED D6 55 00     2000 	add	hl,sxoff(iy)		;FD ED D6 55 00
   03AD FD ED D6 55 00     2001 	add	hl,(iy+sxoff)		;FD ED D6 55 00
   03B2 FD ED D6 22 11     2002 	add	hl,lxoff(iy)		;FD ED D6 22 11
   03B7 FD ED D6 22 11     2003 	add	hl,(iy+lxoff)		;FD ED D6 22 11
                           2007 
                           2008 ;*******************************************************************
                           2009 ;	AND	
                           2010 ;		Leading 'a' operand is optional.
                           2011 ;		If offset is ommitted 0 is assumed.
                           2012 ;*******************************************************************
                           2013 	;***********************************************************
                           2014 	; logical 'and' operand with 'a'
                           2015 	.z80
   03BC A6                 2016 	and	a,(hl)			;A6
   03BD DD A6 55           2036 	and	a,offset(ix)		;DD A6 55
   03C0 FD A6 55           2037 	and	a,offset(iy)		;FD A6 55
   03C3 DD A6 55           2038 	and	a,(ix+offset)		;DD A6 55
   03C6 FD A6 55           2039 	and	a,(iy+offset)		;FD A6 55
   03C9 A7                 2043 	and	a,a			;A7
   03CA A0                 2044 	and	a,b			;A0
   03CB A1                 2045 	and	a,c			;A1
   03CC A2                 2046 	and	a,d			;A2
   03CD A3                 2047 	and	a,e			;A3
   03CE A4                 2048 	and	a,h			;A4
   03CF A5                 2049 	and	a,l			;A5
   03D0 E6 20              2065 	and	a,#n			;E6 20
   03D2 E6 20              2066 	and	a, n			;E6 20
                           2070 	;***********************************************************
                           2071 	; logical 'and' operand without 'a'
                           2072 	.z80
   03D4 A6                 2073 	and	(hl)			;A6
   03D5 DD A6 55           2093 	and	offset(ix)		;DD A6 55
   03D8 FD A6 55           2094 	and	offset(iy)		;FD A6 55
   03DB DD A6 55           2095 	and	(ix+offset)		;DD A6 55
   03DE FD A6 55           2096 	and	(iy+offset)		;FD A6 55
   03E1 A7                 2100 	and	a			;A7
   03E2 A0                 2101 	and	b			;A0
   03E3 A1                 2102 	and	c			;A1
   03E4 A2                 2103 	and	d			;A2
   03E5 A3                 2104 	and	e			;A3
   03E6 A4                 2105 	and	h			;A4
   03E7 A5                 2106 	and	l			;A5
   03E8 E6 20              2122 	and	#n			;E6 20
   03EA E6 20              2123 	and	 n			;E6 20
                           2127 	;***********************************************************
                           2128 	; logical 'and' operand with 'a'
                           2129 	;  p. 5--19
                           2130 	.z280
   03EC DD A4              2131 	and	a,ixh			;DD A4
   03EE DD A5              2132 	and	a,ixl			;DD A5
   03F0 FD A4              2133 	and	a,iyh			;FD A4
   03F2 FD A5              2134 	and	a,iyl			;FD A5
   03F4 DD A7 26 00        2188 	and	a,(n+6)			;DD A7 26 00
   03F8 FD A1 84 05        2189 	and	a,(ix+nn)		;FD A1 84 05
   03FC FD A2 84 05        2190 	and	a,(iy+nn)		;FD A2 84 05
   0400 FD A3 84 05        2191 	and	a,(hl+nn)		;FD A3 84 05
   0404 DD A0 84 05        2192 	and	a,(sp+nn)		;DD A0 84 05
   0408 DD A6 55           2203 	and	a,sxoff(ix)		;DD A6 55
   040B DD A6 55           2204 	and	a,(ix+sxoff)		;DD A6 55
   040E FD A6 55           2205 	and	a,sxoff(iy)		;FD A6 55
   0411 FD A6 55           2206 	and	a,(iy+sxoff)		;FD A6 55
   0414 FD A3 55 00        2210 	and	a,sxoff(hl)		;FD A3 55 00
   0418 FD A3 55 00        2211 	and	a,(hl+sxoff)		;FD A3 55 00
   041C DD A0 55 00        2212 	and	a,sxoff(sp)		;DD A0 55 00
   0420 DD A0 55 00        2213 	and	a,(sp+sxoff)		;DD A0 55 00
   0424 FD A1 22 11        2214 	and	a,lxoff(ix)		;FD A1 22 11
   0428 FD A1 22 11        2215 	and	a,(ix+lxoff)		;FD A1 22 11
   042C FD A2 22 11        2216 	and	a,lxoff(iy)		;FD A2 22 11
   0430 FD A2 22 11        2217 	and	a,(iy+lxoff)		;FD A2 22 11
   0434 FD A3 22 11        2218 	and	a,lxoff(hl)		;FD A3 22 11
   0438 FD A3 22 11        2219 	and	a,(hl+lxoff)		;FD A3 22 11
   043C DD A0 22 11        2220 	and	a,lxoff(sp)		;DD A0 22 11
   0440 DD A0 22 11        2221 	and	a,(sp+lxoff)		;DD A0 22 11
   0444 DD A6 00           2225 	and	a,(ix)			;DD A6 00
   0447 FD A6 00           2226 	and	a,(iy)			;FD A6 00
   044A A6                 2227 	and	a,(hl)			;A6
   044B DD A0 00 00        2228 	and	a,(sp)			;DD A0 00 00
   044F FD A0 34 12        2300 	and	a,pcr_ofst(pc)		;FD A0 34 12
   0453 FD A0 34 12        2304 	and	a,(pc+pcr_ofst)	;FD A0 34 12
   0457 FD A0 34 12        2308 	and	a,[pcr_ofst]		;FD A0 34 12
   045B FD A0 1C 00        2312 	and	a,[.+32]		;FD A0 1C 00
   045F FD A0 30 12        2313 	and	a,(pc+(.+raofc))	;FD A0 30 12
   0463 DD A0 E0 FF        2339 	and	a,-n(sp)		;DD A0 E0 FF
   0467 DD A1              2343 	and	a,(hl+ix)		;DD A1
   0469 DD A2              2344 	and	a,(hl+iy)		;DD A2
   046B DD A3              2345 	and	a,(ix+iy)		;DD A3
                           2346 	;***********************************************************
                           2347 	; logical 'and' operand without 'a'
                           2348 	;  p. 5--19
                           2349 	.z280
   046D DD A4              2350 	and	ixh			;DD A4
   046F DD A5              2351 	and	ixl			;DD A5
   0471 FD A4              2352 	and	iyh			;FD A4
   0473 FD A5              2353 	and	iyl			;FD A5
   0475 DD A7 44 33        2373 	and	(daddr)			;DD A7 44 33
   0479 FD A1 22 11        2374 	and	lxoff(ix)		;FD A1 22 11
   047D FD A2 22 11        2375 	and	(iy+lxoff)		;FD A2 22 11
   0481 FD A3 22 11        2376 	and	lxoff(hl)		;FD A3 22 11
   0485 FD A0 34 12        2451 	and	pcr_ofst(pc)		;FD A0 34 12
   0489 FD A0 34 12        2455 	and	(pc+pcr_ofst)		;FD A0 34 12
   048D FD A0 34 12        2459 	and	[pcr_ofst]		;FD A0 34 12
   0491 FD A0 1C 00        2463 	and	[.+32]			;FD A0 1C 00
   0495 FD A0 30 12        2464 	and	(pc+(.+raofc))		;FD A0 30 12
   0499 DD A0 E0 FF        2490 	and	-n(sp)			;DD A0 E0 FF
   049D DD A1              2494 	and	(hl+ix)			;DD A1
   049F DD A2              2495 	and	(hl+iy)			;DD A2
   04A1 DD A3              2496 	and	(ix+iy)			;DD A3
                           2497 
                           2498 ;*******************************************************************
                           2499 ;	BIT	
                           2500 ;*******************************************************************
                           2501 	;***********************************************************
                           2502 	; test bit of location or register
                           2503 	.z80
   04A3 CB 46              2504 	bit	0,(hl)			;CB 46
   04A5 DD CB 55 46        2524 	bit	0,offset(ix)		;DD CB 55 46
   04A9 FD CB 55 46        2525 	bit	0,offset(iy)		;FD CB 55 46
   04AD DD CB 55 46        2526 	bit	0,(ix+offset)		;DD CB 55 46
   04B1 FD CB 55 46        2527 	bit	0,(iy+offset)		;FD CB 55 46
   04B5 CB 47              2531 	bit	0,a			;CB 47
   04B7 CB 40              2532 	bit	0,b			;CB 40
   04B9 CB 41              2533 	bit	0,c			;CB 41
   04BB CB 42              2534 	bit	0,d			;CB 42
   04BD CB 43              2535 	bit	0,e			;CB 43
   04BF CB 44              2536 	bit	0,h			;CB 44
   04C1 CB 45              2537 	bit	0,l			;CB 45
   04C3 CB 4E              2538 	bit	1,(hl)			;CB 4E
   04C5 DD CB 55 4E        2558 	bit	1,offset(ix)		;DD CB 55 4E
   04C9 FD CB 55 4E        2559 	bit	1,offset(iy)		;FD CB 55 4E
   04CD DD CB 55 4E        2560 	bit	1,(ix+offset)		;DD CB 55 4E
   04D1 FD CB 55 4E        2561 	bit	1,(iy+offset)		;FD CB 55 4E
   04D5 CB 4F              2565 	bit	1,a			;CB 4F
   04D7 CB 48              2566 	bit	1,b			;CB 48
   04D9 CB 49              2567 	bit	1,c			;CB 49
   04DB CB 4A              2568 	bit	1,d			;CB 4A
   04DD CB 4B              2569 	bit	1,e			;CB 4B
   04DF CB 4C              2570 	bit	1,h			;CB 4C
   04E1 CB 4D              2571 	bit	1,l			;CB 4D
   04E3 CB 56              2572 	bit	2,(hl)			;CB 56
   04E5 DD CB 55 56        2592 	bit	2,offset(ix)		;DD CB 55 56
   04E9 FD CB 55 56        2593 	bit	2,offset(iy)		;FD CB 55 56
   04ED DD CB 55 56        2594 	bit	2,(ix+offset)		;DD CB 55 56
   04F1 FD CB 55 56        2595 	bit	2,(iy+offset)		;FD CB 55 56
   04F5 CB 57              2599 	bit	2,a			;CB 57
   04F7 CB 50              2600 	bit	2,b			;CB 50
   04F9 CB 51              2601 	bit	2,c			;CB 51
   04FB CB 52              2602 	bit	2,d			;CB 52
   04FD CB 53              2603 	bit	2,e			;CB 53
   04FF CB 54              2604 	bit	2,h			;CB 54
   0501 CB 55              2605 	bit	2,l			;CB 55
   0503 CB 5E              2606 	bit	3,(hl)			;CB 5E
   0505 DD CB 55 5E        2626 	bit	3,offset(ix)		;DD CB 55 5E
   0509 FD CB 55 5E        2627 	bit	3,offset(iy)		;FD CB 55 5E
   050D DD CB 55 5E        2628 	bit	3,(ix+offset)		;DD CB 55 5E
   0511 FD CB 55 5E        2629 	bit	3,(iy+offset)		;FD CB 55 5E
   0515 CB 5F              2633 	bit	3,a			;CB 5F
   0517 CB 58              2634 	bit	3,b			;CB 58
   0519 CB 59              2635 	bit	3,c			;CB 59
   051B CB 5A              2636 	bit	3,d			;CB 5A
   051D CB 5B              2637 	bit	3,e			;CB 5B
   051F CB 5C              2638 	bit	3,h			;CB 5C
   0521 CB 5D              2639 	bit	3,l			;CB 5D
   0523 CB 66              2640 	bit	4,(hl)			;CB 66
   0525 DD CB 55 66        2660 	bit	4,offset(ix)		;DD CB 55 66
   0529 FD CB 55 66        2661 	bit	4,offset(iy)		;FD CB 55 66
   052D DD CB 55 66        2662 	bit	4,(ix+offset)		;DD CB 55 66
   0531 FD CB 55 66        2663 	bit	4,(iy+offset)		;FD CB 55 66
   0535 CB 67              2667 	bit	4,a			;CB 67
   0537 CB 60              2668 	bit	4,b			;CB 60
   0539 CB 61              2669 	bit	4,c			;CB 61
   053B CB 62              2670 	bit	4,d			;CB 62
   053D CB 63              2671 	bit	4,e			;CB 63
   053F CB 64              2672 	bit	4,h			;CB 64
   0541 CB 65              2673 	bit	4,l			;CB 65
   0543 CB 6E              2674 	bit	5,(hl)			;CB 6E
   0545 DD CB 55 6E        2694 	bit	5,offset(ix)		;DD CB 55 6E
   0549 FD CB 55 6E        2695 	bit	5,offset(iy)		;FD CB 55 6E
   054D DD CB 55 6E        2696 	bit	5,(ix+offset)		;DD CB 55 6E
   0551 FD CB 55 6E        2697 	bit	5,(iy+offset)		;FD CB 55 6E
   0555 CB 6F              2701 	bit	5,a			;CB 6F
   0557 CB 68              2702 	bit	5,b			;CB 68
   0559 CB 69              2703 	bit	5,c			;CB 69
   055B CB 6A              2704 	bit	5,d			;CB 6A
   055D CB 6B              2705 	bit	5,e			;CB 6B
   055F CB 6C              2706 	bit	5,h			;CB 6C
   0561 CB 6D              2707 	bit	5,l			;CB 6D
   0563 CB 76              2708 	bit	6,(hl)			;CB 76
   0565 DD CB 55 76        2728 	bit	6,offset(ix)		;DD CB 55 76
   0569 FD CB 55 76        2729 	bit	6,offset(iy)		;FD CB 55 76
   056D DD CB 55 76        2730 	bit	6,(ix+offset)		;DD CB 55 76
   0571 FD CB 55 76        2731 	bit	6,(iy+offset)		;FD CB 55 76
   0575 CB 77              2735 	bit	6,a			;CB 77
   0577 CB 70              2736 	bit	6,b			;CB 70
   0579 CB 71              2737 	bit	6,c			;CB 71
   057B CB 72              2738 	bit	6,d			;CB 72
   057D CB 73              2739 	bit	6,e			;CB 73
   057F CB 74              2740 	bit	6,h			;CB 74
   0581 CB 75              2741 	bit	6,l			;CB 75
   0583 CB 7E              2742 	bit	7,(hl)			;CB 7E
   0585 DD CB 55 7E        2762 	bit	7,offset(ix)		;DD CB 55 7E
   0589 FD CB 55 7E        2763 	bit	7,offset(iy)		;FD CB 55 7E
   058D DD CB 55 7E        2764 	bit	7,(ix+offset)		;DD CB 55 7E
   0591 FD CB 55 7E        2765 	bit	7,(iy+offset)		;FD CB 55 7E
   0595 CB 7F              2769 	bit	7,a			;CB 7F
   0597 CB 78              2770 	bit	7,b			;CB 78
   0599 CB 79              2771 	bit	7,c			;CB 79
   059B CB 7A              2772 	bit	7,d			;CB 7A
   059D CB 7B              2773 	bit	7,e			;CB 7B
   059F CB 7C              2774 	bit	7,h			;CB 7C
   05A1 CB 7D              2775 	bit	7,l			;CB 7D
                           2776 
                           2777 ;*******************************************************************
                           2778 ;	CALL	
                           2779 ;*******************************************************************
                           2780 	;***********************************************************
                           2781 	; call subroutine at nn if condition is true
                           2782 	.z80
   05A3 DC 84 05           2818 	call	C,nn			;DC 84 05
   05A6 FC 84 05           2819 	call	M,nn			;FC 84 05
   05A9 FC 84 05           2820 	call	s,nn			;FC 84 05
   05AC D4 84 05           2821 	call	NC,nn			;D4 84 05
   05AF C4 84 05           2822 	call	NZ,nn			;C4 84 05
   05B2 F4 84 05           2823 	call	P,nn			;F4 84 05
   05B5 F4 84 05           2824 	CALL	NS,nn			;F4 84 05
   05B8 EC 84 05           2825 	call	PE,nn			;EC 84 05
   05BB EC 84 05           2826 	call	V,nn			;EC 84 05
   05BE E4 84 05           2827 	call	PO,nn			;E4 84 05
   05C1 E4 84 05           2828 	call	nv,nn			;E4 84 05
   05C4 CC 84 05           2829 	call	Z,nn			;CC 84 05
                           2833 	;***********************************************************
                           2834 	; unconditional call to subroutine at nn
   05C7 CD 84 05           2852 	call	nn			;CD 84 05
   05CA CD 84 05           2853 	call	(nn)			;CD 84 05
   05CD CD 84 05           2854 	call	#nn			;CD 84 05
                           2858 	;***********************************************************
                           2859 	;  p. 5-21
                           2860 	.z280
   05D0 DD CD              2861 	call	(hl)			;DD CD
   05D2 DD CC              2862 	call	z,(hl)			;DD CC
   05D4 DD E4              2863 	call	NV,(hl)			;DD E4
   05D6 FD CD 34 12        2935 	call	pcr_ofst(pc)		;FD CD 34 12
   05DA FD CD 34 12        2939 	call	(pc+pcr_ofst)		;FD CD 34 12
   05DE FD CD 34 12        2943 	call	[pcr_ofst]		;FD CD 34 12
   05E2 FD CD 04 01        2947 	call	[.+0x108]		;FD CD 04 01
   05E6 FD DC 34 12        2995 	call	c,pcr_ofst(pc)		;FD DC 34 12
   05EA FD DC 34 12        2999 	call	c,(pc+pcr_ofst)		;FD DC 34 12
   05EE FD DC 34 12        3003 	call	c,[pcr_ofst]		;FD DC 34 12
   05F2 FD DC 04 01        3007 	call	c,.+0x108(pc)		;FD DC 04 01
                           3008 ;*******************************************************************
                           3009 ;	CCF	
                           3010 ;*******************************************************************
                           3011 	;***********************************************************
                           3012 	; complement carry flag
                           3013 	.z80
   05F6 3F                 3014 	ccf				;3F
                           3015 
                           3016 ;*******************************************************************
                           3017 ;	CP	
                           3018 ;		Leading 'a' operand is optional.
                           3019 ;		If offset is ommitted 0 is assumed.
                           3020 ;*******************************************************************
                           3021 	;***********************************************************
                           3022 	; compare operand with 'a'
                           3023 	.z80
   05F7 BE                 3024 	cp	a,(hl)			;BE
   05F8 DD BE 55           3044 	cp	a,offset(ix)		;DD BE 55
   05FB FD BE 55           3045 	cp	a,offset(iy)		;FD BE 55
   05FE DD BE 55           3046 	cp	a,(ix+offset)		;DD BE 55
   0601 FD BE 55           3047 	cp	a,(iy+offset)		;FD BE 55
   0604 BF                 3051 	cp	a,a			;BF
   0605 B8                 3052 	cp	a,b			;B8
   0606 B9                 3053 	cp	a,c			;B9
   0607 BA                 3054 	cp	a,d			;BA
   0608 BB                 3055 	cp	a,e			;BB
   0609 BC                 3056 	cp	a,h			;BC
   060A BD                 3057 	cp	a,l			;BD
   060B FE 20              3073 	cp	a,#n			;FE 20
   060D FE 20              3074 	cp	a, n			;FE 20
                           3078 	;***********************************************************
                           3079 	; compare operand without 'a'
                           3080 	.z80
   060F BE                 3081 	cp	a,(hl)			;BE
   0610 DD BE 55           3101 	cp	offset(ix)		;DD BE 55
   0613 FD BE 55           3102 	cp	offset(iy)		;FD BE 55
   0616 DD BE 55           3103 	cp	(ix+offset)		;DD BE 55
   0619 FD BE 55           3104 	cp	(iy+offset)		;FD BE 55
   061C BF                 3108 	cp	a			;BF
   061D B8                 3109 	cp	b			;B8
   061E B9                 3110 	cp	c			;B9
   061F BA                 3111 	cp	d			;BA
   0620 BB                 3112 	cp	e			;BB
   0621 BC                 3113 	cp	h			;BC
   0622 BD                 3114 	cp	l			;BD
   0623 FE 20              3130 	cp	#n			;FE 20
   0625 FE 20              3131 	cp	 n			;FE 20
                           3135 	;***********************************************************
                           3136 	; compare operand with 'a'
                           3137 	;  p. 5-23
                           3138 	.z280
   0627 DD BC              3139 	cp	a,ixh			;DD BC
   0629 DD BD              3140 	cp	a,ixl			;DD BD
   062B FD BC              3141 	cp	a,iyh			;FD BC
   062D FD BD              3142 	cp	a,iyl			;FD BD
   062F FE 20              3190 	cp	a,#n			;FE 20
   0631 DD BF 44 33        3191 	cp	a,(daddr)		;DD BF 44 33
   0635 DD BE 55           3202 	cp	a,sxoff(ix)		;DD BE 55
   0638 DD BE 55           3203 	cp	a,(ix+sxoff)		;DD BE 55
   063B FD BE 55           3204 	cp	a,sxoff(iy)		;FD BE 55
   063E FD BE 55           3205 	cp	a,(iy+sxoff)		;FD BE 55
   0641 FD BB 55 00        3209 	cp	a,sxoff(hl)		;FD BB 55 00
   0645 FD BB 55 00        3210 	cp	a,(hl+sxoff)		;FD BB 55 00
   0649 DD B8 55 00        3211 	cp	a,sxoff(sp)		;DD B8 55 00
   064D DD B8 55 00        3212 	cp	a,(sp+sxoff)		;DD B8 55 00
   0651 FD B9 22 11        3213 	cp	a,lxoff(ix)		;FD B9 22 11
   0655 FD B9 22 11        3214 	cp	a,(ix+lxoff)		;FD B9 22 11
   0659 FD BA 22 11        3215 	cp	a,lxoff(iy)		;FD BA 22 11
   065D FD BA 22 11        3216 	cp	a,(iy+lxoff)		;FD BA 22 11
   0661 FD BB 22 11        3217 	cp	a,lxoff(hl)		;FD BB 22 11
   0665 FD BB 22 11        3218 	cp	a,(hl+lxoff)		;FD BB 22 11
   0669 DD B8 22 11        3219 	cp	a,lxoff(sp)		;DD B8 22 11
   066D DD B8 22 11        3220 	cp	a,(sp+lxoff)		;DD B8 22 11
   0671 DD BE 00           3224 	cp	a,(ix)			;DD BE 00
   0674 FD BE 00           3225 	cp	a,(iy)			;FD BE 00
   0677 BE                 3226 	cp	a,(hl)			;BE
   0678 DD B8 00 00        3227 	cp	a,(sp)			;DD B8 00 00
   067C FD B8 34 12        3299 	cp	a,pcr_ofst(pc)		;FD B8 34 12
   0680 FD B8 34 12        3303 	cp	a,(pc+pcr_ofst)		;FD B8 34 12
   0684 FD B8 34 12        3307 	cp	a,[pcr_ofst]		;FD B8 34 12
   0688 FD B8 51 00        3311 	cp	a,[.+offsetc]		;FD B8 51 00
   068C DD B9              3312 	cp	a,(hl+ix)		;DD B9
   068E DD BA              3313 	cp	a,(hl+iy)		;DD BA
   0690 DD BB              3314 	cp	a,(ix+iy)		;DD BB
                           3315 	;***********************************************************
                           3316 	; compare operand without 'a'
                           3317 	;  p. 5-23
                           3318 	.z280
   0692 FE 20              3366 	cp	#n			;FE 20
   0694 DD BF 44 33        3367 	cp	(daddr)			;DD BF 44 33
   0698 DD BE 55           3378 	cp	sxoff(ix)		;DD BE 55
   069B DD BE 55           3379 	cp	(ix+sxoff)		;DD BE 55
   069E FD BE 55           3380 	cp	sxoff(iy)		;FD BE 55
   06A1 FD BE 55           3381 	cp	(iy+sxoff)		;FD BE 55
   06A4 FD BB 55 00        3385 	cp	sxoff(hl)		;FD BB 55 00
   06A8 FD BB 55 00        3386 	cp	(hl+sxoff)		;FD BB 55 00
   06AC DD B8 55 00        3387 	cp	sxoff(sp)		;DD B8 55 00
   06B0 DD B8 55 00        3388 	cp	(sp+sxoff)		;DD B8 55 00
   06B4 FD B9 22 11        3389 	cp	lxoff(ix)		;FD B9 22 11
   06B8 FD B9 22 11        3390 	cp	(ix+lxoff)		;FD B9 22 11
   06BC FD BA 22 11        3391 	cp	lxoff(iy)		;FD BA 22 11
   06C0 FD BA 22 11        3392 	cp	(iy+lxoff)		;FD BA 22 11
   06C4 FD BB 22 11        3393 	cp	lxoff(hl)		;FD BB 22 11
   06C8 FD BB 22 11        3394 	cp	(hl+lxoff)		;FD BB 22 11
   06CC DD B8 22 11        3395 	cp	lxoff(sp)		;DD B8 22 11
   06D0 DD B8 22 11        3396 	cp	(sp+lxoff)		;DD B8 22 11
   06D4 DD BE 00           3400 	cp	(ix)			;DD BE 00
   06D7 FD BE 00           3401 	cp	(iy)			;FD BE 00
   06DA BE                 3402 	cp	(hl)			;BE
   06DB DD B8 00 00        3403 	cp	(sp)			;DD B8 00 00
   06DF FD B8 34 12        3475 	cp	pcr_ofst(pc)		;FD B8 34 12
   06E3 FD B8 34 12        3479 	cp	(pc+pcr_ofst)		;FD B8 34 12
   06E7 FD B8 34 12        3483 	cp	[pcr_ofst]		;FD B8 34 12
   06EB FD B8 51 00        3487 	cp	[.+offsetc]		;FD B8 51 00
   06EF DD B9              3488 	cp	(hl+ix)			;DD B9
   06F1 DD BA              3489 	cp	(hl+iy)			;DD BA
   06F3 DD BB              3490 	cp	(ix+iy)			;DD BB
                           3491 ;*******************************************************************
                           3492 ;	CPW	
                           3493 ;*******************************************************************
                           3494 	;***********************************************************
                           3495 	; compare word operand with 'hl'
                           3496 	;  p. 5-29
                           3497 	.z280
   06F5 ED C7              3498 	cpw	hl,bc			;ED C7
   06F7 ED D7              3499 	cpw	hl,de			;ED D7
   06F9 ED E7              3500 	cpw	hl,hl			;ED E7
   06FB ED F7              3501 	cpw	hl,sp			;ED F7
   06FD DD ED E7           3502 	cpw	hl,ix			;DD ED E7
   0700 FD ED E7           3503 	cpw	hl,iy			;FD ED E7
   0703 FD ED F7 84 05     3535 	cpw	hl,#nn			;FD ED F7 84 05
   0708 DD ED D7 44 33     3536 	cpw	hl,(daddr)		;DD ED D7 44 33
   070D FD ED C7 55 00     3537 	cpw	hl,sxoff(ix)		;FD ED C7 55 00
   0712 FD ED C7 55 00     3538 	cpw	hl,(ix+sxoff)		;FD ED C7 55 00
   0717 FD ED C7 22 11     3539 	cpw	hl,lxoff(ix)		;FD ED C7 22 11
   071C FD ED C7 22 11     3540 	cpw	hl,(ix+lxoff)		;FD ED C7 22 11
   0721 FD ED D7 55 00     3541 	cpw	hl,sxoff(iy)		;FD ED D7 55 00
   0726 FD ED D7 55 00     3542 	cpw	hl,(iy+sxoff)		;FD ED D7 55 00
   072B FD ED D7 22 11     3543 	cpw	hl,lxoff(iy)		;FD ED D7 22 11
   0730 FD ED D7 22 11     3544 	cpw	hl,(iy+lxoff)		;FD ED D7 22 11
   0735 DD ED C7           3548 	cpw	hl,(hl)			;DD ED C7
   0738 FD ED C7 00 00     3549 	cpw	hl,(ix)			;FD ED C7 00 00
   073D FD ED D7 00 00     3550 	cpw	hl,(iy)			;FD ED D7 00 00
   0742 DD ED F7 34 12     3622 	cpw	hl,pcr_ofst(pc)		;DD ED F7 34 12
   0747 DD ED F7 34 12     3626 	cpw	hl,(pc+pcr_ofst)	;DD ED F7 34 12
   074C DD ED F7 34 12     3630 	cpw	hl,[pcr_ofst]		;DD ED F7 34 12
   0751 DD ED F7 0F 00     3634 	cpw	hl,[.+20]		;DD ED F7 0F 00
                           3635 
                           3636 	;***********************************************************
                           3637 	; compare word operand without 'hl'
   0756 ED C7              3638 	cpw	bc			;ED C7
   0758 ED D7              3639 	cpw	de			;ED D7
   075A ED E7              3640 	cpw	hl			;ED E7
   075C ED F7              3641 	cpw	sp			;ED F7
   075E DD ED E7           3642 	cpw	ix			;DD ED E7
   0761 FD ED E7           3643 	cpw	iy			;FD ED E7
   0764 FD ED F7 84 05     3675 	cpw	#nn			;FD ED F7 84 05
   0769 DD ED D7 44 33     3676 	cpw	(daddr)			;DD ED D7 44 33
   076E FD ED C7 55 00     3677 	cpw	sxoff(ix)		;FD ED C7 55 00
   0773 FD ED C7 55 00     3678 	cpw	(ix+sxoff)		;FD ED C7 55 00
   0778 FD ED C7 22 11     3679 	cpw	lxoff(ix)		;FD ED C7 22 11
   077D FD ED C7 22 11     3680 	cpw	(ix+lxoff)		;FD ED C7 22 11
   0782 FD ED D7 55 00     3681 	cpw	sxoff(iy)		;FD ED D7 55 00
   0787 FD ED D7 55 00     3682 	cpw	(iy+sxoff)		;FD ED D7 55 00
   078C FD ED D7 22 11     3683 	cpw	lxoff(iy)		;FD ED D7 22 11
   0791 FD ED D7 22 11     3684 	cpw	(iy+lxoff)		;FD ED D7 22 11
   0796 DD ED C7           3688 	cpw	(hl)			;DD ED C7
   0799 FD ED C7 00 00     3689 	cpw	(ix)			;FD ED C7 00 00
   079E FD ED D7 00 00     3690 	cpw	(iy)			;FD ED D7 00 00
   07A3 DD ED F7 34 12     3762 	cpw	pcr_ofst(pc)		;DD ED F7 34 12
   07A8 DD ED F7 34 12     3766 	cpw	(pc+pcr_ofst)		;DD ED F7 34 12
   07AD DD ED F7 34 12     3770 	cpw	[pcr_ofst]		;DD ED F7 34 12
   07B2 DD ED F7 0F 00     3774 	cpw	[.+20]			;DD ED F7 0F 00
                           3775 
                           3776 	;***********************************************************
                           3777 	; Alternative to cpw hl,...
                           3778 	;  p. 5-29
                           3779 	.z280
   07B7 ED C7              3780 	cp	hl,bc			;ED C7
   07B9 ED D7              3781 	cp	hl,de			;ED D7
   07BB ED E7              3782 	cp	hl,hl			;ED E7
   07BD ED F7              3783 	cp	hl,sp			;ED F7
   07BF DD ED E7           3784 	cp	hl,ix			;DD ED E7
   07C2 FD ED E7           3785 	cp	hl,iy			;FD ED E7
   07C5 FD ED F7 84 05     3817 	cp	hl,#nn			;FD ED F7 84 05
   07CA DD ED D7 44 33     3818 	cp	hl,(daddr)		;DD ED D7 44 33
   07CF FD ED C7 55 00     3819 	cp	hl,sxoff(ix)		;FD ED C7 55 00
   07D4 FD ED C7 55 00     3820 	cp	hl,(ix+sxoff)		;FD ED C7 55 00
   07D9 FD ED C7 22 11     3821 	cp	hl,lxoff(ix)		;FD ED C7 22 11
   07DE FD ED C7 22 11     3822 	cp	hl,(ix+lxoff)		;FD ED C7 22 11
   07E3 FD ED D7 55 00     3823 	cp	hl,sxoff(iy)		;FD ED D7 55 00
   07E8 FD ED D7 55 00     3824 	cp	hl,(iy+sxoff)		;FD ED D7 55 00
   07ED FD ED D7 22 11     3825 	cp	hl,lxoff(iy)		;FD ED D7 22 11
   07F2 FD ED D7 22 11     3826 	cp	hl,(iy+lxoff)		;FD ED D7 22 11
   07F7 DD ED C7           3830 	cp	hl,(hl)			;DD ED C7
   07FA FD ED C7 00 00     3831 	cp	hl,(ix)			;FD ED C7 00 00
   07FF FD ED D7 00 00     3832 	cp	hl,(iy)			;FD ED D7 00 00
   0804 DD ED F7 34 12     3904 	cp	hl,pcr_ofst(pc)		;DD ED F7 34 12
   0809 DD ED F7 34 12     3908 	cp	hl,(pc+pcr_ofst)	;DD ED F7 34 12
   080E DD ED F7 34 12     3912 	cp	hl,[pcr_ofst]		;DD ED F7 34 12
   0813 DD ED F7 0F 00     3916 	cp	hl,[.+20]		;DD ED F7 0F 00
                           3917 
                           3918 ;*******************************************************************
                           3919 ;	CPD	
                           3920 ;*******************************************************************
                           3921 	;***********************************************************
                           3922 	; compare location (hl) and 'a'
                           3923 	; decrement 'hl' and 'bc'
                           3924 	.z80
   0818 ED A9              3925 	cpd				;ED A9
                           3926 
                           3927 ;*******************************************************************
                           3928 ;	CPDR	
                           3929 ;*******************************************************************
                           3930 	;***********************************************************
                           3931 	; compare location (hl) and 'a'
                           3932 	; decrement 'hl' and 'bc'
                           3933 	; repeat until 'bc' = 0
                           3934 	.z80
   081A ED B9              3935 	cpdr				;ED B9
                           3936 
                           3937 ;*******************************************************************
                           3938 ;	CPI	
                           3939 ;*******************************************************************
                           3940 	;***********************************************************
                           3941 	; compare location (hl) and 'a'
                           3942 	; increment 'hl' and decrement 'bc'
                           3943 	.z80
   081C ED A1              3944 	cpi				;ED A1
                           3945 
                           3946 ;*******************************************************************
                           3947 ;	CPIR	
                           3948 ;*******************************************************************
                           3949 	;***********************************************************
                           3950 	; compare location (hl) and 'a'
                           3951 	; increment 'hl' and decrement 'bc'
                           3952 	; repeat until 'bc' = 0
                           3953 	.z80
   081E ED B1              3954 	cpir				;ED B1
                           3955 
                           3956 ;*******************************************************************
                           3957 ;	CPL	
                           3958 ;*******************************************************************
                           3959 	;***********************************************************
                           3960 	; 1's complement of 'a'
                           3961 	.z80
   0820 2F                 3962 	cpl				;2F
                           3963 
                           3964 ;*******************************************************************
                           3965 ;	DAA	
                           3966 ;*******************************************************************
                           3967 	;***********************************************************
                           3968 	; decimal adjust 'a'
                           3969 	.z80
   0821 27                 3970 	daa				;27
                           3971 
                           3972 ;*******************************************************************
                           3973 ;	DEC	
                           3974 ;*******************************************************************
                           3975 	;***********************************************************
                           3976 	; decrement operand
                           3977 	.z80
   0822 35                 3978 	dec	(hl)			;35
   0823 DD 35 55           3998 	dec	offset(ix)		;DD 35 55
   0826 FD 35 55           3999 	dec	offset(iy)		;FD 35 55
   0829 DD 35 55           4000 	dec	(ix+offset)		;DD 35 55
   082C FD 35 55           4001 	dec	(iy+offset)		;FD 35 55
   082F 3D                 4005 	dec	a			;3D
   0830 05                 4006 	dec	b			;05
   0831 0B                 4007 	dec	bc			;0B
   0832 0D                 4008 	dec	c			;0D
   0833 15                 4009 	dec	d			;15
   0834 1B                 4010 	dec	de			;1B
   0835 1D                 4011 	dec	e			;1D
   0836 25                 4012 	dec	h			;25
   0837 2B                 4013 	dec	hl			;2B
   0838 DD 2B              4014 	dec	ix			;DD 2B
   083A FD 2B              4015 	dec	iy			;FD 2B
   083C 2D                 4016 	dec	l			;2D
   083D 3B                 4017 	dec	sp			;3B
                           4018 	;***********************************************************
                           4019 	;  p. 5-32
                           4020 	.z280
   083E DD 25              4021 	dec	ixh			;DD 25
   0840 DD 2D              4022 	dec	ixl			;DD 2D
   0842 FD 25              4023 	dec	iyh			;FD 25
   0844 FD 2D              4024 	dec	iyl			;FD 2D
   0846 DD 3D 44 33        4070 	dec	(daddr)			;DD 3D 44 33
   084A DD 35 55           4081 	dec	sxoff(ix)		;DD 35 55
   084D DD 35 55           4082 	dec	(ix+sxoff)		;DD 35 55
   0850 FD 35 55           4083 	dec	sxoff(iy)		;FD 35 55
   0853 FD 35 55           4084 	dec	(iy+sxoff)		;FD 35 55
   0856 FD 1D 55 00        4088 	dec	sxoff(hl)		;FD 1D 55 00
   085A FD 1D 55 00        4089 	dec	(hl+sxoff)		;FD 1D 55 00
   085E DD 05 55 00        4090 	dec	sxoff(sp)		;DD 05 55 00
   0862 DD 05 55 00        4091 	dec	(sp+sxoff)		;DD 05 55 00
   0866 FD 0D 22 11        4092 	dec	lxoff(ix)		;FD 0D 22 11
   086A FD 0D 22 11        4093 	dec	(ix+lxoff)		;FD 0D 22 11
   086E FD 15 22 11        4094 	dec	lxoff(iy)		;FD 15 22 11
   0872 FD 15 22 11        4095 	dec	(iy+lxoff)		;FD 15 22 11
   0876 FD 1D 22 11        4096 	dec	lxoff(hl)		;FD 1D 22 11
   087A FD 1D 22 11        4097 	dec	(hl+lxoff)		;FD 1D 22 11
   087E DD 05 22 11        4098 	dec	lxoff(sp)		;DD 05 22 11
   0882 DD 05 22 11        4099 	dec	(sp+lxoff)		;DD 05 22 11
   0886 DD 35 00           4103 	dec	(ix)			;DD 35 00
   0889 FD 35 00           4104 	dec	(iy)			;FD 35 00
   088C 35                 4105 	dec	(hl)			;35
   088D DD 05 00 00        4106 	dec	(sp)			;DD 05 00 00
   0891 FD 05 34 12        4178 	dec	pcr_ofst(pc)		;FD 05 34 12
   0895 FD 05 34 12        4182 	dec	(pc+pcr_ofst)		;FD 05 34 12
   0899 FD 05 34 12        4186 	dec	[pcr_ofst]		;FD 05 34 12
   089D FD 05 51 00        4190 	dec	[.+offsetc]		;FD 05 51 00
   08A1 DD 0D              4191 	dec	(hl+ix)			;DD 0D
   08A3 DD 15              4192 	dec	(hl+iy)			;DD 15
   08A5 DD 1D              4193 	dec	(ix+iy)			;DD 1D
                           4194 
                           4195 ;*******************************************************************
                           4196 ;	DECB	
                           4197 ;*******************************************************************
                           4198 	;***********************************************************
                           4199 	; decrement byte operand
                           4200 	;  p. 5-32
                           4201 	.z80
   08A7 35                 4202 	decb	(hl)			;35
   08A8 DD 35 55           4222 	decb	offset(ix)		;DD 35 55
   08AB FD 35 55           4223 	decb	offset(iy)		;FD 35 55
   08AE DD 35 55           4224 	decb	(ix+offset)		;DD 35 55
   08B1 FD 35 55           4225 	decb	(iy+offset)		;FD 35 55
                           4229 	;***********************************************************
                           4230 	.z280
   08B4 DD 3D 44 33        4276 	decb	(daddr)			;DD 3D 44 33
   08B8 DD 35 55           4287 	decb	sxoff(ix)		;DD 35 55
   08BB DD 35 55           4288 	decb	(ix+sxoff)		;DD 35 55
   08BE FD 35 55           4289 	decb	sxoff(iy)		;FD 35 55
   08C1 FD 35 55           4290 	decb	(iy+sxoff)		;FD 35 55
   08C4 FD 1D 55 00        4294 	decb	sxoff(hl)		;FD 1D 55 00
   08C8 FD 1D 55 00        4295 	decb	(hl+sxoff)		;FD 1D 55 00
   08CC DD 05 55 00        4296 	decb	sxoff(sp)		;DD 05 55 00
   08D0 DD 05 55 00        4297 	decb	(sp+sxoff)		;DD 05 55 00
   08D4 FD 0D 22 11        4298 	decb	lxoff(ix)		;FD 0D 22 11
   08D8 FD 0D 22 11        4299 	decb	(ix+lxoff)		;FD 0D 22 11
   08DC FD 15 22 11        4300 	decb	lxoff(iy)		;FD 15 22 11
   08E0 FD 15 22 11        4301 	decb	(iy+lxoff)		;FD 15 22 11
   08E4 FD 1D 22 11        4302 	decb	lxoff(hl)		;FD 1D 22 11
   08E8 FD 1D 22 11        4303 	decb	(hl+lxoff)		;FD 1D 22 11
   08EC DD 05 22 11        4304 	decb	lxoff(sp)		;DD 05 22 11
   08F0 DD 05 22 11        4305 	decb	(sp+lxoff)		;DD 05 22 11
   08F4 DD 35 00           4309 	decb	(ix)			;DD 35 00
   08F7 FD 35 00           4310 	decb	(iy)			;FD 35 00
   08FA 35                 4311 	decb	(hl)			;35
   08FB DD 05 00 00        4312 	decb	(sp)			;DD 05 00 00
   08FF FD 05 34 12        4384 	decb	pcr_ofst(pc)		;FD 05 34 12
   0903 FD 05 34 12        4388 	decb	(pc+pcr_ofst)		;FD 05 34 12
   0907 FD 05 34 12        4392 	decb	[pcr_ofst]		;FD 05 34 12
   090B FD 05 51 00        4396 	decb	[.+offsetc]		;FD 05 51 00
   090F DD 0D              4397 	decb	(hl+ix)			;DD 0D
   0911 DD 15              4398 	decb	(hl+iy)			;DD 15
   0913 DD 1D              4399 	decb	(ix+iy)			;DD 1D
                           4400 
                           4401 ;*******************************************************************
                           4402 ;	DECW	
                           4403 ;*******************************************************************
                           4404 	;***********************************************************
                           4405 	;  p. 5-32
                           4406 	.z80
   0915 0B                 4407 	decw	bc			;0B
   0916 1B                 4408 	decw	de			;1B
   0917 2B                 4409 	decw	hl			;2B
   0918 3B                 4410 	decw	sp			;3B
   0919 DD 2B              4411 	decw	ix			;DD 2B
   091B FD 2B              4412 	decw	iy			;FD 2B
                           4413 	;***********************************************************
                           4414 	;  p. 5-33
                           4415 	.z280
   091D DD 1B 44 33        4445 	decw	(daddr)			;DD 1B 44 33
   0921 FD 0B 55 00        4446 	decw	sxoff(ix)		;FD 0B 55 00
   0925 FD 0B 55 00        4447 	decw	(ix+sxoff)		;FD 0B 55 00
   0929 FD 1B 55 00        4448 	decw	sxoff(iy)		;FD 1B 55 00
   092D FD 1B 55 00        4449 	decw	(iy+sxoff)		;FD 1B 55 00
   0931 FD 0B 22 11        4450 	decw	lxoff(ix)		;FD 0B 22 11
   0935 FD 0B 22 11        4451 	decw	(ix+lxoff)		;FD 0B 22 11
   0939 FD 1B 22 11        4452 	decw	lxoff(iy)		;FD 1B 22 11
   093D FD 1B 22 11        4453 	decw	(iy+lxoff)		;FD 1B 22 11
   0941 FD 0B 00 00        4457 	decw	(ix)			;FD 0B 00 00
   0945 FD 1B 00 00        4458 	decw	(iy)			;FD 1B 00 00
   0949 DD 0B              4459 	decw	(hl)			;DD 0B
   094B DD 3B 34 12        4531 	decw	pcr_ofst(pc)		;DD 3B 34 12
   094F DD 3B 34 12        4535 	decw	(pc+pcr_ofst)		;DD 3B 34 12
   0953 DD 3B 34 12        4539 	decw	[pcr_ofst]		;DD 3B 34 12
   0957 DD 3B 51 00        4543 	decw	[.+offsetc]		;DD 3B 51 00
                           4544 
                           4545 ;*******************************************************************
                           4546 ;	DI	
                           4547 ;*******************************************************************
                           4548 	;***********************************************************
                           4549 	; disable interrupts
                           4550 	.z80
   095B F3                 4551 	di				;F3
                           4552 ;	di	#3			;	q
                           4553 	.z180
   095C F3                 4554 	di				;F3
                           4555 ;	di	#3			;	q
                           4556 	;***********************************************************
                           4557 	;  p. 5-34
                           4558 	.z280
                           4559 ;	di				;	q
                           4560 ;	di	#3			;	q
                           4561 	.z280p
   095D F3                 4562 	di				;F3
   095E ED 77 03           4563 	di	#3			;ED 77 03
   0961 ED 77 03           4564 	di	 3			;ED 77 03
                           4565 
                           4566 ;*******************************************************************
                           4567 ;	DIV	
                           4568 ;*******************************************************************
                           4569 	;***********************************************************
                           4570 	;  p. 5-35	DIV(byte)
                           4571 	.z280
   0964 ED FC              4572 	div	hl,a			;ED FC
   0966 ED C4              4573 	div	hl,b			;ED C4
   0968 ED CC              4574 	div	hl,c			;ED CC
   096A ED D4              4575 	div	hl,d			;ED D4
   096C ED DC              4576 	div	hl,e			;ED DC
   096E ED E4              4577 	div	hl,h			;ED E4
   0970 ED EC              4578 	div	hl,l			;ED EC
   0972 DD ED E4           4579 	div	hl,ixh			;DD ED E4
   0975 DD ED EC           4580 	div	hl,ixl			;DD ED EC
   0978 FD ED E4           4581 	div	hl,iyh			;FD ED E4
   097B FD ED EC           4582 	div	hl,iyl			;FD ED EC
   097E FD ED FC 0A        4583 	div	hl,#10			;FD ED FC 0A
   0982 DD ED FC 44 33     4629 	div	hl,(daddr)		;DD ED FC 44 33
   0987 DD ED F4 55        4640 	div	hl,offset(ix)		;DD ED F4 55
   098B DD ED F4 55        4641 	div	hl,(ix+offset)		;DD ED F4 55
   098F FD ED F4 55        4642 	div	hl,offset(iy)		;FD ED F4 55
   0993 FD ED F4 55        4643 	div	hl,(iy+offset)		;FD ED F4 55
   0997 FD ED DC 55 00     4647 	div	hl,offset(hl)		;FD ED DC 55 00
   099C FD ED DC 55 00     4648 	div	hl,(hl+offset)		;FD ED DC 55 00
   09A1 DD ED C4 55 00     4649 	div	hl,offset(sp)		;DD ED C4 55 00
   09A6 DD ED C4 55 00     4650 	div	hl,(sp+offset)		;DD ED C4 55 00
   09AB FD ED CC 22 11     4651 	div	hl,lxoff(ix)		;FD ED CC 22 11
   09B0 FD ED CC 22 11     4652 	div	hl,(ix+lxoff)		;FD ED CC 22 11
   09B5 FD ED D4 22 11     4653 	div	hl,lxoff(iy)		;FD ED D4 22 11
   09BA FD ED D4 22 11     4654 	div	hl,(iy+lxoff)		;FD ED D4 22 11
   09BF FD ED DC 22 11     4655 	div	hl,lxoff(hl)		;FD ED DC 22 11
   09C4 FD ED DC 22 11     4656 	div	hl,(hl+lxoff)		;FD ED DC 22 11
   09C9 DD ED C4 22 11     4657 	div	hl,lxoff(sp)		;DD ED C4 22 11
   09CE DD ED C4 22 11     4658 	div	hl,(sp+lxoff)		;DD ED C4 22 11
   09D3 DD ED F4 00        4662 	div	hl,(ix)			;DD ED F4 00
   09D7 FD ED F4 00        4663 	div	hl,(iy)			;FD ED F4 00
                           4664 ; misprint in the manual on p. 5-35 says the following should assemble as ED E4
                           4665 ;  Appendix C.  corrects this to ED F4
   09DB ED F4              4666 	div	hl,(hl)			;ED F4
   09DD FD ED C4 55 00     4738 	div	hl,pcr_ofst(pc)		;FD ED C4 55 00
   09E2 FD ED C4 55 00     4742 	div	hl,(pc+pcr_ofst)	;FD ED C4 55 00
   09E7 FD ED C4 55 00     4746 	div	hl,[pcr_ofst]		;FD ED C4 55 00
   09EC FD ED C4 50 00     4750 	div	hl,[.+offsetc]		;FD ED C4 50 00
   09F1 DD ED CC           4751 	div	hl,(hl+ix)		;DD ED CC
   09F4 DD ED D4           4752 	div	hl,(hl+iy)		;DD ED D4
   09F7 DD ED DC           4753 	div	hl,(ix+iy)		;DD ED DC
                           4754 
                           4755 ;*******************************************************************
                           4756 ;	DIVU
                           4757 ;*******************************************************************
                           4758 	;***********************************************************
                           4759 	;  p. 5-37	DIVU(byte)
                           4760 	.z280
   09FA ED FD              4761 	divu	hl,a			;ED FD
   09FC ED C5              4762 	divu	hl,b			;ED C5
   09FE ED CD              4763 	divu	hl,c			;ED CD
   0A00 ED D5              4764 	divu	hl,d			;ED D5
   0A02 ED DD              4765 	divu	hl,e			;ED DD
   0A04 ED E5              4766 	divu	hl,h			;ED E5
   0A06 ED ED              4767 	divu	hl,l			;ED ED
   0A08 DD ED E5           4768 	divu	hl,ixh			;DD ED E5
   0A0B DD ED ED           4769 	divu	hl,ixl			;DD ED ED
   0A0E FD ED E5           4770 	divu	hl,iyh			;FD ED E5
   0A11 FD ED ED           4771 	divu	hl,iyl			;FD ED ED
   0A14 FD ED FD 0A        4772 	divu	hl,#10			;FD ED FD 0A
   0A18 DD ED FD 44 33     4818 	divu	hl,(daddr)		;DD ED FD 44 33
   0A1D DD ED F5 55        4829 	divu	hl,offset(ix)		;DD ED F5 55
   0A21 DD ED F5 55        4830 	divu	hl,(ix+offset)		;DD ED F5 55
   0A25 FD ED F5 55        4831 	divu	hl,offset(iy)		;FD ED F5 55
   0A29 FD ED F5 55        4832 	divu	hl,(iy+offset)		;FD ED F5 55
   0A2D FD ED DD 55 00     4836 	divu	hl,offset(hl)		;FD ED DD 55 00
   0A32 FD ED DD 55 00     4837 	divu	hl,(hl+offset)		;FD ED DD 55 00
   0A37 DD ED C5 55 00     4838 	divu	hl,offset(sp)		;DD ED C5 55 00
   0A3C DD ED C5 55 00     4839 	divu	hl,(sp+offset)		;DD ED C5 55 00
   0A41 FD ED CD 22 11     4840 	divu	hl,lxoff(ix)		;FD ED CD 22 11
   0A46 FD ED CD 22 11     4841 	divu	hl,(ix+lxoff)		;FD ED CD 22 11
   0A4B FD ED D5 22 11     4842 	divu	hl,lxoff(iy)		;FD ED D5 22 11
   0A50 FD ED D5 22 11     4843 	divu	hl,(iy+lxoff)		;FD ED D5 22 11
   0A55 FD ED DD 22 11     4844 	divu	hl,lxoff(hl)		;FD ED DD 22 11
   0A5A FD ED DD 22 11     4845 	divu	hl,(hl+lxoff)		;FD ED DD 22 11
   0A5F DD ED C5 22 11     4846 	divu	hl,lxoff(sp)		;DD ED C5 22 11
   0A64 DD ED C5 22 11     4847 	divu	hl,(sp+lxoff)		;DD ED C5 22 11
   0A69 FD ED F5 00        4851 	divu	hl,(iy)			;FD ED F5 00
   0A6D DD ED F5 00        4852 	divu	hl,(ix)			;DD ED F5 00
   0A71 ED F5              4853 	divu	hl,(hl)			;ED F5
   0A73 FD ED C5 55 00     4925 	divu	hl,pcr_ofst(pc)		;FD ED C5 55 00
   0A78 FD ED C5 55 00     4929 	divu	hl,(pc+pcr_ofst)	;FD ED C5 55 00
   0A7D FD ED C5 55 00     4933 	divu	hl,[pcr_ofst]		;FD ED C5 55 00
   0A82 FD ED C5 50 00     4937 	divu	hl,[.+offsetc]		;FD ED C5 50 00
   0A87 DD ED CD           4938 	divu	hl,(hl+ix)		;DD ED CD
   0A8A DD ED D5           4939 	divu	hl,(hl+iy)		;DD ED D5
   0A8D DD ED DD           4940 	divu	hl,(ix+iy)		;DD ED DD
                           4941 
                           4942 ;*******************************************************************
                           4943 ;	DIVUW	
                           4944 ;*******************************************************************
                           4945 	;***********************************************************
                           4946 	;  p. 5-39	DIVUW(word)
                           4947 	.z280
   0A90 ED CB              4948 	divuw	dehl,bc			;ED CB
   0A92 ED DB              4949 	divuw	dehl,de			;ED DB
   0A94 ED EB              4950 	divuw	dehl,hl			;ED EB
   0A96 ED FB              4951 	divuw	dehl,sp			;ED FB
   0A98 DD ED EB           4952 	divuw	dehl,ix			;DD ED EB
   0A9B FD ED EB           4953 	divuw	dehl,iy			;FD ED EB
   0A9E DD ED CB           4954 	divuw	dehl,(hl)		;DD ED CB
   0AA1 FD ED CB 00 00     4955 	divuw	dehl,(ix)		;FD ED CB 00 00
   0AA6 FD ED DB 00 00     4956 	divuw	dehl,(iy)		;FD ED DB 00 00
   0AAB FD ED FB 20 00     4990     	divuw	dehl,#n			;FD ED FB 20 00
   0AB0 FD ED FB 84 05     4991 	divuw	dehl,#nn		;FD ED FB 84 05
   0AB5 DD ED DB 44 33     4992 	divuw	dehl,(daddr)		;DD ED DB 44 33
   0ABA FD ED CB 55 00     4993 	divuw	dehl,(ix+offset)	;FD ED CB 55 00
   0ABF FD ED CB 55 00     4994 	divuw	dehl,offset(ix)		;FD ED CB 55 00
   0AC4 FD ED DB 55 00     4995 	divuw	dehl,(iy+offset)	;FD ED DB 55 00
   0AC9 FD ED DB 55 00     4996 	divuw	dehl,offset(iy)		;FD ED DB 55 00
   0ACE FD ED CB 22 11     4997 	divuw	dehl,(ix+lxoff)		;FD ED CB 22 11
   0AD3 FD ED CB 22 11     4998 	divuw	dehl,lxoff(ix)		;FD ED CB 22 11
   0AD8 FD ED DB 22 11     4999 	divuw	dehl,(iy+lxoff)		;FD ED DB 22 11
   0ADD FD ED DB 22 11     5000 	divuw	dehl,lxoff(iy)		;FD ED DB 22 11
   0AE2 FD ED CB 00 00     5004 	divuw	dehl,(ix)		;FD ED CB 00 00
   0AE7 FD ED DB 00 00     5005 	divuw	dehl,(iy)		;FD ED DB 00 00
   0AEC DD ED CB           5006 	divuw	dehl,(hl)		;DD ED CB
   0AEF DD ED FB 55 00     5078 	divuw	dehl,pcr_ofst(pc)	;DD ED FB 55 00
   0AF4 DD ED FB 55 00     5082 	divuw	dehl,(pc+pcr_ofst)	;DD ED FB 55 00
   0AF9 DD ED FB 55 00     5086 	divuw	dehl,[pcr_ofst]		;DD ED FB 55 00
   0AFE DD ED FB 50 00     5090 	divuw	dehl,[.+offsetc]	;DD ED FB 50 00
                           5091 
                           5092 ;*******************************************************************
                           5093 ;	DIVW	
                           5094 ;*******************************************************************
                           5095 	;***********************************************************
                           5096 	;  p. 5-41	DIVW(word)
                           5097 	.z280
   0B03 ED CA              5098 	divw	dehl,bc			;ED CA
   0B05 ED DA              5099 	divw	dehl,de			;ED DA
   0B07 ED EA              5100 	divw	dehl,hl			;ED EA
   0B09 ED FA              5101 	divw	dehl,sp			;ED FA
   0B0B DD ED EA           5102 	divw	dehl,ix			;DD ED EA
   0B0E FD ED EA           5103 	divw	dehl,iy			;FD ED EA
   0B11 DD ED CA           5104 	divw	dehl,(hl)		;DD ED CA
   0B14 FD ED CA 00 00     5105 	divw	dehl,(ix)		;FD ED CA 00 00
   0B19 FD ED DA 00 00     5106 	divw	dehl,(iy)		;FD ED DA 00 00
   0B1E FD ED FA 20 00     5140 	divw	dehl,#n			;FD ED FA 20 00
   0B23 FD ED FA 84 05     5141 	divw	dehl,#nn		;FD ED FA 84 05
   0B28 DD ED DA 44 33     5142 	divw	dehl,(daddr)		;DD ED DA 44 33
   0B2D FD ED CA 55 00     5143 	divw	dehl,(ix+offset)	;FD ED CA 55 00
   0B32 FD ED CA 55 00     5144 	divw	dehl,offset(ix)		;FD ED CA 55 00
   0B37 FD ED DA 55 00     5145 	divw	dehl,(iy+offset)	;FD ED DA 55 00
   0B3C FD ED DA 55 00     5146 	divw	dehl,offset(iy)		;FD ED DA 55 00
   0B41 FD ED CA 22 11     5147 	divw	dehl,(ix+lxoff)		;FD ED CA 22 11
   0B46 FD ED CA 22 11     5148 	divw	dehl,lxoff(ix)		;FD ED CA 22 11
   0B4B FD ED DA 22 11     5149 	divw	dehl,(iy+lxoff)		;FD ED DA 22 11
   0B50 FD ED DA 22 11     5150 	divw	dehl,lxoff(iy)		;FD ED DA 22 11
   0B55 FD ED CA 00 00     5154 	divw	dehl,(ix)		;FD ED CA 00 00
   0B5A FD ED DA 00 00     5155 	divw	dehl,(iy)		;FD ED DA 00 00
   0B5F DD ED CA           5156 	divw	dehl,(hl)		;DD ED CA
   0B62 DD ED FA 55 00     5228 	divw	dehl,pcr_ofst(pc)	;DD ED FA 55 00
   0B67 DD ED FA 55 00     5232 	divw	dehl,(pc+pcr_ofst)	;DD ED FA 55 00
   0B6C DD ED FA 55 00     5236 	divw	dehl,[pcr_ofst]		;DD ED FA 55 00
   0B71 DD ED FA 50 00     5240 	divw	dehl,[.+offsetc]	;DD ED FA 50 00
                           5241 
                           5242 ;*******************************************************************
                           5243 ;	DJNZ	
                           5244 ;*******************************************************************
                           5245 	.z80
                           5246 	;***********************************************************
                           5247 	; decrement b and jump relative if b # 0
   0B76 10 10              5248 	djnz	.+0x12			;10 10
                           5249 
                           5250 ;*******************************************************************
                           5251 ;	EI	
                           5252 ;*******************************************************************
                           5253 	;***********************************************************
                           5254 	; enable interrupts
                           5255 	.z80
   0B78 FB                 5256 	ei				;FB
                           5257 	.z180
   0B79 FB                 5258 	ei				;FB
                           5259 	;***********************************************************
                           5260 	;  p. 5-44
                           5261 	.z280p
   0B7A FB                 5262 	ei				;FB
   0B7B ED 7F 37           5263 	ei	#0x37			;ED 7F 37
                           5264 
                           5265 ;*******************************************************************
                           5266 ;	EX	
                           5267 ;		If offset is ommitted 0 is assumed.
                           5268 ;*******************************************************************
                           5269 	;***********************************************************
                           5270 	; exchange location and (sp)
                           5271 	.z80
   0B7E E3                 5272 	ex	(sp),hl			;E3
   0B7F DD E3              5273 	ex	(sp),ix			;DD E3
   0B81 FD E3              5274 	ex	(sp),iy			;FD E3
                           5275 	;***********************************************************
                           5276 	; exchange af and af'
   0B83 08                 5277 	ex	af,af'			;08
                           5278 	;***********************************************************
                           5279 	; exchange de and hl
   0B84 EB                 5280 	ex	de,hl			;EB
                           5281 	;***********************************************************
                           5282 	;  p. 5-47
                           5283 	.z280
   0B85 ED EF              5284 	ex	h,l			;ED EF
                           5285 	;  p. 5-48
   0B87 DD EB              5286 	ex	ix,hl			;DD EB
   0B89 FD EB              5287 	ex	iy,hl			;FD EB
   0B8B FD EB              5288 	ex	hl,iy			;FD EB
   0B8D DD EB              5289 	ex	hl,ix			;DD EB
                           5290 	; p. 5-49
   0B8F ED 3F              5291 	ex	a,a			;ED 3F
   0B91 ED 07              5292 	ex	a,b			;ED 07
   0B93 ED 0F              5293 	ex	a,c			;ED 0F
   0B95 ED 17              5294 	ex	a,d			;ED 17
   0B97 ED 1F              5295 	ex	a,e			;ED 1F
   0B99 ED 27              5296 	ex	a,h			;ED 27
   0B9B ED 2F              5297 	ex	a,l			;ED 2F
   0B9D DD ED 27           5298 	ex	a,ixh			;DD ED 27
   0BA0 DD ED 2F           5299 	ex	a,ixl			;DD ED 2F
   0BA3 FD ED 27           5300 	ex	a,iyh			;FD ED 27
   0BA6 FD ED 2F           5301 	ex	a,iyl			;FD ED 2F
   0BA9 ED 37              5302 	ex	a,(hl)			;ED 37
   0BAB DD ED 3F 44 33     5348 	ex	a,(daddr)		;DD ED 3F 44 33
   0BB0 DD ED 37 55        5359 	ex	a,offset(ix)		;DD ED 37 55
   0BB4 DD ED 37 55        5360 	ex	a,(ix+offset)		;DD ED 37 55
   0BB8 FD ED 37 55        5361 	ex	a,offset(iy)		;FD ED 37 55
   0BBC FD ED 37 55        5362 	ex	a,(iy+offset)		;FD ED 37 55
   0BC0 FD ED 1F 55 00     5366 	ex	a,offset(hl)		;FD ED 1F 55 00
   0BC5 FD ED 1F 55 00     5367 	ex	a,(hl+offset)		;FD ED 1F 55 00
   0BCA DD ED 07 55 00     5368 	ex	a,offset(sp)		;DD ED 07 55 00
   0BCF DD ED 07 55 00     5369 	ex	a,(sp+offset)		;DD ED 07 55 00
   0BD4 FD ED 0F 22 11     5370 	ex	a,lxoff(ix)		;FD ED 0F 22 11
   0BD9 FD ED 0F 22 11     5371 	ex	a,(ix+lxoff)		;FD ED 0F 22 11
   0BDE FD ED 17 22 11     5372 	ex	a,lxoff(iy)		;FD ED 17 22 11
   0BE3 FD ED 17 22 11     5373 	ex	a,(iy+lxoff)		;FD ED 17 22 11
   0BE8 FD ED 1F 22 11     5374 	ex	a,lxoff(hl)		;FD ED 1F 22 11
   0BED FD ED 1F 22 11     5375 	ex	a,(hl+lxoff)		;FD ED 1F 22 11
   0BF2 DD ED 07 22 11     5376 	ex	a,lxoff(sp)		;DD ED 07 22 11
   0BF7 DD ED 07 22 11     5377 	ex	a,(sp+lxoff)		;DD ED 07 22 11
   0BFC DD ED 37 00        5381 	ex	a,(ix)			;DD ED 37 00
   0C00 FD ED 37 00        5382 	ex	a,(iy)			;FD ED 37 00
                           5383 ;	ex	a,(hl)			;FD ED 1F 00 00
   0C04 FD ED 07 55 00     5455 	ex	a,pcr_ofst(pc)		;FD ED 07 55 00
   0C09 FD ED 07 55 00     5459 	ex	a,(pc+pcr_ofst)		;FD ED 07 55 00
   0C0E FD ED 07 55 00     5463 	ex	a,[pcr_ofst]		;FD ED 07 55 00
   0C13 FD ED 07 D9 EE     5467 	ex	a,[.-lxofc]		;FD ED 07 D9 EE
   0C18 DD ED 0F           5468 	ex	a,(hl+ix)		;DD ED 0F
   0C1B DD ED 17           5469 	ex	a,(hl+iy)		;DD ED 17
   0C1E DD ED 1F           5470 	ex	a,(ix+iy)		;DD ED 1F
                           5471 
                           5472 ;*******************************************************************
                           5473 ;	EXTS	
                           5474 ;*******************************************************************
                           5475 	;***********************************************************
                           5476 	;  extend sign  a->hl,   hl->dehl
                           5477 	;  pp. 5-50, 5-51
   0C21 ED 64              5478 	exts				;ED 64
   0C23 ED 64              5479 	exts	a			;ED 64
   0C25 ED 6C              5480 	exts	hl			;ED 6C
                           5481 
                           5482 ;*******************************************************************
                           5483 ;	EXX	
                           5484 ;*******************************************************************
                           5485 	;***********************************************************
                           5486 	; exchange:
                           5487 	;	bc <-> bc'
                           5488 	;	de <-> de'
                           5489 	;	hl <-> hl'
                           5490 	.z80
   0C27 D9                 5491 	exx				;D9
                           5492 
                           5493 ;*******************************************************************
                           5494 ;	HALT	
                           5495 ;*******************************************************************
                           5496 	;***********************************************************
                           5497 	; halt (wait for interrupt or reset)
                           5498 	.z80
   0C28 76                 5499 	halt				;76
                           5500 
                           5501 ;*******************************************************************
                           5502 ;	IM	
                           5503 ;*******************************************************************
                           5504 	;***********************************************************
                           5505 	; set interrupt mode
                           5506 	.z80
   0C29 ED 46              5507 	im	0			;ED 46
   0C2B ED 56              5508 	im	1			;ED 56
   0C2D ED 5E              5509 	im	2			;ED 5E
                           5510 	.z280p
   0C2F ED 4E              5511 	im	3			;ED 4E
                           5512 
                           5513 ;*******************************************************************
                           5514 ;	IN and INW	
                           5515 ;*******************************************************************
                           5516 	;***********************************************************
                           5517 	; load 'a' with input from device n
                           5518 	.z80
   0C31 DB 20              5532 	in	a,(n)			;DB 20
   0C33 DB 33              5536 	in	a,0x33			;DB 33
                           5537 	;***********************************************************
                           5538 	; load register with input from (c)
   0C35 ED 78              5539 	in	a,(c)			;ED 78
   0C37 ED 40              5540 	in	b,(c)			;ED 40
   0C39 ED 48              5541 	in	c,(c)			;ED 48
   0C3B ED 50              5542 	in	d,(c)			;ED 50
   0C3D ED 58              5543 	in	e,(c)			;ED 58
   0C3F ED 60              5544 	in	h,(c)			;ED 60
   0C41 ED 68              5545 	in	l,(c)			;ED 68
                           5546 	;***********************************************************
                           5547 	;  p. 5-55
                           5548 	.z280
   0C43 DD ED 60           5549 	in	ixh,(c)			;DD ED 60
   0C46 DD ED 68           5550 	in	ixl,(c)			;DD ED 68
   0C49 FD ED 60           5551 	in	iyh,(c)			;FD ED 60
   0C4C FD ED 68           5552 	in	iyl,(c)			;FD ED 68
   0C4F DD ED 78 44 33     5598 	in	(daddr),(c)		;DD ED 78 44 33
   0C54 FD ED 48 55 00     5599 	in	offset(ix),(c)		;FD ED 48 55 00
   0C59 FD ED 48 55 00     5600 	in	(ix+offset),(c)		;FD ED 48 55 00
   0C5E FD ED 50 55 00     5601 	in	offset(iy),(c)		;FD ED 50 55 00
   0C63 FD ED 50 55 00     5602 	in	(iy+offset),(c)		;FD ED 50 55 00
   0C68 FD ED 58 55 00     5603 	in	offset(hl),(c)		;FD ED 58 55 00
   0C6D FD ED 58 55 00     5604 	in	(hl+offset),(c)		;FD ED 58 55 00
   0C72 DD ED 40 55 00     5605 	in	offset(sp),(c)		;DD ED 40 55 00
   0C77 DD ED 40 55 00     5606 	in	(sp+offset),(c)		;DD ED 40 55 00
   0C7C FD ED 48 22 11     5607 	in	lxoff(ix),(c)		;FD ED 48 22 11
   0C81 FD ED 48 22 11     5608 	in	(ix+lxoff),(c)		;FD ED 48 22 11
   0C86 FD ED 50 22 11     5609 	in	lxoff(iy),(c)		;FD ED 50 22 11
   0C8B FD ED 50 22 11     5610 	in	(iy+lxoff),(c)		;FD ED 50 22 11
   0C90 FD ED 58 22 11     5611 	in	lxoff(hl),(c)		;FD ED 58 22 11
   0C95 FD ED 58 22 11     5612 	in	(hl+lxoff),(c)		;FD ED 58 22 11
   0C9A DD ED 40 22 11     5613 	in	lxoff(sp),(c)		;DD ED 40 22 11
   0C9F DD ED 40 22 11     5614 	in	(sp+lxoff),(c)		;DD ED 40 22 11
   0CA4 FD ED 40 55 00     5689 	in	pcr_ofst(pc),(c)	;FD ED 40 55 00
   0CA9 FD ED 40 55 00     5693 	in	(pc+pcr_ofst),(c)	;FD ED 40 55 00
   0CAE FD ED 40 55 00     5697 	in	[pcr_ofst],(c)		;FD ED 40 55 00
   0CB3 FD ED 40 50 00     5701 	in	[.+offsetc],(c)		;FD ED 40 50 00
   0CB8 DD ED 48           5702 	in	(ix+hl),(c)		;DD ED 48
   0CBB DD ED 50           5703 	in	(hl+iy),(c)		;DD ED 50
   0CBE DD ED 58           5704 	in	(iy+ix),(c)		;DD ED 58
                           5705 	;***********************************************************
                           5706 	;  p. 5-65
   0CC1 ED B7              5707 	in	hl,(c)			;ED B7
   0CC3 ED B7              5708 	inw	hl,(c)			;ED B7
                           5709 
                           5710 ;*******************************************************************
                           5711 ;	INC	
                           5712 ;		If offset is ommitted 0 is assumed.
                           5713 ;*******************************************************************
                           5714 	;***********************************************************
                           5715 	; increment operand
                           5716 	.z80
   0CC5 34                 5717 	inc	(hl)			;34
   0CC6 DD 34 55           5737 	inc	offset(ix)		;DD 34 55
   0CC9 DD 34 55           5738 	inc	(ix+offset)		;DD 34 55
   0CCC FD 34 55           5739 	inc	offset(iy)		;FD 34 55
   0CCF FD 34 55           5740 	inc	(iy+offset)		;FD 34 55
   0CD2 3C                 5744 	inc	a			;3C
   0CD3 04                 5745 	inc	b			;04
   0CD4 03                 5746 	inc	bc			;03
   0CD5 0C                 5747 	inc	c			;0C
   0CD6 14                 5748 	inc	d			;14
   0CD7 13                 5749 	inc	de			;13
   0CD8 1C                 5750 	inc	e			;1C
   0CD9 24                 5751 	inc	h			;24
   0CDA 23                 5752 	inc	hl			;23
   0CDB DD 23              5753 	inc	ix			;DD 23
   0CDD FD 23              5754 	inc	iy			;FD 23
   0CDF 2C                 5755 	inc	l			;2C
   0CE0 33                 5756 	inc	sp			;33
                           5757 
   0CE1 03                 5758 	incw	bc			;03
   0CE2 13                 5759 	incw	de			;13
   0CE3 23                 5760 	incw	hl			;23
   0CE4 33                 5761 	incw	sp			;33
                           5762 
                           5763 	;***********************************************************
                           5764 	; increment operand
                           5765 	;  p. 5-57
                           5766 	.z280
   0CE5 DD 24              5767 	inc	ixh			;DD 24
   0CE7 DD 2C              5768 	inc	ixl			;DD 2C
   0CE9 FD 24              5769 	inc	iyh			;FD 24
   0CEB FD 2C              5770 	inc 	iyl			;FD 2C
   0CED DD 3C 44 33        5816 	inc	(daddr)			;DD 3C 44 33
   0CF1 DD 34 55           5827 	inc	offset(ix)		;DD 34 55
   0CF4 DD 34 55           5828 	inc	(ix+offset)		;DD 34 55
   0CF7 FD 34 55           5829 	inc	offset(iy)		;FD 34 55
   0CFA FD 34 55           5830 	inc	(iy+offset)		;FD 34 55
   0CFD FD 1C 55 00        5834 	inc	offset(hl)		;FD 1C 55 00
   0D01 FD 1C 55 00        5835 	inc	(hl+offset)		;FD 1C 55 00
   0D05 DD 04 55 00        5836 	inc	offset(sp)		;DD 04 55 00
   0D09 DD 04 55 00        5837 	inc	(sp+offset)		;DD 04 55 00
   0D0D FD 0C 22 11        5838 	inc	lxoff(ix)		;FD 0C 22 11
   0D11 FD 0C 22 11        5839 	inc	(ix+lxoff)		;FD 0C 22 11
   0D15 FD 14 22 11        5840 	inc	lxoff(iy)		;FD 14 22 11
   0D19 FD 14 22 11        5841 	inc	(iy+lxoff)		;FD 14 22 11
   0D1D FD 1C 22 11        5842 	inc	lxoff(hl)		;FD 1C 22 11
   0D21 FD 1C 22 11        5843 	inc	(hl+lxoff)		;FD 1C 22 11
   0D25 DD 04 22 11        5844 	inc	lxoff(sp)		;DD 04 22 11
   0D29 DD 04 22 11        5845 	inc	(sp+lxoff)		;DD 04 22 11
   0D2D FD 04 55 00        5920 	inc	pcr_ofst(pc)		;FD 04 55 00
   0D31 FD 04 55 00        5924 	inc	(pc+pcr_ofst)		;FD 04 55 00
   0D35 FD 04 55 00        5928 	inc	[pcr_ofst]		;FD 04 55 00
   0D39 FD 04 51 00        5932 	inc	[.+offsetc]		;FD 04 51 00
   0D3D DD 0C              5933 	inc	(hl+ix)			;DD 0C
   0D3F DD 14              5934 	inc	(hl+iy)			;DD 14
   0D41 DD 1C              5935 	inc	(ix+iy)			;DD 1C
                           5936 
                           5937 ;*******************************************************************
                           5938 ;	INCW	
                           5939 ;		If offset is ommitted 0 is assumed.
                           5940 ;*******************************************************************
                           5941 	;***********************************************************
                           5942 	; increment word operand
   0D43 03                 5943 	incw	bc			;03
   0D44 13                 5944 	incw	de			;13
   0D45 23                 5945 	incw	hl			;23
   0D46 33                 5946 	incw	sp			;33
   0D47 DD 23              5947 	incw	ix			;DD 23
   0D49 FD 23              5948 	incw	iy			;FD 23
                           5949 
   0D4B DD 03              5950 	incw	(hl)			;DD 03
   0D4D DD 13 44 33        5972 	incw	(daddr)			;DD 13 44 33
   0D51 FD 03 55 00        5973 	incw	offset(ix)		;FD 03 55 00
   0D55 FD 03 55 00        5974 	incw	(ix+offset)		;FD 03 55 00
   0D59 FD 13 22 11        5975 	incw	lxoff(iy)		;FD 13 22 11
   0D5D FD 13 22 11        5976 	incw	(iy+lxoff)		;FD 13 22 11
   0D61 DD 33 34 12        6051 	incw	pcr_ofst(pc)		;DD 33 34 12
   0D65 DD 33 34 12        6055 	incw	(pc+pcr_ofst)		;DD 33 34 12
   0D69 DD 33 34 12        6059 	incw	[pcr_ofst]		;DD 33 34 12
   0D6D DD 33 30 12        6063 	incw	[.+raofc]		;DD 33 30 12
                           6064 
                           6065 ;*******************************************************************
                           6066 ;	IND	
                           6067 ;*******************************************************************
                           6068 	;***********************************************************
                           6069 	; load location (hl) with input
                           6070 	; from port (c)
                           6071 	; decrement 'hl' and 'b'
                           6072 	.z80
   0D71 ED AA              6073 	ind				;ED AA
                           6074 
                           6075 ;*******************************************************************
                           6076 ;	INDR	
                           6077 ;*******************************************************************
                           6078 	;***********************************************************
                           6079 	; load location (hl) with input
                           6080 	; from port (c)
                           6081 	; decrement 'hl' and 'b'
                           6082 	; repeat until 'b' = 0
                           6083 	.z80
   0D73 ED BA              6084 	indr				;ED BA
                           6085 
                           6086 ;*******************************************************************
                           6087 ;	INI	
                           6088 ;*******************************************************************
                           6089 	;***********************************************************
                           6090 	; load location (hl) with input
                           6091 	; from port (c)
                           6092 	; increment 'hl' and decrement 'b'
                           6093 	.z80
   0D75 ED A2              6094 	ini				;ED A2
                           6095 
                           6096 ;*******************************************************************
                           6097 ;	INIR	
                           6098 ;*******************************************************************
                           6099 	;***********************************************************
                           6100 	; load location (hl) with input
                           6101 	; from port (c)
                           6102 	; increment 'hl' and decrement 'b'
                           6103 	; repeat until 'b' = 0
                           6104 	.z80
   0D77 ED B2              6105 	inir				;ED B2
                           6106 
                           6107 ;*******************************************************************
                           6108 ;	INDW, INDR, INIW, and INIRW	
                           6109 ;*******************************************************************
                           6110 	;***********************************************************
                           6111 	.z280
   0D79 ED 8A              6112 jmp1:	indw				;ED 8A
   0D7B ED 9A              6113 	indrw				;ED 9A
   0D7D ED 82              6114 	iniw				;ED 82
   0D7F ED 92              6115 	inirw				;ED 92
                           6116 
                           6117 ;*******************************************************************
                           6118 ;	JAF	
                           6119 ;*******************************************************************
                           6120 	;***********************************************************
                           6121  	; jump on auxiliary accumulator/flag (AF)
                           6122 	;  p. 5-66
   0D81 DD 28 F5           6123 	jaf	jmp1			;DD 28 F5
                           6124 
                           6125 ;*******************************************************************
                           6126 ;	JAR	
                           6127 ;*******************************************************************
                           6128 	;***********************************************************
                           6129 	; jump on auxiliary register set
                           6130 	;  p. 5-67
                           6131 	.z280
   0D84 DD 20 F2           6132 	jar	jmp1			;DD 20 F2
                           6133 
                           6134 ;*******************************************************************
                           6135 ;	JP	
                           6136 ;*******************************************************************
                           6137 	;***********************************************************
                           6138 	; unconditional jump to location nn
                           6139 	.z80
   0D87 E9                 6140 	jp	(hl)			;E9
   0D88 DD E9              6141 	jp	(ix)			;DD E9
   0D8A FD E9              6142 	jp	(iy)			;FD E9
                           6143 	;***********************************************************
                           6144 	; jump to location if condition is true
   0D8C C3 84 05           6174 	jp	nn			;C3 84 05
   0D8F DA 84 05           6175 	jp	C,nn			;DA 84 05
   0D92 FA 84 05           6176 	jp	M,nn			;FA 84 05
   0D95 D2 84 05           6177 	jp	NC,nn			;D2 84 05
   0D98 C2 84 05           6178 	jp	NZ,nn			;C2 84 05
   0D9B F2 84 05           6179 	jp	P,nn			;F2 84 05
   0D9E EA 84 05           6180 	jp	PE,nn			;EA 84 05
   0DA1 E2 84 05           6181 	jp	PO,nn			;E2 84 05
   0DA4 CA 84 05           6182 	jp	Z,nn			;CA 84 05
                           6186 	;***********************************************************
                           6187 	;  p. 5-68
                           6188 	.z280
   0DA7 DD C2              6189 	jp	nz,(hl)			;DD C2
   0DA9 DD CA              6190 	jp	z,(hl)			;DD CA
   0DAB DD D2              6191 	jp	nc,(hl)			;DD D2
   0DAD DD DA              6192 	jp	c,(hl)			;DD DA
   0DAF DD E2              6193 	jp	nv,(hl)			;DD E2
   0DB1 DD EA              6194 	jp	v,(hl)			;DD EA
   0DB3 DD F2              6195 	jp	ns,(hl)			;DD F2
   0DB5 DD FA              6196 	jp	s,(hl)			;DD FA
   0DB7 DD E2              6197 	jp	po,(hl)			;DD E2
   0DB9 DD EA              6198 	jp	pe,(hl)			;DD EA
   0DBB DD F2              6199 	jp	p,(hl)			;DD F2
   0DBD DD FA              6200 	jp	m,(hl)			;DD FA
                           6201 	; long relative jumps
   0DBF FD C3 B6 FF        6202 	jp	[jmp1]			;FD C3 B6 FF
   0DC3 FD C2 B2 FF        6203 	jp	nz,[jmp1]		;FD C2 B2 FF
   0DC7 FD CA AE FF        6204 	jp	z,[jmp1]		;FD CA AE FF
   0DCB FD F2 AA FF        6205 	jp	p,[jmp1]		;FD F2 AA FF
   0DCF FD FA A6 FF        6206 	jp	m,[jmp1]		;FD FA A6 FF
   0DD3 FD C3 55 00        6278 	jp	pcr_ofst(pc)		;FD C3 55 00
   0DD7 FD C3 55 00        6282 	jp	(pc+pcr_ofst)		;FD C3 55 00
   0DDB FD C3 55 00        6286 	jp	[pcr_ofst]		;FD C3 55 00
   0DDF FD C3 51 00        6290 	jp	[.+offsetc]		;FD C3 51 00
                           6291 
                           6292 ;*******************************************************************
                           6293 ;	JR	
                           6294 ;*******************************************************************
                           6295 	;***********************************************************
                           6296 	; unconditional jump relative to PC+e
   0DE3 18 10              6297 	jr	ljr1+0x10		;18 10
                           6298 	.z80
                           6299 	;***********************************************************
                           6300 	; jump relative to PC+e if condition is true
   0DE5 38 10              6301 ljr1:	jr	C,1$+0x10		;38 10
   0DE7 30 10              6302 1$:	jr	NC,2$+0x10		;30 10
   0DE9 20 10              6303 2$:	jr	NZ,3$+0x10		;20 10
   0DEB 28 10              6304 3$:	jr	Z,4$+0x10		;28 10
   0DED                    6305 4$:	
   0DED 18 F6              6306 ljr2:	jr	ljr1			;18 F6
                           6307 
   0DEF 38 FE              6335 jr1:	jr	C, jr1			;38 FE
   0DF1 30 FE              6336 jr2:	jr	NC,jr2			;30 FE
   0DF3 20 FE              6337 jr3:	jr	NZ,jr3			;20 FE
   0DF5 28 FE              6338 jr4:	jr	Z, jr4			;28 FE
                           6342 
                           6343 ;*******************************************************************
                           6344 ;	LD	
                           6345 ;		Leading 'a' operand is optional.
                           6346 ;		If offset is ommitted 0 is assumed.
                           6347 ;*******************************************************************
                           6348 	;***********************************************************
                           6349 	; load source to destination
                           6350 	.z80
   0DF7 7E                 6351 	ld	a,(hl)			;7E
   0DF8 DD 7E 55           6371 	ld	a,offset(ix)		;DD 7E 55
   0DFB DD 7E 55           6372 	ld	a,(ix+offset)		;DD 7E 55
   0DFE FD 7E 55           6373 	ld	a,offset(iy)		;FD 7E 55
   0E01 FD 7E 55           6374 	ld	a,(iy+offset)		;FD 7E 55
   0E04 7F                 6378 	ld	a,a			;7F
   0E05 78                 6379 	ld	a,b			;78
   0E06 79                 6380 	ld	a,c			;79
   0E07 7A                 6381 	ld	a,d			;7A
   0E08 7B                 6382 	ld	a,e			;7B
   0E09 7C                 6383 	ld	a,h			;7C
   0E0A 7D                 6384 	ld	a,l			;7D
   0E0B 3E 20              6400 	ld	a,#n			;3E 20
   0E0D 3E 20              6401 	ld	a, n			;3E 20
   0E0F 46                 6405 	ld	b,(hl)			;46
   0E10 DD 46 55           6425 	ld	b,offset(ix)		;DD 46 55
   0E13 DD 46 55           6426 	ld	b,(ix+offset)		;DD 46 55
   0E16 FD 46 55           6427 	ld	b,offset(iy)		;FD 46 55
   0E19 FD 46 55           6428 	ld	b,(iy+offset)		;FD 46 55
   0E1C 47                 6432 	ld	b,a			;47
   0E1D 40                 6433 	ld	b,b			;40
   0E1E 41                 6434 	ld	b,c			;41
   0E1F 42                 6435 	ld	b,d			;42
   0E20 43                 6436 	ld	b,e			;43
   0E21 44                 6437 	ld	b,h			;44
   0E22 45                 6438 	ld	b,l			;45
   0E23 06 20              6454 	ld	b,#n			;06 20
   0E25 06 20              6455 	ld	b, n			;06 20
   0E27 4E                 6459 	ld	c,(hl)			;4E
   0E28 DD 4E 55           6479 	ld	c,offset(ix)		;DD 4E 55
   0E2B DD 4E 55           6480 	ld	c,(ix+offset)		;DD 4E 55
   0E2E FD 4E 55           6481 	ld	c,offset(iy)		;FD 4E 55
   0E31 FD 4E 55           6482 	ld	c,(iy+offset)		;FD 4E 55
   0E34 4F                 6486 	ld	c,a			;4F
   0E35 48                 6487 	ld	c,b			;48
   0E36 49                 6488 	ld	c,c			;49
   0E37 4A                 6489 	ld	c,d			;4A
   0E38 4B                 6490 	ld	c,e			;4B
   0E39 4C                 6491 	ld	c,h			;4C
   0E3A 4D                 6492 	ld	c,l			;4D
   0E3B 0E 20              6508 	ld	c,#n			;0E 20
   0E3D 0E 20              6509 	ld	c, n			;0E 20
   0E3F 56                 6513 	ld	d,(hl)			;56
   0E40 DD 56 55           6533 	ld	d,offset(ix)		;DD 56 55
   0E43 DD 56 55           6534 	ld	d,(ix+offset)		;DD 56 55
   0E46 FD 56 55           6535 	ld	d,offset(iy)		;FD 56 55
   0E49 FD 56 55           6536 	ld	d,(iy+offset)		;FD 56 55
   0E4C 57                 6540 	ld	d,a			;57
   0E4D 50                 6541 	ld	d,b			;50
   0E4E 51                 6542 	ld	d,c			;51
   0E4F 52                 6543 	ld	d,d			;52
   0E50 53                 6544 	ld	d,e			;53
   0E51 54                 6545 	ld	d,h			;54
   0E52 55                 6546 	ld	d,l			;55
   0E53 16 20              6562 	ld	d,#n			;16 20
   0E55 16 20              6563 	ld	d, n			;16 20
   0E57 5E                 6567 	ld	e,(hl)			;5E
   0E58 DD 5E 55           6587 	ld	e,offset(ix)		;DD 5E 55
   0E5B DD 5E 55           6588 	ld	e,(ix+offset)		;DD 5E 55
   0E5E FD 5E 55           6589 	ld	e,offset(iy)		;FD 5E 55
   0E61 FD 5E 55           6590 	ld	e,(iy+offset)		;FD 5E 55
   0E64 5F                 6594 	ld	e,a			;5F
   0E65 58                 6595 	ld	e,b			;58
   0E66 59                 6596 	ld	e,c			;59
   0E67 5A                 6597 	ld	e,d			;5A
   0E68 5B                 6598 	ld	e,e			;5B
   0E69 5C                 6599 	ld	e,h			;5C
   0E6A 5D                 6600 	ld	e,l			;5D
   0E6B 1E 20              6616 	ld	e,#n			;1E 20
   0E6D 1E 20              6617 	ld	e, n			;1E 20
   0E6F 66                 6621 	ld	h,(hl)			;66
   0E70 DD 66 55           6641 	ld	h,offset(ix)		;DD 66 55
   0E73 DD 66 55           6642 	ld	h,(ix+offset)		;DD 66 55
   0E76 FD 66 55           6643 	ld	h,offset(iy)		;FD 66 55
   0E79 FD 66 55           6644 	ld	h,(iy+offset)		;FD 66 55
   0E7C 67                 6648 	ld	h,a			;67
   0E7D 60                 6649 	ld	h,b			;60
   0E7E 61                 6650 	ld	h,c			;61
   0E7F 62                 6651 	ld	h,d			;62
   0E80 63                 6652 	ld	h,e			;63
   0E81 64                 6653 	ld	h,h			;64
   0E82 65                 6654 	ld	h,l			;65
   0E83 26 20              6670 	ld	h,#n			;26 20
   0E85 26 20              6671 	ld	h, n			;26 20
   0E87 6E                 6675 	ld	l,(hl)			;6E
   0E88 DD 6E 55           6695 	ld	l,offset(ix)		;DD 6E 55
   0E8B DD 6E 55           6696 	ld	l,(ix+offset)		;DD 6E 55
   0E8E FD 6E 55           6697 	ld	l,offset(iy)		;FD 6E 55
   0E91 FD 6E 55           6698 	ld	l,(iy+offset)		;FD 6E 55
   0E94 6F                 6702 	ld	l,a			;6F
   0E95 68                 6703 	ld	l,b			;68
   0E96 69                 6704 	ld	l,c			;69
   0E97 6A                 6705 	ld	l,d			;6A
   0E98 6B                 6706 	ld	l,e			;6B
   0E99 6C                 6707 	ld	l,h			;6C
   0E9A 6D                 6708 	ld	l,l			;6D
   0E9B 2E 20              6724 	ld	l,#n			;2E 20
   0E9D 2E 20              6725 	ld	l, n			;2E 20
                           6729 	;***********************************************************
   0E9F ED 47              6730 	ld	i,a			;ED 47
   0EA1 ED 4F              6731 	ld	r,a			;ED 4F
   0EA3 ED 57              6732 	ld	a,i			;ED 57
   0EA5 ED 5F              6733 	ld	a,r			;ED 5F
                           6734 	;***********************************************************
   0EA7 02                 6735 	ld	(bc),a			;02
   0EA8 12                 6736 	ld	(de),a			;12
   0EA9 0A                 6737 	ld	a,(bc)			;0A
   0EAA 1A                 6738 	ld	a,(de)			;1A
                           6739 	;***********************************************************
   0EAB 77                 6740 	ld	(hl),a			;77
   0EAC 70                 6741 	ld	(hl),b			;70
   0EAD 71                 6742 	ld	(hl),c			;71
   0EAE 72                 6743 	ld	(hl),d			;72
   0EAF 73                 6744 	ld	(hl),e			;73
   0EB0 74                 6745 	ld	(hl),h			;74
   0EB1 75                 6746 	ld	(hl),l			;75
   0EB2 36 20              6762 	ld	(hl),#n			;36 20
   0EB4 36 20              6763 	ld	(hl), n			;36 20
                           6767 	;***********************************************************
   0EB6 DD 77 55           6941 	ld	offset(ix),a		;DD 77 55
   0EB9 DD 70 55           6942 	ld	offset(ix),b		;DD 70 55
   0EBC DD 71 55           6943 	ld	offset(ix),c		;DD 71 55
   0EBF DD 72 55           6944 	ld	offset(ix),d		;DD 72 55
   0EC2 DD 73 55           6945 	ld	offset(ix),e		;DD 73 55
   0EC5 DD 74 55           6946 	ld	offset(ix),h		;DD 74 55
   0EC8 DD 75 55           6947 	ld	offset(ix),l		;DD 75 55
   0ECB DD 36 55 20        6948 	ld	offset(ix),#n		;DD 36 55 20
   0ECF DD 36 55 20        6949 	ld	offset(ix), n		;DD 36 55 20
                           6950 	;***********************************************************
   0ED3 DD 77 55           6951 	ld	(ix+offset),a		;DD 77 55
   0ED6 DD 70 55           6952 	ld	(ix+offset),b		;DD 70 55
   0ED9 DD 71 55           6953 	ld	(ix+offset),c		;DD 71 55
   0EDC DD 72 55           6954 	ld	(ix+offset),d		;DD 72 55
   0EDF DD 73 55           6955 	ld	(ix+offset),e		;DD 73 55
   0EE2 DD 74 55           6956 	ld	(ix+offset),h		;DD 74 55
   0EE5 DD 75 55           6957 	ld	(ix+offset),l		;DD 75 55
   0EE8 DD 36 55 20        6958 	ld	(ix+offset),#n		;DD 36 55 20
   0EEC DD 36 55 20        6959 	ld	(ix+offset), n		;DD 36 55 20
                           6960 	;***********************************************************
   0EF0 FD 77 55           6961 	ld	offset(iy),a		;FD 77 55
   0EF3 FD 70 55           6962 	ld	offset(iy),b		;FD 70 55
   0EF6 FD 71 55           6963 	ld	offset(iy),c		;FD 71 55
   0EF9 FD 72 55           6964 	ld	offset(iy),d		;FD 72 55
   0EFC FD 73 55           6965 	ld	offset(iy),e		;FD 73 55
   0EFF FD 74 55           6966 	ld	offset(iy),h		;FD 74 55
   0F02 FD 75 55           6967 	ld	offset(iy),l		;FD 75 55
   0F05 FD 36 55 20        6968 	ld	offset(iy),#n		;FD 36 55 20
   0F09 FD 36 55 20        6969 	ld	offset(iy), n		;FD 36 55 20
                           6970 	;***********************************************************
   0F0D FD 77 55           6971 	ld	(iy+offset),a		;FD 77 55
   0F10 FD 70 55           6972 	ld	(iy+offset),b		;FD 70 55
   0F13 FD 71 55           6973 	ld	(iy+offset),c		;FD 71 55
   0F16 FD 72 55           6974 	ld	(iy+offset),d		;FD 72 55
   0F19 FD 73 55           6975 	ld	(iy+offset),e		;FD 73 55
   0F1C FD 74 55           6976 	ld	(iy+offset),h		;FD 74 55
   0F1F FD 75 55           6977 	ld	(iy+offset),l		;FD 75 55
   0F22 FD 36 55 20        6978 	ld	(iy+offset),#n		;FD 36 55 20
   0F26 FD 36 55 20        6979 	ld	(iy+offset), n		;FD 36 55 20
                           6980 	;***********************************************************
   0F2A 32 84 05           6981 	ld	(nn),a			;32 84 05
   0F2D ED 43 84 05        6982 	ld	(nn),bc			;ED 43 84 05
   0F31 ED 53 84 05        6983 	ld	(nn),de			;ED 53 84 05
   0F35 22 84 05           6984 	ld	(nn),hl			;22 84 05
   0F38 ED 73 84 05        6985 	ld	(nn),sp			;ED 73 84 05
   0F3C DD 22 84 05        6986 	ld	(nn),ix			;DD 22 84 05
   0F40 FD 22 84 05        6987 	ld	(nn),iy			;FD 22 84 05
                           6988 	;***********************************************************
   0F44 3A 84 05           6989 	ld	a,(nn)			;3A 84 05
   0F47 ED 4B 84 05        6990 	ld	bc,(nn)			;ED 4B 84 05
   0F4B ED 5B 84 05        6991 	ld	de,(nn)			;ED 5B 84 05
   0F4F 2A 84 05           6992 	ld	hl,(nn)			;2A 84 05
   0F52 ED 7B 84 05        6993 	ld	sp,(nn)			;ED 7B 84 05
   0F56 DD 2A 84 05        6994 	ld	ix,(nn)			;DD 2A 84 05
   0F5A FD 2A 84 05        6995 	ld	iy,(nn)			;FD 2A 84 05
                           6996 	;***********************************************************
   0F5E 01 20 00           6997 	ld	bc,#n			;01 20 00
   0F61 01 20 00           6998 	ld	bc, n			;01 20 00
   0F64 11 20 00           6999 	ld	de,#n			;11 20 00
   0F67 11 20 00           7000 	ld	de, n			;11 20 00
   0F6A 21 20 00           7001 	ld	hl,#n			;21 20 00
   0F6D 21 20 00           7002 	ld	hl, n			;21 20 00
   0F70 31 20 00           7003 	ld	sp,#n			;31 20 00
   0F73 31 20 00           7004 	ld	sp, n			;31 20 00
   0F76 DD 21 20 00        7005 	ld	ix,#n			;DD 21 20 00
   0F7A DD 21 20 00        7006 	ld	ix, n			;DD 21 20 00
   0F7E FD 21 20 00        7007 	ld	iy,#n			;FD 21 20 00
   0F82 FD 21 20 00        7008 	ld	iy, n			;FD 21 20 00
                           7009 	;***********************************************************
   0F86 01 84 05           7010 	ld	bc,#nn			;01 84 05
   0F89 01 84 05           7011 	ld	bc, nn			;01 84 05
   0F8C 11 84 05           7012 	ld	de,#nn			;11 84 05
   0F8F 11 84 05           7013 	ld	de, nn			;11 84 05
   0F92 21 84 05           7014 	ld	hl,#nn			;21 84 05
   0F95 21 84 05           7015 	ld	hl, nn			;21 84 05
   0F98 31 84 05           7016 	ld	sp,#nn			;31 84 05
   0F9B 31 84 05           7017 	ld	sp, nn			;31 84 05
   0F9E DD 21 84 05        7018 	ld	ix,#nn			;DD 21 84 05
   0FA2 DD 21 84 05        7019 	ld	ix, nn			;DD 21 84 05
   0FA6 FD 21 84 05        7020 	ld	iy,#nn			;FD 21 84 05
   0FAA FD 21 84 05        7021 	ld	iy, nn			;FD 21 84 05
                           7025 	;***********************************************************
   0FAE F9                 7026 	ld	sp,hl			;F9
   0FAF DD F9              7027 	ld	sp,ix			;DD F9
   0FB1 FD F9              7028 	ld	sp,iy			;FD F9
                           7029 
                           7030 	;***********************************************************
                           7031 	; p. 5-70
                           7032 	.z280
   0FB3 DD 7C              7033 	ld	a,ixh			;DD 7C
   0FB5 DD 7D              7034 	ld	a,ixl			;DD 7D
   0FB7 FD 7C              7035 	ld	a,iyh			;FD 7C
   0FB9 FD 7D              7036 	ld	a,iyl			;FD 7D
   0FBB 3E 20              7084     	ld	a,#n			;3E 20
   0FBD 3A 44 33           7085 	ld	a,(daddr)		;3A 44 33
   0FC0 DD 7E 55           7096 	ld	a,offset(ix)		;DD 7E 55
   0FC3 DD 7E 55           7097 	ld	a,(ix+offset)		;DD 7E 55
   0FC6 FD 7E 55           7098 	ld	a,offset(iy)		;FD 7E 55
   0FC9 FD 7E 55           7099 	ld	a,(iy+offset)		;FD 7E 55
   0FCC FD 7B 55 00        7103 	ld	a,offset(hl)		;FD 7B 55 00
   0FD0 FD 7B 55 00        7104 	ld	a,(hl+offset)		;FD 7B 55 00
   0FD4 DD 78 55 00        7105 	ld	a,offset(sp)		;DD 78 55 00
   0FD8 DD 78 55 00        7106 	ld	a,(sp+offset)		;DD 78 55 00
   0FDC FD 79 22 11        7107 	ld	a,lxoff(ix)		;FD 79 22 11
   0FE0 FD 79 22 11        7108 	ld	a,(ix+lxoff)		;FD 79 22 11
   0FE4 FD 7A 22 11        7109 	ld	a,lxoff(iy)		;FD 7A 22 11
   0FE8 FD 7A 22 11        7110 	ld	a,(iy+lxoff)		;FD 7A 22 11
   0FEC FD 7B 22 11        7111 	ld	a,lxoff(hl)		;FD 7B 22 11
   0FF0 FD 7B 22 11        7112 	ld	a,(hl+lxoff)		;FD 7B 22 11
   0FF4 DD 78 22 11        7113 	ld	a,lxoff(sp)		;DD 78 22 11
   0FF8 DD 78 22 11        7114 	ld	a,(sp+lxoff)		;DD 78 22 11
   0FFC DD 7E 00           7118 	ld	a,(ix)			;DD 7E 00
   0FFF FD 7E 00           7119 	ld	a,(iy)			;FD 7E 00
   1002 7E                 7120 	ld	a,(hl)			;7E
                           7121 ;	ld	a,(hl)			;FD 7B 00 00
   1003 DD 78 00 00        7122 	ld	a,(sp)			;DD 78 00 00
   1007 FD 78 22 11        7194 	ld	a,pcr_ofst(pc)		;FD 78 22 11
   100B FD 78 22 11        7198 	ld	a,(pc+pcr_ofst)		;FD 78 22 11
   100F FD 78 22 11        7202 	ld	a,[pcr_ofst]		;FD 78 22 11
   1013 FD 78 1E 11        7206 	ld	a,[.+lxofc]		;FD 78 1E 11
   1017 DD 79              7207 	ld	a,(hl+ix)		;DD 79
   1019 DD 7A              7208 	ld	a,(hl+iy)		;DD 7A
   101B DD 7B              7209 	ld	a,(ix+iy)		;DD 7B
                           7210 	;***********************************************************
                           7211 	; p. 5-71
                           7212 	.z280
   101D DD 67              7213 	ld	ixh,a			;DD 67
   101F DD 6F              7214 	ld	ixl,a			;DD 6F
   1021 FD 67              7215 	ld	iyh,a			;FD 67
   1023 FD 6F              7216 	ld	iyl,a			;FD 6F
   1025 32 44 33           7262     	ld	(daddr),a		;32 44 33
   1028 DD 77 55           7273 	ld	offset(ix),a		;DD 77 55
   102B DD 77 55           7274 	ld	(ix+offset),a		;DD 77 55
   102E FD 77 55           7275 	ld	offset(iy),a		;FD 77 55
   1031 FD 77 55           7276 	ld	(iy+offset),a		;FD 77 55
   1034 ED 3B 55 00        7280 	ld	offset(hl),a		;ED 3B 55 00
   1038 ED 3B 55 00        7281 	ld	(hl+offset),a		;ED 3B 55 00
   103C ED 03 55 00        7282 	ld	offset(sp),a		;ED 03 55 00
   1040 ED 03 55 00        7283 	ld	(sp+offset),a		;ED 03 55 00
   1044 ED 2B 22 11        7284 	ld	lxoff(ix),a		;ED 2B 22 11
   1048 ED 2B 22 11        7285 	ld	(ix+lxoff),a		;ED 2B 22 11
   104C ED 33 22 11        7286 	ld	lxoff(iy),a		;ED 33 22 11
   1050 ED 33 22 11        7287 	ld	(iy+lxoff),a		;ED 33 22 11
   1054 ED 3B 22 11        7288 	ld	lxoff(hl),a		;ED 3B 22 11
   1058 ED 3B 22 11        7289 	ld	(hl+lxoff),a		;ED 3B 22 11
   105C ED 03 22 11        7290 	ld	lxoff(sp),a		;ED 03 22 11
   1060 ED 03 22 11        7291 	ld	(sp+lxoff),a		;ED 03 22 11
   1064 DD 77 00           7295 	ld	(ix),a			;DD 77 00
   1067 FD 77 00           7296 	ld	(iy),a			;FD 77 00
   106A 77                 7297 	ld	(hl),a			;77
                           7298 ;	ld	(hl),a			;ED 3B 00 00
   106B ED 03 00 00        7299 	ld	(sp),a			;ED 03 00 00
   106F ED 23 22 11        7371 	ld	pcr_ofst(pc),a		;ED 23 22 11
   1073 ED 23 22 11        7375 	ld	(pc+pcr_ofst),a		;ED 23 22 11
   1077 ED 23 22 11        7379 	ld	[pcr_ofst],a		;ED 23 22 11
   107B ED 23 DC FF        7383 	ld	[.-32],a		;ED 23 DC FF
   107F ED 0B              7384 	ld	(hl+ix),a		;ED 0B
   1081 ED 13              7385 	ld	(hl+iy),a		;ED 13
   1083 ED 1B              7386 	ld	(iy+ix),a		;ED 1B
                           7387 	;***********************************************************
                           7388 	; p. 5-73
                           7389 	.z280
   1085 DD 26 20           7449 	ld	ixh,#n			;DD 26 20
   1088 DD 2E 20           7450 	ld	ixl,#n			;DD 2E 20
   108B FD 26 20           7451 	ld	iyh,#n			;FD 26 20
   108E FD 2E 20           7452 	ld	iyl,#n			;FD 2E 20
   1091 DD 3E 44 33 20     7453 	ld	(daddr),#n		;DD 3E 44 33 20
   1096 DD 36 55 20        7464 	ld	offset(ix),#n		;DD 36 55 20
   109A DD 36 55 20        7465 	ld	(ix+offset),#n		;DD 36 55 20
   109E FD 36 55 20        7466 	ld	offset(iy),#n		;FD 36 55 20
   10A2 FD 36 55 20        7467 	ld	(iy+offset),#n		;FD 36 55 20
   10A6 FD 1E 55 00 20     7471 	ld	offset(hl),#n		;FD 1E 55 00 20
   10AB FD 1E 55 00 20     7472 	ld	(hl+offset),#n		;FD 1E 55 00 20
   10B0 DD 06 55 00 20     7473 	ld	offset(sp),#n		;DD 06 55 00 20
   10B5 DD 06 55 00 20     7474 	ld	(sp+offset),#n		;DD 06 55 00 20
   10BA FD 0E 22 11 20     7475 	ld	lxoff(ix),#n		;FD 0E 22 11 20
   10BF FD 0E 22 11 20     7476 	ld	(ix+lxoff),#n		;FD 0E 22 11 20
   10C4 FD 16 22 11 20     7477 	ld	lxoff(iy),#n		;FD 16 22 11 20
   10C9 FD 16 22 11 20     7478 	ld	(iy+lxoff),#n		;FD 16 22 11 20
   10CE FD 1E 22 11 20     7479 	ld	lxoff(hl),#n		;FD 1E 22 11 20
   10D3 FD 1E 22 11 20     7480 	ld	(hl+lxoff),#n		;FD 1E 22 11 20
   10D8 DD 06 22 11 20     7481 	ld	lxoff(sp),#n		;DD 06 22 11 20
   10DD DD 06 22 11 20     7482 	ld	(sp+lxoff),#n		;DD 06 22 11 20
   10E2 DD 0E 20           7483 	ld	(hl+ix),#n		;DD 0E 20
   10E5 DD 16 20           7484 	ld	(hl+iy),#n		;DD 16 20
   10E8 DD 1E 20           7485 	ld	(ix+iy),#n		;DD 1E 20
   10EB FD 06 22 11 20     7560 	ld	pcr_ofst(pc),#n		;FD 06 22 11 20
   10F0 FD 06 22 11 20     7564 	ld	(pc+pcr_ofst),#n	;FD 06 22 11 20
   10F5 FD 06 22 11 20     7568 	ld	[pcr_ofst],#n		;FD 06 22 11 20
   10FA FD 06 1B 00 20     7572 	ld	[.+32],#nc		;FD 06 1B 00 20
                           7573 
                           7574 	;***********************************************************
                           7575 	; p. 5-74
                           7576 	.z280
   10FF DD 7C              7577 	ld	a,ixh			;DD 7C
   1101 FD 7D              7578 	ld	a,iyl			;FD 7D
   1103 DD 44              7579 	ld	b,ixh			;DD 44
   1105 DD 45              7580 	ld	b,ixl			;DD 45
   1107 DD 4C              7581 	ld	c,ixh			;DD 4C
   1109 DD 4D              7582 	ld	c,ixl			;DD 4D
   110B FD 54              7583 	ld	d,iyh			;FD 54
   110D FD 55              7584 	ld	d,iyl			;FD 55
   110F FD 5C              7585 	ld	e,iyh			;FD 5C
   1111 FD 5D              7586 	ld	e,iyl			;FD 5D
   1113 DD 64              7587 	ld	ixh,ixh			;DD 64
   1115 DD 65              7588 	ld	ixh,ixl			;DD 65
   1117 DD 6C              7589 	ld	ixl,ixh			;DD 6C
   1119 DD 6D              7590 	ld	ixl,ixl			;DD 6D
   111B FD 64              7591 	ld	iyh,iyh			;FD 64
   111D FD 65              7592 	ld	iyh,iyl			;FD 65
   111F FD 6C              7593 	ld	iyl,iyh			;FD 6C
   1121 FD 6D              7594 	ld	iyl,iyl			;FD 6D
   1123 62                 7595 	ld	h,d			;62
   1124 6B                 7596 	ld	l,e			;6B
   1125 DD 67              7597 	ld	ixh,a			;DD 67
   1127 DD 6F              7598 	ld	ixl,a			;DD 6F
   1129 FD 67              7599 	ld	iyh,a			;FD 67
   112B FD 6F              7600 	ld	iyl,a			;FD 6F
   112D DD 60              7601 	ld	ixh,b			;DD 60
   112F DD 69              7602 	ld	ixl,c			;DD 69
   1131 FD 62              7603 	ld	iyh,d			;FD 62
   1133 FD 6B              7604 	ld	iyl,e			;FD 6B
                           7605 
                           7606 ;*******************************************************************
                           7607 ;	LDB	
                           7608 ;*******************************************************************
                           7609 	;***********************************************************
                           7610 	; p. 5-74
                           7611 	.z280
   1135 DD 3E 44 33 20     7663 	ldb	(daddr),#n		;DD 3E 44 33 20
   113A DD 36 55 20        7674 	ldb	offset(ix),#n		;DD 36 55 20
   113E DD 36 55 20        7675 	ldb	(ix+offset),#n		;DD 36 55 20
   1142 FD 36 55 20        7676 	ldb	offset(iy),#n		;FD 36 55 20
   1146 FD 36 55 20        7677 	ldb	(iy+offset),#n		;FD 36 55 20
   114A FD 1E 55 00 20     7681 	ldb	offset(hl),#n		;FD 1E 55 00 20
   114F FD 1E 55 00 20     7682 	ldb	(hl+offset),#n		;FD 1E 55 00 20
   1154 DD 06 55 00 20     7683 	ldb	offset(sp),#n		;DD 06 55 00 20
   1159 DD 06 55 00 20     7684 	ldb	(sp+offset),#n		;DD 06 55 00 20
   115E FD 0E 22 11 20     7685 	ldb	lxoff(ix),#n		;FD 0E 22 11 20
   1163 FD 0E 22 11 20     7686 	ldb	(ix+lxoff),#n		;FD 0E 22 11 20
   1168 FD 16 22 11 20     7687 	ldb	lxoff(iy),#n		;FD 16 22 11 20
   116D FD 16 22 11 20     7688 	ldb	(iy+lxoff),#n		;FD 16 22 11 20
   1172 FD 1E 22 11 20     7689 	ldb	lxoff(hl),#n		;FD 1E 22 11 20
   1177 FD 1E 22 11 20     7690 	ldb	(hl+lxoff),#n		;FD 1E 22 11 20
   117C DD 06 22 11 20     7691 	ldb	lxoff(sp),#n		;DD 06 22 11 20
   1181 DD 06 22 11 20     7692 	ldb	(sp+lxoff),#n		;DD 06 22 11 20
   1186 DD 0E 20           7693 	ldb	(hl+ix),#n		;DD 0E 20
   1189 DD 16 20           7694 	ldb	(hl+iy),#n		;DD 16 20
   118C DD 1E 20           7695 	ldb	(ix+iy),#n		;DD 1E 20
   118F FD 06 22 11 20     7770 	ldb	pcr_ofst(pc),#n		;FD 06 22 11 20
   1194 FD 06 22 11 20     7774 	ldb	(pc+pcr_ofst),#n	;FD 06 22 11 20
   1199 FD 06 22 11 20     7778 	ldb	[pcr_ofst],#n		;FD 06 22 11 20
   119E FD 06 1B 00 20     7782 	ldb	[.+32],#nc		;FD 06 1B 00 20
                           7783 
                           7784 ;*******************************************************************
                           7785 ;	LDA
                           7786 ;*******************************************************************
                           7787 	;***********************************************************
                           7788 	; p. 5-76
   11A3 21 44 33           7806 	lda	hl,(daddr)		;21 44 33
   11A6 DD 21 44 33        7807 	lda	ix,(daddr)		;DD 21 44 33
   11AA FD 21 44 33        7808 	lda	iy,(daddr)		;FD 21 44 33
   11AE ED 2A 55 00        7919 	lda	hl,(ix+sxoff)		;ED 2A 55 00
   11B2 ED 2A 22 11        7920 	lda	hl,(ix+lxoff)		;ED 2A 22 11
   11B6 ED 32 55 00        7921 	lda	hl,(iy+sxoff)		;ED 32 55 00
   11BA ED 32 22 11        7922 	lda	hl,(iy+lxoff)		;ED 32 22 11
   11BE ED 3A 55 00        7923 	lda	hl,(hl+sxoff)		;ED 3A 55 00
   11C2 ED 3A 22 11        7924 	lda	hl,(hl+lxoff)		;ED 3A 22 11
   11C6 ED 02 55 00        7925 	lda	hl,(sp+sxoff)		;ED 02 55 00
   11CA ED 02 22 11        7926 	lda	hl,(sp+lxoff)		;ED 02 22 11
   11CE DD ED 2A 55 00     7927 	lda	ix,(ix+sxoff)		;DD ED 2A 55 00
   11D3 DD ED 2A 22 11     7928 	lda	ix,(ix+lxoff)		;DD ED 2A 22 11
   11D8 DD ED 32 55 00     7929 	lda	ix,(iy+sxoff)		;DD ED 32 55 00
   11DD DD ED 32 22 11     7930 	lda	ix,(iy+lxoff)		;DD ED 32 22 11
   11E2 DD ED 3A 55 00     7931 	lda	ix,(hl+sxoff)		;DD ED 3A 55 00
   11E7 DD ED 3A 22 11     7932 	lda	ix,(hl+lxoff)		;DD ED 3A 22 11
   11EC DD ED 02 55 00     7933 	lda	ix,(sp+sxoff)		;DD ED 02 55 00
   11F1 DD ED 02 22 11     7934 	lda	ix,(sp+lxoff)		;DD ED 02 22 11
   11F6 FD ED 2A 55 00     7935 	lda	iy,(ix+sxoff)		;FD ED 2A 55 00
   11FB FD ED 2A 22 11     7936 	lda	iy,(ix+lxoff)		;FD ED 2A 22 11
   1200 FD ED 32 55 00     7937 	lda	iy,(iy+sxoff)		;FD ED 32 55 00
   1205 FD ED 32 22 11     7938 	lda	iy,(iy+lxoff)		;FD ED 32 22 11
   120A FD ED 3A 55 00     7939 	lda	iy,(hl+sxoff)		;FD ED 3A 55 00
   120F FD ED 3A 22 11     7940 	lda	iy,(hl+lxoff)		;FD ED 3A 22 11
   1214 FD ED 02 55 00     7941 	lda	iy,(sp+sxoff)		;FD ED 02 55 00
   1219 FD ED 02 22 11     7942 	lda	iy,(sp+lxoff)		;FD ED 02 22 11
   121E ED 2A 55 00        7943 	lda	hl,sxoff(ix)		;ED 2A 55 00
   1222 ED 2A 22 11        7944 	lda	hl,lxoff(ix)		;ED 2A 22 11
   1226 ED 32 55 00        7945 	lda	hl,sxoff(iy)		;ED 32 55 00
   122A ED 32 22 11        7946 	lda	hl,lxoff(iy)		;ED 32 22 11
   122E ED 3A 55 00        7947 	lda	hl,sxoff(hl)		;ED 3A 55 00
   1232 ED 3A 22 11        7948 	lda	hl,lxoff(hl)		;ED 3A 22 11
   1236 ED 02 55 00        7949 	lda	hl,sxoff(sp)		;ED 02 55 00
   123A ED 02 22 11        7950 	lda	hl,lxoff(sp)		;ED 02 22 11
   123E DD ED 2A 55 00     7951 	lda	ix,sxoff(ix)		;DD ED 2A 55 00
   1243 DD ED 2A 22 11     7952 	lda	ix,lxoff(ix)		;DD ED 2A 22 11
   1248 DD ED 32 55 00     7953 	lda	ix,sxoff(iy)		;DD ED 32 55 00
   124D DD ED 32 22 11     7954 	lda	ix,lxoff(iy)		;DD ED 32 22 11
   1252 DD ED 3A 55 00     7955 	lda	ix,sxoff(hl)		;DD ED 3A 55 00
   1257 DD ED 3A 22 11     7956 	lda	ix,lxoff(hl)		;DD ED 3A 22 11
   125C DD ED 02 55 00     7957 	lda	ix,sxoff(sp)		;DD ED 02 55 00
   1261 DD ED 02 22 11     7958 	lda	ix,lxoff(sp)		;DD ED 02 22 11
   1266 FD ED 2A 55 00     7959 	lda	iy,sxoff(ix)		;FD ED 2A 55 00
   126B FD ED 2A 22 11     7960 	lda	iy,lxoff(ix)		;FD ED 2A 22 11
   1270 FD ED 32 55 00     7961 	lda	iy,sxoff(iy)		;FD ED 32 55 00
   1275 FD ED 32 22 11     7962 	lda	iy,lxoff(iy)		;FD ED 32 22 11
   127A FD ED 3A 55 00     7963 	lda	iy,sxoff(hl)		;FD ED 3A 55 00
   127F FD ED 3A 22 11     7964 	lda	iy,lxoff(hl)		;FD ED 3A 22 11
   1284 FD ED 02 55 00     7965 	lda	iy,sxoff(sp)		;FD ED 02 55 00
   1289 FD ED 02 22 11     7966 	lda	iy,lxoff(sp)		;FD ED 02 22 11
   128E ED 2A 00 00        7970 	lda	hl,(ix)			;ED 2A 00 00
   1292 ED 32 00 00        7971 	lda	hl,(iy)			;ED 32 00 00
   1296 ED 3A 00 00        7972 	lda	hl,(hl)			;ED 3A 00 00
   129A ED 02 00 00        7973 	lda	hl,(sp)			;ED 02 00 00
   129E DD ED 2A 00 00     7974 	lda	ix,(ix)			;DD ED 2A 00 00
   12A3 DD ED 32 00 00     7975 	lda	ix,(iy)			;DD ED 32 00 00
   12A8 DD ED 3A 00 00     7976 	lda	ix,(hl)			;DD ED 3A 00 00
   12AD DD ED 02 00 00     7977 	lda	ix,(sp)			;DD ED 02 00 00
   12B2 FD ED 2A 00 00     7978 	lda	iy,(ix)			;FD ED 2A 00 00
   12B7 FD ED 32 00 00     7979 	lda	iy,(iy)			;FD ED 32 00 00
   12BC FD ED 3A 00 00     7980 	lda	iy,(hl)			;FD ED 3A 00 00
   12C1 FD ED 02 00 00     7981 	lda	iy,(sp)			;FD ED 02 00 00
   12C6 ED 0A              7982 	lda	hl,(ix+hl)		;ED 0A
   12C8 ED 12              7983 	lda	hl,(hl+iy)		;ED 12
   12CA ED 1A              7984 	lda	hl,(ix+iy)		;ED 1A
   12CC DD ED 0A           7985 	lda	ix,(hl+ix)		;DD ED 0A
   12CF DD ED 12           7986 	lda	ix,(hl+iy)		;DD ED 12
   12D2 DD ED 1A           7987 	lda	ix,(ix+iy)		;DD ED 1A
   12D5 FD ED 0A           7988 	lda	iy,(hl+ix)		;FD ED 0A
   12D8 FD ED 12           7989 	lda	iy,(hl+iy)		;FD ED 12
   12DB FD ED 1A           7990 	lda	iy,(ix+iy)		;FD ED 1A
   12DE DD ED 22 22 11     8062 	lda	ix,pcr_ofst(pc)		;DD ED 22 22 11
   12E3 DD ED 22 22 11     8066 	lda	ix,(pc+pcr_ofst)	;DD ED 22 22 11
   12E8 DD ED 22 22 11     8070 	lda	ix,[pcr_ofst]		;DD ED 22 22 11
   12ED DD ED 22 FB FF     8074 	lda	ix,[.]			;DD ED 22 FB FF
   12F2 DD ED 22 1B 00     8075 	lda	ix,[.+nc]		;DD ED 22 1B 00
   12F7 FD ED 22 22 11     8147 	lda	iy,pcr_ofst(pc)		;FD ED 22 22 11
   12FC FD ED 22 22 11     8151 	lda	iy,(pc+pcr_ofst)	;FD ED 22 22 11
   1301 FD ED 22 22 11     8155 	lda	iy,[pcr_ofst]		;FD ED 22 22 11
   1306 FD ED 22 FB FF     8159 	lda	iy,[.]			;FD ED 22 FB FF
   130B FD ED 22 1B 00     8160 	lda	iy,[.+nc]		;FD ED 22 1B 00
   1310 ED 22 22 11        8232 	lda	hl,pcr_ofst(pc)		;ED 22 22 11
   1314 ED 22 22 11        8236 	lda	hl,(pc+pcr_ofst)	;ED 22 22 11
   1318 ED 22 22 11        8240 	lda	hl,[pcr_ofst]		;ED 22 22 11
   131C ED 22 FC FF        8244 	lda	hl,[.]			;ED 22 FC FF
   1320 ED 22 1C 00        8245 	lda	hl,[.+nc]		;ED 22 1C 00
                           8246 
                           8247 ;*******************************************************************
                           8248 ;	LDCTL	
                           8249 ;*******************************************************************
                           8250 	;***********************************************************
                           8251 	;  p. 5-77
                           8252 	.z280p
   1324 ED 66              8253 	ldctl	hl,(c)			;ED 66
   1326 DD ED 66           8254 	ldctl	ix,(c)			;DD ED 66
   1329 FD ED 66           8255 	ldctl	iy,(c)			;FD ED 66
   132C ED 6E              8256 	ldctl	(c),hl			;ED 6E
   132E DD ED 6E           8257 	ldctl	(c),ix			;DD ED 6E
   1331 FD ED 6E           8258 	ldctl	(c),iy			;FD ED 6E
   1334 ED 87              8259 	ldctl	hl,usp			;ED 87
   1336 DD ED 87           8260 	ldctl	ix,usp			;DD ED 87
   1339 FD ED 87           8261 	ldctl	iy,usp			;FD ED 87
   133C ED 8F              8262 	ldctl	usp,hl			;ED 8F
   133E DD ED 8F           8263 	ldctl	usp,ix			;DD ED 8F
   1341 FD ED 8F           8264 	ldctl	usp,iy			;FD ED 8F
                           8265 
                           8266 ;*******************************************************************
                           8267 ;	LDUD	
                           8268 ;		Leading 'a' operand is optional.
                           8269 ;		If offset is ommitted 0 is assumed.
                           8270 ;*******************************************************************
                           8271 	;***********************************************************
                           8272 	;  p. 5-84
                           8273 	.z280p
   1344 ED 86              8315 	ldud	a,(hl)			;ED 86
   1346 DD ED 86 55        8316 	ldud	a,sxoff(ix)		;DD ED 86 55
   134A DD ED 86 55        8317 	ldud	a,(ix+sxoff)		;DD ED 86 55
   134E DD ED 86 00        8318 	ldud	a,(ix)			;DD ED 86 00
   1352 FD ED 86 55        8319 	ldud	a,sxoff(iy)		;FD ED 86 55
   1356 FD ED 86 55        8320 	ldud	a,(iy+sxoff)		;FD ED 86 55
   135A FD ED 86 00        8321 	ldud	a,(iy)			;FD ED 86 00
                           8322 
   135E ED 8E              8323 	ldud	(hl),a			;ED 8E
   1360 DD ED 8E 55        8324 	ldud	sxoff(ix),a		;DD ED 8E 55
   1364 DD ED 8E 55        8325 	ldud	(ix+sxoff),a		;DD ED 8E 55
   1368 DD ED 8E 00        8326 	ldud	(ix),a			;DD ED 8E 00
   136C FD ED 8E 55        8327 	ldud	sxoff(iy),a		;FD ED 8E 55
   1370 FD ED 8E 55        8328 	ldud	(iy+sxoff),a		;FD ED 8E 55
   1374 FD ED 8E 00        8329 	ldud	(iy),a			;FD ED 8E 00
                           8333 
                           8334 ;*******************************************************************
                           8335 ;	LDUP	
                           8336 ;		Leading 'a' operand is optional.
                           8337 ;		If offset is ommitted 0 is assumed.
                           8338 ;*******************************************************************
                           8339 	;***********************************************************
                           8340 	;  p. 5-86
                           8341 	.z280p
   1378 ED 96              8383 	ldup	a,(hl)			;ED 96
   137A DD ED 96 55        8384 	ldup	a,sxoff(ix)		;DD ED 96 55
   137E DD ED 96 55        8385 	ldup	a,(ix+sxoff)		;DD ED 96 55
   1382 DD ED 96 00        8386 	ldup	a,(ix)			;DD ED 96 00
   1386 FD ED 96 55        8387 	ldup	a,sxoff(iy)		;FD ED 96 55
   138A FD ED 96 55        8388 	ldup	a,(iy+sxoff)		;FD ED 96 55
   138E FD ED 96 00        8389 	ldup	a,(iy)			;FD ED 96 00
                           8390 
   1392 ED 9E              8391 	ldup	(hl),a			;ED 9E
   1394 DD ED 9E 55        8392 	ldup	sxoff(ix),a		;DD ED 9E 55
   1398 DD ED 9E 55        8393 	ldup	(ix+sxoff),a		;DD ED 9E 55
   139C DD ED 9E 00        8394 	ldup	(ix),a			;DD ED 9E 00
   13A0 FD ED 9E 55        8395 	ldup	sxoff(iy),a		;FD ED 9E 55
   13A4 FD ED 9E 55        8396 	ldup	(iy+sxoff),a		;FD ED 9E 55
   13A8 FD ED 9E 00        8397 	ldup	(iy),a			;FD ED 9E 00
                           8401 
                           8402 ;*******************************************************************
                           8403 ;	LDW	
                           8404 ;*******************************************************************
                           8405 	;***********************************************************
                           8406 	;  p. 5-88
                           8407 	.z280
   13AC 01 20 00           8451 	ldw	bc,#n			;01 20 00
   13AF 11 20 00           8452 	ldw	de,#n			;11 20 00
   13B2 21 20 00           8453 	ldw	hl,#n			;21 20 00
   13B5 31 20 00           8454 	ldw	sp,#n			;31 20 00
   13B8 DD 21 20 00        8455 	ldw	ix,#n			;DD 21 20 00
   13BC FD 21 20 00        8456 	ldw	iy,#n			;FD 21 20 00
   13C0 DD 01 20 00        8457 	ldw	(hl),#n			;DD 01 20 00
   13C4 DD 11 44 33 20 00  8458 	ldw	(daddr),#n		;DD 11 44 33 20 00
   13CA 01 84 05           8459 	ldw	bc,#nn			;01 84 05
   13CD 11 84 05           8460 	ldw	de,#nn			;11 84 05
   13D0 21 84 05           8461 	ldw	hl,#nn			;21 84 05
   13D3 31 84 05           8462 	ldw	sp,#nn			;31 84 05
   13D6 DD 21 84 05        8463 	ldw	ix,#nn			;DD 21 84 05
   13DA FD 21 84 05        8464 	ldw	iy,#nn			;FD 21 84 05
   13DE DD 01 84 05        8465 	ldw	(hl),#nn		;DD 01 84 05
   13E2 DD 11 44 33 84 05  8466 	ldw	(daddr),#nn		;DD 11 44 33 84 05
   13E8 DD 31 22 11 20 00  8540 	ldw	pcr_ofst(pc),#n		;DD 31 22 11 20 00
   13EE DD 31 22 11 20 00  8544 	ldw	(pc+pcr_ofst),#n	;DD 31 22 11 20 00
   13F4 DD 31 22 11 20 00  8548 	ldw	[pcr_ofst],#n		;DD 31 22 11 20 00
   13FA DD 31 00 00 84 05  8552 	ldw	[.+6],#nnc		;DD 31 00 00 84 05
                           8553 
                           8554 	;***********************************************************
                           8555 	;  p. 5-89     two immediates handled above
                           8556 	.z280
   1400 2A 44 33           8672 	ldw	hl,(daddr)		;2A 44 33
   1403 DD 2A 44 33        8673 	ldw	ix,(daddr)		;DD 2A 44 33
   1407 FD 2A 44 33        8674 	ldw	iy,(daddr)		;FD 2A 44 33
                           8685 ;	ldw	hl,sxoff(ix)		;ED 2C 55 00
                           8686 ;	ldw	hl,(ix+sxoff)		;ED 2C 55 00
                           8687 ;	ldw	hl,sxoff(iy)		;ED 34 55 00
                           8688 ;	ldw	hl,(iy+sxoff)		;ED 34 55 00
   140B DD ED 26 55        8689 	ldw	hl,sxoff(ix)		;DD ED 26 55
   140F DD ED 26 55        8690 	ldw	hl,(ix+sxoff)		;DD ED 26 55
   1413 FD ED 26 55        8691 	ldw	hl,sxoff(iy)		;FD ED 26 55
   1417 FD ED 26 55        8692 	ldw	hl,(iy+sxoff)		;FD ED 26 55
   141B ED 3C 55 00        8696 	ldw	hl,sxoff(hl)		;ED 3C 55 00
   141F ED 3C 55 00        8697 	ldw	hl,(hl+sxoff)		;ED 3C 55 00
   1423 ED 04 55 00        8698 	ldw	hl,sxoff(sp)		;ED 04 55 00
   1427 ED 04 55 00        8699 	ldw	hl,(sp+sxoff)		;ED 04 55 00
   142B ED 2C 22 11        8700 	ldw	hl,lxoff(ix)		;ED 2C 22 11
   142F ED 2C 22 11        8701 	ldw	hl,(ix+lxoff)		;ED 2C 22 11
   1433 ED 34 22 11        8702 	ldw	hl,lxoff(iy)		;ED 34 22 11
   1437 ED 34 22 11        8703 	ldw	hl,(iy+lxoff)		;ED 34 22 11
   143B ED 3C 22 11        8704 	ldw	hl,lxoff(hl)		;ED 3C 22 11
   143F ED 3C 22 11        8705 	ldw	hl,(hl+lxoff)		;ED 3C 22 11
   1443 ED 04 22 11        8706 	ldw	hl,lxoff(sp)		;ED 04 22 11
   1447 ED 04 22 11        8707 	ldw	hl,(sp+lxoff)		;ED 04 22 11
   144B DD ED 2C 55 00     8708 	ldw	ix,sxoff(ix)		;DD ED 2C 55 00
   1450 DD ED 2C 55 00     8709 	ldw	ix,(ix+sxoff)		;DD ED 2C 55 00
   1455 DD ED 34 55 00     8710 	ldw	ix,sxoff(iy)		;DD ED 34 55 00
   145A DD ED 34 55 00     8711 	ldw	ix,(iy+sxoff)		;DD ED 34 55 00
   145F DD ED 3C 55 00     8712 	ldw	ix,sxoff(hl)		;DD ED 3C 55 00
   1464 DD ED 3C 55 00     8713 	ldw	ix,(hl+sxoff)		;DD ED 3C 55 00
   1469 DD ED 04 55 00     8714 	ldw	ix,sxoff(sp)		;DD ED 04 55 00
   146E DD ED 04 55 00     8715 	ldw	ix,(sp+sxoff)		;DD ED 04 55 00
   1473 DD ED 2C 22 11     8716 	ldw	ix,lxoff(ix)		;DD ED 2C 22 11
   1478 DD ED 2C 22 11     8717 	ldw	ix,(ix+lxoff)		;DD ED 2C 22 11
   147D DD ED 34 22 11     8718 	ldw	ix,lxoff(iy)		;DD ED 34 22 11
   1482 DD ED 34 22 11     8719 	ldw	ix,(iy+lxoff)		;DD ED 34 22 11
   1487 DD ED 3C 22 11     8720 	ldw	ix,lxoff(hl)		;DD ED 3C 22 11
   148C DD ED 3C 22 11     8721 	ldw	ix,(hl+lxoff)		;DD ED 3C 22 11
   1491 DD ED 04 22 11     8722 	ldw	ix,lxoff(sp)		;DD ED 04 22 11
   1496 DD ED 04 22 11     8723 	ldw	ix,lxoff(sp)		;DD ED 04 22 11
   149B DD ED 04 22 11     8724 	ldw	ix,(sp+lxoff)		;DD ED 04 22 11
   14A0 FD ED 2C 55 00     8725 	ldw	iy,sxoff(ix)		;FD ED 2C 55 00
   14A5 FD ED 2C 55 00     8726 	ldw	iy,(ix+sxoff)		;FD ED 2C 55 00
   14AA FD ED 34 55 00     8727 	ldw	iy,sxoff(iy)		;FD ED 34 55 00
   14AF FD ED 34 55 00     8728 	ldw	iy,(iy+sxoff)		;FD ED 34 55 00
   14B4 FD ED 3C 55 00     8729 	ldw	iy,sxoff(hl)		;FD ED 3C 55 00
   14B9 FD ED 3C 55 00     8730 	ldw	iy,(hl+sxoff)		;FD ED 3C 55 00
   14BE FD ED 04 55 00     8731 	ldw	iy,sxoff(sp)		;FD ED 04 55 00
   14C3 FD ED 04 55 00     8732 	ldw	iy,(sp+sxoff)		;FD ED 04 55 00
   14C8 FD ED 2C 22 11     8733 	ldw	iy,lxoff(ix)		;FD ED 2C 22 11
   14CD FD ED 2C 22 11     8734 	ldw	iy,(ix+lxoff)		;FD ED 2C 22 11
   14D2 FD ED 34 22 11     8735 	ldw	iy,lxoff(iy)		;FD ED 34 22 11
   14D7 FD ED 34 22 11     8736 	ldw	iy,(iy+lxoff)		;FD ED 34 22 11
   14DC FD ED 3C 22 11     8737 	ldw	iy,lxoff(hl)		;FD ED 3C 22 11
   14E1 FD ED 3C 22 11     8738 	ldw	iy,(hl+lxoff)		;FD ED 3C 22 11
   14E6 FD ED 04 22 11     8739 	ldw	iy,lxoff(sp)		;FD ED 04 22 11
   14EB FD ED 04 22 11     8740 	ldw	iy,(sp+lxoff)		;FD ED 04 22 11
   14F0 ED 04 00 00        8744 	ldw	hl,(sp)			;ED 04 00 00
   14F4 DD ED 04 00 00     8745 	ldw	ix,(sp)			;DD ED 04 00 00
   14F9 FD ED 04 00 00     8746 	ldw	iy,(sp)			;FD ED 04 00 00
   14FE ED 0C              8747 	ldw	hl,(hl+ix)		;ED 0C
   1500 ED 14              8748 	ldw	hl,(hl+iy)		;ED 14
   1502 ED 1C              8749 	ldw	hl,(ix+iy)		;ED 1C
   1504 DD ED 0C           8750 	ldw	ix,(hl+ix)		;DD ED 0C
   1507 DD ED 14           8751 	ldw	ix,(hl+iy)		;DD ED 14
   150A DD ED 1C           8752 	ldw	ix,(ix+iy)		;DD ED 1C
   150D FD ED 0C           8753 	ldw	iy,(hl+ix)		;FD ED 0C
   1510 FD ED 14           8754 	ldw	iy,(hl+iy)		;FD ED 14
   1513 FD ED 1C           8755 	ldw	iy,(ix+iy)		;FD ED 1C
                           8756 
   1516 ED 24 22 11        8828 	ldw	hl,pcr_ofst(pc)		;ED 24 22 11
   151A ED 24 22 11        8832 	ldw	hl,(pc+pcr_ofst)	;ED 24 22 11
   151E ED 24 22 11        8836 	ldw	hl,[pcr_ofst]		;ED 24 22 11
   1522 ED 24 1C 00        8840 	ldw	hl,[.+32]		;ED 24 1C 00
   1526 DD ED 24 22 11     8912 	ldw	ix,pcr_ofst(pc)		;DD ED 24 22 11
   152B DD ED 24 22 11     8916 	ldw	ix,(pc+pcr_ofst)	;DD ED 24 22 11
   1530 DD ED 24 22 11     8920 	ldw	ix,[pcr_ofst]		;DD ED 24 22 11
   1535 DD ED 24 1B 00     8924 	ldw	ix,[.+32]		;DD ED 24 1B 00
   153A FD ED 24 22 11     8996 	ldw	iy,pcr_ofst(pc)		;FD ED 24 22 11
   153F FD ED 24 22 11     9000 	ldw	iy,(pc+pcr_ofst)	;FD ED 24 22 11
   1544 FD ED 24 22 11     9004 	ldw	iy,[pcr_ofst]		;FD ED 24 22 11
   1549 FD ED 24 1B 00     9008 	ldw	iy,[.+32]		;FD ED 24 1B 00
                           9009 	;***********************************************************
                           9010 	;  p. 5-90
                           9011 	.z280
   154E 22 44 33           9125 	ldw	(daddr),hl		;22 44 33
   1551 DD 22 44 33        9126 	ldw	(daddr),ix		;DD 22 44 33
   1555 FD 22 44 33        9127 	ldw	(daddr),iy		;FD 22 44 33
                           9138 ;	ldw	sxoff(ix),hl		;ED 2D 55 00
                           9139 ;	ldw	(ix+sxoff),hl		;ED 2D 55 00
                           9140 ;	ldw	sxoff(iy),hl		;ED 35 55 00
                           9141 ;	ldw	(iy+sxoff),hl		;ED 35 55 00
   1559 DD ED 2E 55        9142 	ldw	sxoff(ix),hl		;DD ED 2E 55
   155D DD ED 2E 55        9143 	ldw	(ix+sxoff),hl		;DD ED 2E 55
   1561 FD ED 2E 55        9144 	ldw	sxoff(iy),hl		;FD ED 2E 55
   1565 FD ED 2E 55        9145 	ldw	(iy+sxoff),hl		;FD ED 2E 55
   1569 ED 3D 55 00        9149 	ldw	sxoff(hl),hl		;ED 3D 55 00
   156D ED 3D 55 00        9150 	ldw	(hl+sxoff),hl		;ED 3D 55 00
   1571 ED 05 55 00        9151 	ldw	sxoff(sp),hl		;ED 05 55 00
   1575 ED 05 55 00        9152 	ldw	(sp+sxoff),hl		;ED 05 55 00
   1579 ED 2D 22 11        9153 	ldw	lxoff(ix),hl		;ED 2D 22 11
   157D ED 2D 22 11        9154 	ldw	(ix+lxoff),hl		;ED 2D 22 11
   1581 ED 35 22 11        9155 	ldw	lxoff(iy),hl		;ED 35 22 11
   1585 ED 35 22 11        9156 	ldw	(iy+lxoff),hl		;ED 35 22 11
   1589 ED 3D 22 11        9157 	ldw	lxoff(hl),hl		;ED 3D 22 11
   158D ED 3D 22 11        9158 	ldw	(hl+lxoff),hl		;ED 3D 22 11
   1591 ED 05 22 11        9159 	ldw	lxoff(sp),hl		;ED 05 22 11
   1595 ED 05 22 11        9160 	ldw	(sp+lxoff),hl		;ED 05 22 11
   1599 DD ED 2D 55 00     9161 	ldw	sxoff(ix),ix		;DD ED 2D 55 00
   159E DD ED 2D 55 00     9162 	ldw	(ix+sxoff),ix		;DD ED 2D 55 00
   15A3 DD ED 35 55 00     9163 	ldw	sxoff(iy),ix		;DD ED 35 55 00
   15A8 DD ED 35 55 00     9164 	ldw	(iy+sxoff),ix		;DD ED 35 55 00
   15AD DD ED 3D 55 00     9165 	ldw	sxoff(hl),ix		;DD ED 3D 55 00
   15B2 DD ED 3D 55 00     9166 	ldw	(hl+sxoff),ix		;DD ED 3D 55 00
   15B7 DD ED 05 55 00     9167 	ldw	sxoff(sp),ix		;DD ED 05 55 00
   15BC DD ED 05 55 00     9168 	ldw	(sp+sxoff),ix		;DD ED 05 55 00
   15C1 DD ED 2D 22 11     9169 	ldw	lxoff(ix),ix		;DD ED 2D 22 11
   15C6 DD ED 2D 22 11     9170 	ldw	(ix+lxoff),ix		;DD ED 2D 22 11
   15CB DD ED 35 22 11     9171 	ldw	lxoff(iy),ix		;DD ED 35 22 11
   15D0 DD ED 35 22 11     9172 	ldw	(iy+lxoff),ix		;DD ED 35 22 11
   15D5 DD ED 3D 22 11     9173 	ldw	lxoff(hl),ix		;DD ED 3D 22 11
   15DA DD ED 3D 22 11     9174 	ldw	(hl+lxoff),ix		;DD ED 3D 22 11
   15DF DD ED 05 22 11     9175 	ldw	lxoff(sp),ix		;DD ED 05 22 11
   15E4 DD ED 05 22 11     9176 	ldw	(sp+lxoff),ix		;DD ED 05 22 11
   15E9 FD ED 2D 55 00     9177 	ldw	sxoff(ix),iy		;FD ED 2D 55 00
   15EE FD ED 2D 55 00     9178 	ldw	(ix+sxoff),iy		;FD ED 2D 55 00
   15F3 FD ED 35 55 00     9179 	ldw	sxoff(iy),iy		;FD ED 35 55 00
   15F8 FD ED 35 55 00     9180 	ldw	(iy+sxoff),iy		;FD ED 35 55 00
   15FD FD ED 3D 55 00     9181 	ldw	sxoff(hl),iy		;FD ED 3D 55 00
   1602 FD ED 3D 55 00     9182 	ldw	(hl+sxoff),iy		;FD ED 3D 55 00
   1607 FD ED 05 55 00     9183 	ldw	sxoff(sp),iy		;FD ED 05 55 00
   160C FD ED 05 55 00     9184 	ldw	(sp+sxoff),iy		;FD ED 05 55 00
   1611 FD ED 2D 22 11     9185 	ldw	lxoff(ix),iy		;FD ED 2D 22 11
   1616 FD ED 2D 22 11     9186 	ldw	(ix+lxoff),iy		;FD ED 2D 22 11
   161B FD ED 35 22 11     9187 	ldw	lxoff(iy),iy		;FD ED 35 22 11
   1620 FD ED 35 22 11     9188 	ldw	(iy+lxoff),iy		;FD ED 35 22 11
   1625 FD ED 3D 22 11     9189 	ldw	lxoff(hl),iy		;FD ED 3D 22 11
   162A FD ED 3D 22 11     9190 	ldw	(hl+lxoff),iy		;FD ED 3D 22 11
   162F FD ED 05 22 11     9191 	ldw	lxoff(sp),iy		;FD ED 05 22 11
   1634 FD ED 05 22 11     9192 	ldw	(sp+lxoff),iy		;FD ED 05 22 11
                           9196 
   1639 ED 05 00 00        9197 	ldw	(sp),hl			;ED 05 00 00
   163D DD ED 05 00 00     9198 	ldw	(sp),ix			;DD ED 05 00 00
   1642 FD ED 05 00 00     9199 	ldw	(sp),iy			;FD ED 05 00 00
   1647 FD ED 0D           9200 	ldw	(hl+ix),iy		;FD ED 0D
   164A FD ED 15           9201 	ldw	(hl+iy),iy		;FD ED 15
   164D FD ED 1D           9202 	ldw	(ix+iy),iy		;FD ED 1D
   1650 DD ED 0D           9203 	ldw	(hl+ix),ix		;DD ED 0D
   1653 DD ED 15           9204 	ldw	(hl+iy),ix		;DD ED 15
   1656 DD ED 1D           9205 	ldw	(ix+iy),ix		;DD ED 1D
   1659 ED 0D              9206 	ldw	(hl+ix),hl		;ED 0D
   165B ED 15              9207 	ldw	(hl+iy),hl		;ED 15
   165D ED 1D              9208 	ldw	(ix+iy),hl		;ED 1D
                           9209 
   165F ED 25 22 11        9281 	ldw	pcr_ofst(pc),hl		;ED 25 22 11
   1663 ED 25 22 11        9285 	ldw	(pc+pcr_ofst),hl	;ED 25 22 11
   1667 ED 25 22 11        9289 	ldw	[pcr_ofst],hl		;ED 25 22 11
   166B ED 25 1C 00        9293 	ldw	[.+32],hl		;ED 25 1C 00
   166F DD ED 25 22 11     9365 	ldw	pcr_ofst(pc),ix		;DD ED 25 22 11
   1674 DD ED 25 22 11     9369 	ldw	(pc+pcr_ofst),ix	;DD ED 25 22 11
   1679 DD ED 25 22 11     9373 	ldw	[pcr_ofst],ix		;DD ED 25 22 11
   167E DD ED 25 1B 00     9377 	ldw	[.+32],ix		;DD ED 25 1B 00
   1683 FD ED 25 22 11     9449 	ldw	pcr_ofst(pc),iy		;FD ED 25 22 11
   1688 FD ED 25 22 11     9453 	ldw	(pc+pcr_ofst),iy	;FD ED 25 22 11
   168D FD ED 25 22 11     9457 	ldw	[pcr_ofst],iy		;FD ED 25 22 11
   1692 FD ED 25 1B 00     9461 	ldw	[.+32],iy		;FD ED 25 1B 00
                           9462 	;***********************************************************
                           9463 	;  p. 5-91
                           9464 	.z280
   1697 01 84 05           9484 	ldw	bc,#nn			;01 84 05
   169A 11 84 05           9485 	ldw	de,#nn			;11 84 05
   169D 21 84 05           9486 	ldw	hl,#nn			;21 84 05
   16A0 31 84 05           9487 	ldw	sp,#nn			;31 84 05
   16A3 ED 06              9491 	ldw	bc,(hl)			;ED 06
   16A5 ED 16              9492 	ldw	de,(hl)			;ED 16
   16A7 ED 26              9493 	ldw	hl,(hl)			;ED 26
   16A9 ED 36              9494 	ldw	sp,(hl)			;ED 36
   16AB DD ED 06 00        9495 	ldw	bc,(ix)			;DD ED 06 00
   16AF DD ED 16 00        9496 	ldw	de,(ix)			;DD ED 16 00
   16B3 DD ED 26 00        9497 	ldw	hl,(ix)			;DD ED 26 00
   16B7 DD ED 36 00        9498 	ldw	sp,(ix)			;DD ED 36 00
   16BB FD ED 06 00        9499 	ldw	bc,(iy)			;FD ED 06 00
   16BF FD ED 16 00        9500 	ldw	de,(iy)			;FD ED 16 00
   16C3 FD ED 26 00        9501 	ldw	hl,(iy)			;FD ED 26 00
   16C7 FD ED 36 00        9502 	ldw	sp,(iy)			;FD ED 36 00
   16CB ED 4B 44 33        9554 	ldw	bc,(daddr)		;ED 4B 44 33
   16CF ED 5B 44 33        9555 	ldw	de,(daddr)		;ED 5B 44 33
   16D3 2A 44 33           9556 	ldw	hl,(daddr)		;2A 44 33
   16D6 ED 7B 44 33        9557 	ldw	sp,(daddr)		;ED 7B 44 33
   16DA DD ED 06 55        9558 	ldw	bc,sxoff(ix)		;DD ED 06 55
   16DE DD ED 06 55        9559 	ldw	bc,(ix+sxoff)		;DD ED 06 55
   16E2 FD ED 06 55        9560 	ldw	bc,sxoff(iy)		;FD ED 06 55
   16E6 FD ED 06 55        9561 	ldw	bc,(iy+sxoff)		;FD ED 06 55
   16EA DD ED 16 55        9562 	ldw	de,sxoff(ix)		;DD ED 16 55
   16EE DD ED 16 55        9563 	ldw	de,(ix+sxoff)		;DD ED 16 55
   16F2 FD ED 16 55        9564 	ldw	de,sxoff(iy)		;FD ED 16 55
   16F6 FD ED 16 55        9565 	ldw	de,(iy+sxoff)		;FD ED 16 55
   16FA DD ED 26 55        9576 	ldw	hl,sxoff(ix)		;DD ED 26 55
   16FE DD ED 26 55        9577 	ldw	hl,(ix+sxoff)		;DD ED 26 55
   1702 FD ED 26 55        9578 	ldw	hl,sxoff(iy)		;FD ED 26 55
   1706 FD ED 26 55        9579 	ldw	hl,(iy+sxoff)		;FD ED 26 55
   170A DD ED 36 55        9583 	ldw	sp,sxoff(ix)		;DD ED 36 55
   170E DD ED 36 55        9584 	ldw	sp,(ix+sxoff)		;DD ED 36 55
   1712 FD ED 36 55        9585 	ldw	sp,sxoff(iy)		;FD ED 36 55
   1716 FD ED 36 55        9586 	ldw	sp,(iy+sxoff)		;FD ED 36 55
   171A ED 0E              9590 	ldw	(hl),bc			;ED 0E
   171C ED 1E              9591 	ldw	(hl),de			;ED 1E
   171E ED 2E              9592 	ldw	(hl),hl			;ED 2E
   1720 ED 3E              9593 	ldw	(hl),sp			;ED 3E
   1722 ED 43 44 33        9645 	ldw	(daddr),bc		;ED 43 44 33
   1726 ED 53 44 33        9646 	ldw	(daddr),de		;ED 53 44 33
   172A ED 73 44 33        9647 	ldw	(daddr),sp		;ED 73 44 33
   172E 22 44 33           9648 	ldw	(daddr),hl		;22 44 33
   1731 DD ED 0E 55        9649 	ldw	sxoff(ix),bc		;DD ED 0E 55
   1735 DD ED 0E 55        9650 	ldw	(ix+sxoff),bc		;DD ED 0E 55
   1739 FD ED 0E 55        9651 	ldw	sxoff(iy),bc		;FD ED 0E 55
   173D FD ED 0E 55        9652 	ldw	(iy+sxoff),bc		;FD ED 0E 55
   1741 DD ED 1E 55        9653 	ldw	sxoff(ix),de		;DD ED 1E 55
   1745 DD ED 1E 55        9654 	ldw	(ix+sxoff),de		;DD ED 1E 55
   1749 FD ED 1E 55        9655 	ldw	sxoff(iy),de		;FD ED 1E 55
   174D FD ED 1E 55        9656 	ldw	(iy+sxoff),de		;FD ED 1E 55
   1751 DD ED 2E 55        9667 	ldw	sxoff(ix),hl		;DD ED 2E 55
   1755 DD ED 2E 55        9668 	ldw	(ix+sxoff),hl		;DD ED 2E 55
   1759 FD ED 2E 55        9669 	ldw	sxoff(iy),hl		;FD ED 2E 55
   175D FD ED 2E 55        9670 	ldw	(iy+sxoff),hl		;FD ED 2E 55
   1761 DD ED 3E 55        9674 	ldw	sxoff(ix),sp		;DD ED 3E 55
   1765 DD ED 3E 55        9675 	ldw	(ix+sxoff),sp		;DD ED 3E 55
   1769 FD ED 3E 55        9676 	ldw	sxoff(iy),sp		;FD ED 3E 55
   176D FD ED 3E 55        9677 	ldw	(iy+sxoff),sp		;FD ED 3E 55
   1771 DD ED 0E 00        9681 	ldw	(ix),bc			;DD ED 0E 00
   1775 DD ED 1E 00        9682 	ldw	(ix),de			;DD ED 1E 00
   1779 DD ED 2E 00        9683 	ldw	(ix),hl			;DD ED 2E 00
   177D DD ED 3E 00        9684 	ldw	(ix),sp			;DD ED 3E 00
   1781 FD ED 0E 00        9685 	ldw	(iy),bc			;FD ED 0E 00
   1785 FD ED 1E 00        9686 	ldw	(iy),de			;FD ED 1E 00
   1789 FD ED 2E 00        9687 	ldw	(iy),hl			;FD ED 2E 00
   178D FD ED 3E 00        9688 	ldw	(iy),sp			;FD ED 3E 00
                           9689 	;***********************************************************
                           9690 	;  p. 5-92
   1791 F9                 9691 	ldw	sp,hl			;F9
   1792 DD F9              9692 	ldw	sp,ix			;DD F9
   1794 FD F9              9693 	ldw	sp,iy			;FD F9
   1796 F9                 9694 	ld	sp,hl			;F9
   1797 DD F9              9695 	ld	sp,ix			;DD F9
   1799 FD F9              9696 	ld	sp,iy			;FD F9
   179B 31 84 05           9712 	ldw	sp,#nn			;31 84 05
   179E 31 84 05           9713 	ld	sp,#nn			;31 84 05
   17A1 ED 36              9717 	ldw	sp,(hl)			;ED 36
   17A3 ED 36              9718 	ld	sp,(hl)			;ED 36
   17A5 ED 3E              9719 	ldw	(hl),sp			;ED 3E
   17A7 ED 3E              9720 	ld	(hl),sp			;ED 3E
   17A9 ED 7B 44 33        9752 	ldw	sp,(daddr)		;ED 7B 44 33
   17AD ED 7B 44 33        9753 	ld	sp,(daddr)		;ED 7B 44 33
   17B1 DD ED 36 55        9754 	ldw	sp,(ix+sxoff)		;DD ED 36 55
   17B5 DD ED 36 55        9755 	ld	sp,(ix+sxoff)		;DD ED 36 55
   17B9 DD ED 36 55        9756 	ldw	sp,sxoff(ix)		;DD ED 36 55
   17BD DD ED 36 55        9757 	ld	sp,sxoff(ix)		;DD ED 36 55
   17C1 FD ED 36 55        9758 	ldw	sp,(iy+sxoff)		;FD ED 36 55
   17C5 FD ED 36 55        9759 	ld	sp,(iy+sxoff)		;FD ED 36 55
   17C9 FD ED 36 55        9760 	ldw	sp,sxoff(iy)		;FD ED 36 55
   17CD FD ED 36 55        9761 	ld	sp,sxoff(iy)		;FD ED 36 55
   17D1 ED 73 44 33        9796 	ldw	(daddr),sp		;ED 73 44 33
   17D5 ED 73 44 33        9797 	ld	(daddr),sp		;ED 73 44 33
   17D9 DD ED 3E 55        9798 	ldw	(ix+sxoff),sp		;DD ED 3E 55
   17DD DD ED 3E 55        9799 	ld	(ix+sxoff),sp		;DD ED 3E 55
   17E1 DD ED 3E 55        9800 	ldw	sxoff(ix),sp		;DD ED 3E 55
   17E5 DD ED 3E 55        9801 	ld	sxoff(ix),sp		;DD ED 3E 55
   17E9 FD ED 3E 55        9802 	ldw	(iy+sxoff),sp		;FD ED 3E 55
   17ED FD ED 3E 55        9803 	ld	(iy+sxoff),sp		;FD ED 3E 55
   17F1 FD ED 3E 55        9804 	ldw	sxoff(iy),sp		;FD ED 3E 55
   17F5 FD ED 3E 55        9805 	ld	sxoff(iy),sp		;FD ED 3E 55
                           9809 
                           9810 ;*******************************************************************
                           9811 ;	LDD	
                           9812 ;*******************************************************************
                           9813 	;***********************************************************
                           9814 	; load location (hl)
                           9815 	; with location (de)
                           9816 	; decrement de, hl
                           9817 	; decrement bc
                           9818 	.z80
   17F9 ED A8              9819 	ldd				;ED A8
                           9820 
                           9821 ;*******************************************************************
                           9822 ;	LDDR	
                           9823 ;*******************************************************************
                           9824 	;***********************************************************
                           9825 	; load location (hl)
                           9826 	; with location (de)
                           9827 	; decrement de, hl
                           9828 	; decrement bc
                           9829 	; repeat until bc = 0
                           9830 	.z80
   17FB ED B8              9831 	lddr				;ED B8
                           9832 
                           9833 ;*******************************************************************
                           9834 ;	LDI	
                           9835 ;*******************************************************************
                           9836 	;***********************************************************
                           9837 	; load location (hl)
                           9838 	; with location (de)
                           9839 	; increment de, hl
                           9840 	; decrement bc
                           9841 	.z80
   17FD ED A0              9842 	ldi				;ED A0
                           9843 
                           9844 ;*******************************************************************
                           9845 ;	LDIR	
                           9846 ;*******************************************************************
                           9847 	;***********************************************************
                           9848 	; load location (hl)
                           9849 	; with location (de)
                           9850 	; increment de, hl
                           9851 	; decrement bc
                           9852 	; repeat until bc = 0
                           9853 	.z80
   17FF ED B0              9854 	ldir				;ED B0
                           9855 
                           9856 ;*******************************************************************
                           9857 ;	MULT
                           9858 ;		Leading 'a' operand is optional.
                           9859 ;		If offset is ommitted 0 is assumed.
                           9860 ;*******************************************************************
                           9861 	;***********************************************************
                           9862 	; multiplication with 'a'
                           9863 	;  p. 5-93
                           9864 	.z280
   1801 ED C0              9865 	mult	a,b			;ED C0
   1803 ED C8              9866 	mult	a,c			;ED C8
   1805 ED D0              9867 	mult	a,d			;ED D0
   1807 ED D8              9868 	mult	a,e			;ED D8
   1809 ED E0              9869 	mult	a,h			;ED E0
   180B ED E8              9870 	mult	a,l			;ED E8
   180D ED F8              9871 	mult	a,a			;ED F8
   180F DD ED E0           9872 	mult	a,ixh			;DD ED E0
   1812 DD ED E8           9873 	mult	a,ixl			;DD ED E8
   1815 FD ED E0           9874 	mult	a,iyh			;FD ED E0
   1818 FD ED E8           9875 	mult	a,iyl			;FD ED E8
   181B FD ED F8 20        9923 	mult	a,#n			;FD ED F8 20
   181F DD ED F8 44 33     9924 	mult	a,(daddr)		;DD ED F8 44 33
   1824 DD ED F0 55        9935 	mult	a,sxoff(ix)		;DD ED F0 55
   1828 DD ED F0 55        9936 	mult	a,(ix+sxoff)		;DD ED F0 55
   182C FD ED F0 55        9937 	mult	a,sxoff(iy)		;FD ED F0 55
   1830 FD ED F0 55        9938 	mult	a,(iy+sxoff)		;FD ED F0 55
   1834 FD ED D8 55 00     9942 	mult	a,sxoff(hl)		;FD ED D8 55 00
   1839 FD ED D8 55 00     9943 	mult	a,(hl+sxoff)		;FD ED D8 55 00
   183E DD ED C0 55 00     9944 	mult	a,sxoff(sp)		;DD ED C0 55 00
   1843 DD ED C0 55 00     9945 	mult	a,(sp+sxoff)		;DD ED C0 55 00
   1848 FD ED C8 22 11     9946 	mult	a,lxoff(ix)		;FD ED C8 22 11
   184D FD ED C8 22 11     9947 	mult	a,(ix+lxoff)		;FD ED C8 22 11
   1852 FD ED D0 22 11     9948 	mult	a,lxoff(iy)		;FD ED D0 22 11
   1857 FD ED D0 22 11     9949 	mult	a,(iy+lxoff)		;FD ED D0 22 11
   185C FD ED D8 22 11     9950 	mult	a,lxoff(hl)		;FD ED D8 22 11
   1861 FD ED D8 22 11     9951 	mult	a,(hl+lxoff)		;FD ED D8 22 11
   1866 DD ED C0 22 11     9952 	mult	a,lxoff(sp)		;DD ED C0 22 11
   186B DD ED C0 22 11     9953 	mult	a,(sp+lxoff)		;DD ED C0 22 11
   1870 DD ED F0 00        9957 	mult	a,(ix)			;DD ED F0 00
   1874 FD ED F0 00        9958 	mult	a,(iy)			;FD ED F0 00
   1878 ED F0              9959 	mult	a,(hl)			;ED F0
   187A FD ED C0 22 11    10031 	mult	a,pcr_ofst(pc)		;FD ED C0 22 11
   187F FD ED C0 22 11    10035 	mult	a,(pc+pcr_ofst)		;FD ED C0 22 11
   1884 FD ED C0 22 11    10039 	mult	a,[pcr_ofst]		;FD ED C0 22 11
   1889 FD ED C0 F6 FF    10043 	mult	a,[.-5]			;FD ED C0 F6 FF
   188E DD ED C8          10044 	mult	a,(hl+ix)		;DD ED C8
   1891 DD ED D0          10045 	mult	a,(hl+iy)		;DD ED D0
   1894 DD ED D8          10046 	mult	a,(ix+iy)		;DD ED D8
                          10047 
                          10048 	;***********************************************************
                          10049 	; multiplication without 'a'
                          10050 	;  p. 5-93
   1897 ED C0             10051 	mult	b			;ED C0
   1899 ED C8             10052 	mult	c			;ED C8
   189B ED D0             10053 	mult	d			;ED D0
   189D ED D8             10054 	mult	e			;ED D8
   189F ED E0             10055 	mult	h			;ED E0
   18A1 ED E8             10056 	mult	l			;ED E8
   18A3 ED F8             10057 	mult	a			;ED F8
   18A5 DD ED E0          10058 	mult	ixh			;DD ED E0
   18A8 DD ED E8          10059 	mult	ixl			;DD ED E8
   18AB FD ED E0          10060 	mult	iyh			;FD ED E0
   18AE FD ED E8          10061 	mult	iyl			;FD ED E8
   18B1 FD ED F8 20       10109 	mult	#n			;FD ED F8 20
   18B5 DD ED F8 44 33    10110 	mult	(daddr)			;DD ED F8 44 33
   18BA DD ED F0 55       10121 	mult	sxoff(ix)		;DD ED F0 55
   18BE DD ED F0 55       10122 	mult	(ix+sxoff)		;DD ED F0 55
   18C2 FD ED F0 55       10123 	mult	sxoff(iy)		;FD ED F0 55
   18C6 FD ED F0 55       10124 	mult	(iy+sxoff)		;FD ED F0 55
   18CA FD ED D8 55 00    10128 	mult	sxoff(hl)		;FD ED D8 55 00
   18CF FD ED D8 55 00    10129 	mult	(hl+sxoff)		;FD ED D8 55 00
   18D4 DD ED C0 55 00    10130 	mult	sxoff(sp)		;DD ED C0 55 00
   18D9 DD ED C0 55 00    10131 	mult	(sp+sxoff)		;DD ED C0 55 00
   18DE FD ED C8 22 11    10132 	mult	lxoff(ix)		;FD ED C8 22 11
   18E3 FD ED C8 22 11    10133 	mult	(ix+lxoff)		;FD ED C8 22 11
   18E8 FD ED D0 22 11    10134 	mult	lxoff(iy)		;FD ED D0 22 11
   18ED FD ED D0 22 11    10135 	mult	(iy+lxoff)		;FD ED D0 22 11
   18F2 FD ED D8 22 11    10136 	mult	lxoff(hl)		;FD ED D8 22 11
   18F7 FD ED D8 22 11    10137 	mult	(hl+lxoff)		;FD ED D8 22 11
   18FC DD ED C0 22 11    10138 	mult	lxoff(sp)		;DD ED C0 22 11
   1901 DD ED C0 22 11    10139 	mult	(sp+lxoff)		;DD ED C0 22 11
   1906 DD ED F0 00       10143 	mult	(ix)			;DD ED F0 00
   190A FD ED F0 00       10144 	mult	(iy)			;FD ED F0 00
   190E ED F0             10145 	mult	(hl)			;ED F0
   1910 FD ED C0 22 11    10217 	mult	pcr_ofst(pc)		;FD ED C0 22 11
   1915 FD ED C0 22 11    10221 	mult	(pc+pcr_ofst)		;FD ED C0 22 11
   191A FD ED C0 22 11    10225 	mult	[pcr_ofst]		;FD ED C0 22 11
   191F FD ED C0 F6 FF    10229 	mult	[.-5]			;FD ED C0 F6 FF
   1924 DD ED C8          10230 	mult	(hl+ix)		;DD ED C8
   1927 DD ED D0          10231 	mult	(hl+iy)		;DD ED D0
   192A DD ED D8          10232 	mult	(ix+iy)		;DD ED D8
                          10233 
                          10234 ;*******************************************************************
                          10235 ;	MULTU	
                          10236 ;		Leading 'a' operand is optional.
                          10237 ;		If offset is ommitted 0 is assumed.
                          10238 ;*******************************************************************
                          10239 	; unsigned multiplication with 'a'
                          10240 	;  p. 5-93
                          10241 	.z280
   192D ED C1             10242 	multu	a,b			;ED C1
   192F ED C9             10243 	multu	a,c			;ED C9
   1931 ED D1             10244 	multu	a,d			;ED D1
   1933 ED D9             10245 	multu	a,e			;ED D9
   1935 ED E1             10246 	multu	a,h			;ED E1
   1937 ED E9             10247 	multu	a,l			;ED E9
   1939 ED F9             10248 	multu	a,a			;ED F9
   193B DD ED E1          10249 	multu	a,ixh			;DD ED E1
   193E DD ED E9          10250 	multu	a,ixl			;DD ED E9
   1941 FD ED E1          10251 	multu	a,iyh			;FD ED E1
   1944 FD ED E9          10252 	multu	a,iyl			;FD ED E9
   1947 FD ED F9 20       10300 	multu	a,#n			;FD ED F9 20
   194B DD ED F9 44 33    10301 	multu	a,(daddr)		;DD ED F9 44 33
   1950 DD ED F1 55       10312 	multu	a,sxoff(ix)		;DD ED F1 55
   1954 DD ED F1 55       10313 	multu	a,(ix+sxoff)		;DD ED F1 55
   1958 FD ED F1 55       10314 	multu	a,sxoff(iy)		;FD ED F1 55
   195C FD ED F1 55       10315 	multu	a,(iy+sxoff)		;FD ED F1 55
   1960 FD ED D9 55 00    10319 	multu	a,sxoff(hl)		;FD ED D9 55 00
   1965 FD ED D9 55 00    10320 	multu	a,(hl+sxoff)		;FD ED D9 55 00
   196A DD ED C1 55 00    10321 	multu	a,sxoff(sp)		;DD ED C1 55 00
   196F DD ED C1 55 00    10322 	multu	a,(sp+sxoff)		;DD ED C1 55 00
   1974 FD ED C9 22 11    10323 	multu	a,lxoff(ix)		;FD ED C9 22 11
   1979 FD ED C9 22 11    10324 	multu	a,(ix+lxoff)		;FD ED C9 22 11
   197E FD ED D1 22 11    10325 	multu	a,lxoff(iy)		;FD ED D1 22 11
   1983 FD ED D1 22 11    10326 	multu	a,(iy+lxoff)		;FD ED D1 22 11
   1988 FD ED D9 22 11    10327 	multu	a,lxoff(hl)		;FD ED D9 22 11
   198D FD ED D9 22 11    10328 	multu	a,(hl+lxoff)		;FD ED D9 22 11
   1992 DD ED C1 22 11    10329 	multu	a,lxoff(sp)		;DD ED C1 22 11
   1997 DD ED C1 22 11    10330 	multu	a,(sp+lxoff)		;DD ED C1 22 11
   199C DD ED F1 00       10334 	multu	a,(ix)			;DD ED F1 00
   19A0 FD ED F1 00       10335 	multu	a,(iy)			;FD ED F1 00
   19A4 ED F1             10336 	multu	a,(hl)			;ED F1
   19A6 DD ED C1 00 00    10337 	multu	a,(sp)			;DD ED C1 00 00
   19AB FD ED C1 22 11    10409 	multu	a,pcr_ofst(pc)		;FD ED C1 22 11
   19B0 FD ED C1 22 11    10413 	multu	a,(pc+pcr_ofst)		;FD ED C1 22 11
   19B5 FD ED C1 22 11    10417 	multu	a,[pcr_ofst]		;FD ED C1 22 11
   19BA FD ED C1 F6 FF    10421 	multu	a,[.-5]			;FD ED C1 F6 FF
   19BF DD ED C9          10422 	multu	a,(hl+ix)		;DD ED C9
   19C2 DD ED D1          10423 	multu	a,(hl+iy)		;DD ED D1
   19C5 DD ED D9          10424 	multu	a,(ix+iy)		;DD ED D9
                          10425 
                          10426 	; unsigned multiplication without 'a'
                          10427 	;  p. 5-93
                          10428 	.z280
   19C8 ED C1             10429 	multu	b			;ED C1
   19CA ED C9             10430 	multu	c			;ED C9
   19CC ED D1             10431 	multu	d			;ED D1
   19CE ED D9             10432 	multu	e			;ED D9
   19D0 ED E1             10433 	multu	h			;ED E1
   19D2 ED E9             10434 	multu	l			;ED E9
   19D4 ED F9             10435 	multu	a			;ED F9
   19D6 DD ED E1          10436 	multu	ixh			;DD ED E1
   19D9 DD ED E9          10437 	multu	ixl			;DD ED E9
   19DC FD ED E1          10438 	multu	iyh			;FD ED E1
   19DF FD ED E9          10439 	multu	iyl			;FD ED E9
   19E2 FD ED F9 20       10487 	multu	#n			;FD ED F9 20
   19E6 DD ED F9 44 33    10488 	multu	(daddr)			;DD ED F9 44 33
   19EB DD ED F1 55       10499 	multu	sxoff(ix)		;DD ED F1 55
   19EF DD ED F1 55       10500 	multu	(ix+sxoff)		;DD ED F1 55
   19F3 FD ED F1 55       10501 	multu	sxoff(iy)		;FD ED F1 55
   19F7 FD ED F1 55       10502 	multu	(iy+sxoff)		;FD ED F1 55
   19FB FD ED D9 55 00    10506 	multu	sxoff(hl)		;FD ED D9 55 00
   1A00 FD ED D9 55 00    10507 	multu	(hl+sxoff)		;FD ED D9 55 00
   1A05 DD ED C1 55 00    10508 	multu	sxoff(sp)		;DD ED C1 55 00
   1A0A DD ED C1 55 00    10509 	multu	(sp+sxoff)		;DD ED C1 55 00
   1A0F FD ED C9 22 11    10510 	multu	lxoff(ix)		;FD ED C9 22 11
   1A14 FD ED C9 22 11    10511 	multu	(ix+lxoff)		;FD ED C9 22 11
   1A19 FD ED D1 22 11    10512 	multu	lxoff(iy)		;FD ED D1 22 11
   1A1E FD ED D1 22 11    10513 	multu	(iy+lxoff)		;FD ED D1 22 11
   1A23 FD ED D9 22 11    10514 	multu	lxoff(hl)		;FD ED D9 22 11
   1A28 FD ED D9 22 11    10515 	multu	(hl+lxoff)		;FD ED D9 22 11
   1A2D DD ED C1 22 11    10516 	multu	lxoff(sp)		;DD ED C1 22 11
   1A32 DD ED C1 22 11    10517 	multu	(sp+lxoff)		;DD ED C1 22 11
   1A37 DD ED F1 00       10521 	multu	(ix)			;DD ED F1 00
   1A3B FD ED F1 00       10522 	multu	(iy)			;FD ED F1 00
   1A3F ED F1             10523 	multu	(hl)			;ED F1
   1A41 DD ED C1 00 00    10524 	multu	(sp)			;DD ED C1 00 00
   1A46 FD ED C1 22 11    10596 	multu	pcr_ofst(pc)		;FD ED C1 22 11
   1A4B FD ED C1 22 11    10600 	multu	(pc+pcr_ofst)		;FD ED C1 22 11
   1A50 FD ED C1 22 11    10604 	multu	[pcr_ofst]		;FD ED C1 22 11
   1A55 FD ED C1 F6 FF    10608 	multu	[.-5]			;FD ED C1 F6 FF
   1A5A DD ED C9          10609 	multu	(hl+ix)			;DD ED C9
   1A5D DD ED D1          10610 	multu	(hl+iy)			;DD ED D1
   1A60 DD ED D9          10611 	multu	(ix+iy)			;DD ED D9
                          10612 
                          10613 ;*******************************************************************
                          10614 ;	MULTUW	
                          10615 ;*******************************************************************
                          10616 	; unsigned word multiplication
                          10617 	;  p. 5-93
                          10618 	.z280
   1A63 ED C3             10619 	multuw	hl,bc			;ED C3
   1A65 ED D3             10620 	multuw	hl,de			;ED D3
   1A67 ED E3             10621 	multuw	hl,hl			;ED E3
   1A69 ED F3             10622 	multuw	hl,sp			;ED F3
   1A6B DD ED E3          10623 	multuw	hl,ix			;DD ED E3
   1A6E FD ED E3          10624 	multuw	hl,iy			;FD ED E3
   1A71 FD ED F3 20 00    10656 	multuw	hl,#n			;FD ED F3 20 00
   1A76 FD ED F3 84 05    10657 	multuw	hl,#nn			;FD ED F3 84 05
   1A7B FD ED C3 55 00    10658 	multuw	hl,sxoff(ix)		;FD ED C3 55 00
   1A80 FD ED C3 55 00    10659 	multuw	hl,(ix+sxoff)		;FD ED C3 55 00
   1A85 FD ED D3 55 00    10660 	multuw	hl,sxoff(iy)		;FD ED D3 55 00
   1A8A FD ED D3 55 00    10661 	multuw	hl,(iy+sxoff)		;FD ED D3 55 00
   1A8F FD ED C3 22 11    10662 	multuw	hl,lxoff(ix)		;FD ED C3 22 11
   1A94 FD ED C3 22 11    10663 	multuw	hl,(ix+lxoff)		;FD ED C3 22 11
   1A99 FD ED D3 22 11    10664 	multuw	hl,lxoff(iy)		;FD ED D3 22 11
   1A9E FD ED D3 22 11    10665 	multuw	hl,(iy+lxoff)		;FD ED D3 22 11
   1AA3 DD ED C3          10669 	multuw	hl,(hl)			;DD ED C3
   1AA6 FD ED C3 00 00    10670 	multuw	hl,(ix)			;FD ED C3 00 00
   1AAB FD ED D3 00 00    10671 	multuw	hl,(iy)			;FD ED D3 00 00
   1AB0 DD ED F3 22 11    10743 	multuw	hl,pcr_ofst(pc)		;DD ED F3 22 11
   1AB5 DD ED F3 22 11    10747 	multuw	hl,(pc+pcr_ofst)	;DD ED F3 22 11
   1ABA DD ED F3 22 11    10751 	multuw	hl,[pcr_ofst]		;DD ED F3 22 11
   1ABF DD ED F3 1B 00    10755 	multuw	hl,[.+nc]		;DD ED F3 1B 00
                          10756 
                          10757 ;*******************************************************************
                          10758 ;	MULTW	
                          10759 ;*******************************************************************
                          10760 	; word multiplication
                          10761 	;  p. 5-93
                          10762 	.z280
   1AC4 ED C2             10763 	multw	hl,bc			;ED C2
   1AC6 ED D2             10764 	multw	hl,de			;ED D2
   1AC8 ED E2             10765 	multw	hl,hl			;ED E2
   1ACA ED F2             10766 	multw	hl,sp			;ED F2
   1ACC DD ED E2          10767 	multw	hl,ix			;DD ED E2
   1ACF FD ED E2          10768 	multw	hl,iy			;FD ED E2
   1AD2 FD ED F2 20 00    10802 	multw	hl,#n			;FD ED F2 20 00
   1AD7 FD ED F2 84 05    10803 	multw	hl,#nn			;FD ED F2 84 05
   1ADC DD ED D2 44 33    10804 	multw	hl,(daddr)		;DD ED D2 44 33
   1AE1 FD ED C2 55 00    10805 	multw	hl,sxoff(ix)		;FD ED C2 55 00
   1AE6 FD ED C2 55 00    10806 	multw	hl,(ix+sxoff)		;FD ED C2 55 00
   1AEB FD ED D2 55 00    10807 	multw	hl,sxoff(iy)		;FD ED D2 55 00
   1AF0 FD ED D2 55 00    10808 	multw	hl,(iy+sxoff)		;FD ED D2 55 00
   1AF5 FD ED C2 22 11    10809 	multw	hl,lxoff(ix)		;FD ED C2 22 11
   1AFA FD ED C2 22 11    10810 	multw	hl,(ix+lxoff)		;FD ED C2 22 11
   1AFF FD ED D2 22 11    10811 	multw	hl,lxoff(iy)		;FD ED D2 22 11
   1B04 FD ED D2 22 11    10812 	multw	hl,(iy+lxoff)		;FD ED D2 22 11
   1B09 DD ED C2          10816 	multw	hl,(hl)			;DD ED C2
   1B0C FD ED C2 00 00    10817 	multw	hl,(ix)			;FD ED C2 00 00
   1B11 FD ED D2 00 00    10818 	multw	hl,(iy)			;FD ED D2 00 00
   1B16 DD ED F2 22 11    10890 	multw	hl,pcr_ofst(pc)		;DD ED F2 22 11
   1B1B DD ED F2 22 11    10894 	multw	hl,(pc+pcr_ofst)	;DD ED F2 22 11
   1B20 DD ED F2 22 11    10898 	multw	hl,[pcr_ofst]		;DD ED F2 22 11
   1B25 DD ED F2 1B 00    10902 	multw	hl,[.+nc]		;DD ED F2 1B 00
                          10903 
                          10904 ;*******************************************************************
                          10905 ;	NEG	
                          10906 ;*******************************************************************
                          10907 	;***********************************************************
                          10908 	; 2's complement of 'a'
                          10909 	.z80
   1B2A ED 44             10910 	neg				;ED 44
   1B2C ED 44             10911 	neg	a			;ED 44
                          10912 	.z280
   1B2E ED 4C             10913 	neg	hl			;ED 4C
                          10914 
                          10915 ;*******************************************************************
                          10916 ;	NOP	
                          10917 ;*******************************************************************
                          10918 	;***********************************************************
                          10919 	; no operation
                          10920 	.z80
   1B30 00                10921 	nop				;00
                          10922 
                          10923 ;*******************************************************************
                          10924 ;	OR	
                          10925 ;		Leading 'a' operand is optional.
                          10926 ;		If offset is ommitted 0 is assumed.
                          10927 ;*******************************************************************
                          10928 	;***********************************************************
                          10929 	; logical 'or' operand with 'a'
                          10930 	.z80
   1B31 B6                10931 	or	a,(hl)			;B6
   1B32 F6 20             10955 	or	a,#n			;F6 20
   1B34 F6 20             10956 	or	a, n			;F6 20
   1B36 DD B6 55          10957 	or	a,offset(ix)		;DD B6 55
   1B39 FD B6 55          10958 	or	a,offset(iy)		;FD B6 55
   1B3C DD B6 55          10959 	or	a,(ix+offset)		;DD B6 55
   1B3F FD B6 55          10960 	or	a,(iy+offset)		;FD B6 55
   1B42 B7                10964 	or	a,a			;B7
   1B43 B0                10965 	or	a,b			;B0
   1B44 B1                10966 	or	a,c			;B1
   1B45 B2                10967 	or	a,d			;B2
   1B46 B3                10968 	or	a,e			;B3
   1B47 B4                10969 	or	a,h			;B4
   1B48 B5                10970 	or	a,l			;B5
                          10971 	;***********************************************************
                          10972 	;  p. 5-100
                          10973 	.z280
   1B49 DD B1             10974 	or	a,(hl+ix)		;DD B1
   1B4B DD B2             10975 	or	a,(hl+iy)		;DD B2
   1B4D DD B3             10976 	or	a,(ix+iy)		;DD B3
   1B4F DD B7 44 33       11022 	or	a,(daddr)		;DD B7 44 33
   1B53 DD B6 55          11033 	or	a,sxoff(ix)		;DD B6 55
   1B56 DD B6 55          11034 	or	a,(ix+sxoff)		;DD B6 55
   1B59 FD B6 55          11035 	or	a,sxoff(iy)		;FD B6 55
   1B5C FD B6 55          11036 	or	a,(iy+sxoff)		;FD B6 55
   1B5F FD B1 22 11       11040 	or	a,lxoff(ix)		;FD B1 22 11
   1B63 FD B1 22 11       11041 	or	a,(ix+lxoff)		;FD B1 22 11
   1B67 FD B2 22 11       11042 	or	a,lxoff(iy)		;FD B2 22 11
   1B6B FD B2 22 11       11043 	or	a,(iy+lxoff)		;FD B2 22 11
   1B6F FD B3 22 11       11044 	or	a,lxoff(hl)		;FD B3 22 11
   1B73 FD B3 22 11       11045 	or	a,(hl+lxoff)		;FD B3 22 11
   1B77 DD B0 22 11       11046 	or	a,lxoff(sp)		;DD B0 22 11
   1B7B DD B0 22 11       11047 	or	a,(sp+lxoff)		;DD B0 22 11
   1B7F FD B0 22 11       11122 	or	a,pcr_ofst(pc)		;FD B0 22 11
   1B83 FD B0 22 11       11126 	or	a,(pc+pcr_ofst)		;FD B0 22 11
   1B87 FD B0 22 11       11130 	or	a,[pcr_ofst]		;FD B0 22 11
   1B8B FD B0 1E 11       11134 	or	a,[.+lxofc]		;FD B0 1E 11
   1B8F DD B4             11135 	or	a,ixh			;DD B4
   1B91 DD B5             11136 	or	a,ixl			;DD B5
   1B93 FD B4             11137 	or	a,iyh			;FD B4
   1B95 FD B5             11138 	or	a,iyl			;FD B5
                          11139 
                          11140 	;***********************************************************
                          11141 	; logical 'or' operand without 'a'
                          11142 	.z80
   1B97 B6                11143 	or	a,(hl)			;B6
   1B98 F6 20             11167 	or	#n			;F6 20
   1B9A F6 20             11168 	or	 n			;F6 20
   1B9C DD B6 55          11169 	or	offset(ix)		;DD B6 55
   1B9F FD B6 55          11170 	or	offset(iy)		;FD B6 55
   1BA2 DD B6 55          11171 	or	(ix+offset)		;DD B6 55
   1BA5 FD B6 55          11172 	or	(iy+offset)		;FD B6 55
   1BA8 B7                11176 	or	a			;B7
   1BA9 B0                11177 	or	b			;B0
   1BAA B1                11178 	or	c			;B1
   1BAB B2                11179 	or	d			;B2
   1BAC B3                11180 	or	e			;B3
   1BAD B4                11181 	or	h			;B4
   1BAE B5                11182 	or	l			;B5
                          11183 	;***********************************************************
                          11184 	;  p. 5-100
                          11185 	.z280
   1BAF DD B1             11186 	or	(hl+ix)		;DD B1
   1BB1 DD B2             11187 	or	(hl+iy)		;DD B2
   1BB3 DD B3             11188 	or	(ix+iy)		;DD B3
   1BB5 DD B7 44 33       11234 	or	(daddr)			;DD B7 44 33
   1BB9 DD B6 55          11245 	or	sxoff(ix)		;DD B6 55
   1BBC DD B6 55          11246 	or	(ix+sxoff)		;DD B6 55
   1BBF FD B6 55          11247 	or	sxoff(iy)		;FD B6 55
   1BC2 FD B6 55          11248 	or	(iy+sxoff)		;FD B6 55
   1BC5 FD B3 55 00       11252 	or	sxoff(hl)		;FD B3 55 00
   1BC9 FD B3 55 00       11253 	or	(hl+sxoff)		;FD B3 55 00
   1BCD DD B0 55 00       11254 	or	sxoff(sp)		;DD B0 55 00
   1BD1 DD B0 55 00       11255 	or	(sp+sxoff)		;DD B0 55 00
   1BD5 FD B1 22 11       11256 	or	lxoff(ix)		;FD B1 22 11
   1BD9 FD B1 22 11       11257 	or	(ix+lxoff)		;FD B1 22 11
   1BDD FD B2 22 11       11258 	or	lxoff(iy)		;FD B2 22 11
   1BE1 FD B2 22 11       11259 	or	(iy+lxoff)		;FD B2 22 11
   1BE5 FD B3 22 11       11260 	or	lxoff(hl)		;FD B3 22 11
   1BE9 FD B3 22 11       11261 	or	(hl+lxoff)		;FD B3 22 11
   1BED DD B0 22 11       11262 	or	lxoff(sp)		;DD B0 22 11
   1BF1 DD B0 22 11       11263 	or	(sp+lxoff)		;DD B0 22 11
   1BF5 FD B0 22 11       11338 	or	pcr_ofst(pc)		;FD B0 22 11
   1BF9 FD B0 22 11       11342 	or	(pc+pcr_ofst)		;FD B0 22 11
   1BFD FD B0 22 11       11346 	or	[pcr_ofst]		;FD B0 22 11
   1C01 FD B0 1E 11       11350 	or	[.+lxofc]		;FD B0 1E 11
   1C05 DD B4             11351 	or	ixh			;DD B4
   1C07 DD B5             11352 	or	ixl			;DD B5
   1C09 FD B4             11353 	or	iyh			;FD B4
   1C0B FD B5             11354 	or	iyl			;FD B5
                          11355 
                          11356 ;*******************************************************************
                          11357 ;	OTDR	
                          11358 ;*******************************************************************
                          11359 	;***********************************************************
                          11360 	; load output port (c)
                          11361 	; with location (hl)
                          11362 	; decrement hl and decrement b
                          11363 	; repeat until b = 0
                          11364 	.z80
   1C0D ED BB             11365 	otdr				;ED BB
                          11366 
                          11367 ;*******************************************************************
                          11368 ;	OTIR	
                          11369 ;*******************************************************************
                          11370 	;***********************************************************
                          11371 	; load output port (c)
                          11372 	; with location (hl)
                          11373 	; increment hl and decrement b
                          11374 	; repeat until b = 0
                          11375 	.z80
   1C0F ED B3             11376 	otir				;ED B3
                          11377 
                          11378 ;*******************************************************************
                          11379 ;	OUT	
                          11380 ;*******************************************************************
                          11381 	;***********************************************************
                          11382 	; load output port (c) with reg
                          11383 	.z80
   1C11 ED 79             11384 	out	(c),a			;ED 79
   1C13 ED 41             11385 	out	(c),b			;ED 41
   1C15 ED 49             11386 	out	(c),c			;ED 49
   1C17 ED 51             11387 	out	(c),d			;ED 51
   1C19 ED 59             11388 	out	(c),e			;ED 59
   1C1B ED 61             11389 	out	(c),h			;ED 61
   1C1D ED 69             11390 	out	(c),l			;ED 69
                          11391 	;***********************************************************
                          11392 	;  p. 5-105
                          11393 	.z280
   1C1F DD ED 69          11394 	out	(c),ixl			;DD ED 69
   1C22 DD ED 61          11395 	out	(c),ixh			;DD ED 61
   1C25 FD ED 69          11396 	out	(c),iyl			;FD ED 69
   1C28 FD ED 61          11397 	out	(c),iyh			;FD ED 61
   1C2B DD ED 79 44 33    11443 	out	(c),(daddr)		;DD ED 79 44 33
   1C30 FD ED 59 55 00    11444 	out	(c),sxoff(hl)		;FD ED 59 55 00
   1C35 FD ED 59 55 00    11445 	out	(c),(hl+sxoff)		;FD ED 59 55 00
   1C3A FD ED 59 22 11    11446 	out	(c),lxoff(hl)		;FD ED 59 22 11
   1C3F FD ED 59 22 11    11447 	out	(c),(hl+lxoff)		;FD ED 59 22 11
   1C44 FD ED 49 55 00    11448 	out	(c),sxoff(ix)		;FD ED 49 55 00
   1C49 FD ED 49 55 00    11449 	out	(c),(ix+sxoff)		;FD ED 49 55 00
   1C4E FD ED 49 22 11    11450 	out	(c),lxoff(ix)		;FD ED 49 22 11
   1C53 FD ED 49 22 11    11451 	out	(c),(ix+lxoff)		;FD ED 49 22 11
   1C58 FD ED 51 55 00    11452 	out	(c),sxoff(iy)		;FD ED 51 55 00
   1C5D FD ED 51 55 00    11453 	out	(c),(iy+sxoff)		;FD ED 51 55 00
   1C62 FD ED 51 22 11    11454 	out	(c),lxoff(iy)		;FD ED 51 22 11
   1C67 FD ED 51 22 11    11455 	out	(c),(iy+lxoff)		;FD ED 51 22 11
   1C6C DD ED 41 55 00    11456 	out	(c),offset(sp)		;DD ED 41 55 00
   1C71 DD ED 41 55 00    11457 	out	(c),(sp+offset)		;DD ED 41 55 00
   1C76 DD ED 41 22 11    11458 	out	(c),lxoff(sp)		;DD ED 41 22 11
   1C7B DD ED 41 22 11    11459 	out	(c),(sp+lxoff)		;DD ED 41 22 11
   1C80 FD ED 41 22 11    11534 	out	(c),pcr_ofst(pc)	;FD ED 41 22 11
   1C85 FD ED 41 22 11    11538 	out	(c),(pc+pcr_ofst)	;FD ED 41 22 11
   1C8A FD ED 41 22 11    11542 	out	(c),[pcr_ofst]		;FD ED 41 22 11
   1C8F FD ED 41 50 00    11546 	out	(c),[.+offsetc]		;FD ED 41 50 00
   1C94 DD ED 49          11547 	out	(c),(hl+ix)		;DD ED 49
   1C97 DD ED 51          11548 	out	(c),(hl+iy)		;DD ED 51
   1C9A DD ED 59          11549 	out	(c),(ix+iy)		;DD ED 59
                          11550 	;***********************************************************
                          11551 	; load output port (n) with 'a'
                          11552 	.z80
   1C9D D3 20             11568 	out	(n),a			;D3 20
   1C9F D3 20             11569 	out	n,a			;D3 20
                          11573 
                          11574 ;*******************************************************************
                          11575 ;	OUTD	
                          11576 ;*******************************************************************
                          11577 	;***********************************************************
                          11578 	; load output port (c)
                          11579 	; with location (hl)
                          11580 	; decrement hl and decrement b
                          11581 	.z80
   1CA1 ED AB             11582 	outd				;ED AB
                          11583 
                          11584 ;*******************************************************************
                          11585 ;	OUTI	
                          11586 ;*******************************************************************
                          11587 	;***********************************************************
                          11588 	; load output port (c)
                          11589 	; with location (hl)
                          11590 	; increment hl and decrement b
                          11591 	.z80
   1CA3 ED A3             11592 	outi				;ED A3
                          11593 
                          11594 ;*******************************************************************
                          11595 ;	OUTDW	
                          11596 ;*******************************************************************
                          11597 	;***********************************************************
                          11598 	.z280
   1CA5 ED 8B             11599 	outdw				;ED 8B
   1CA7 ED 83             11600 	outiw				;ED 83
   1CA9 ED 9B             11601 	otdrw				;ED 9B
   1CAB ED 93             11602 	otirw				;ED 93
                          11603 
                          11604 ;*******************************************************************
                          11605 ;	OUTW	
                          11606 ;*******************************************************************
                          11607 	;***********************************************************
                          11608 	;  p. 5-110	output to word port
                          11609 	.z280
   1CAD ED BF             11610 	out	(c),hl			;ED BF
   1CAF ED BF             11611 	outw	(c),hl			;ED BF
                          11612 
                          11613 ;*******************************************************************
                          11614 ;	PCACHE	
                          11615 ;*******************************************************************
                          11616 	;***********************************************************
                          11617 	;  p. 5-111    NOT privileged
                          11618 	.z280
   1CB1 ED 65             11619 	pcache				;ED 65
                          11620 
                          11621 ;*******************************************************************
                          11622 ;	POP	
                          11623 ;*******************************************************************
                          11624 	;***********************************************************
                          11625 	; load destination with top of stack
                          11626 	.z80
   1CB3 F1                11627 	pop	af			;F1
   1CB4 C1                11628 	pop	bc			;C1
   1CB5 D1                11629 	pop	de			;D1
   1CB6 E1                11630 	pop	hl			;E1
   1CB7 DD E1             11631 	pop	ix			;DD E1
   1CB9 FD E1             11632 	pop	iy			;FD E1
                          11633 	.z280
   1CBB DD D1 44 33       11647 	pop	(daddr)			;DD D1 44 33
   1CBF DD F1 22 11       11722 	pop	pcr_ofst(pc)		;DD F1 22 11
   1CC3 DD F1 22 11       11726 	pop	(pc+pcr_ofst)		;DD F1 22 11
   1CC7 DD F1 22 11       11730 	pop	[pcr_ofst]		;DD F1 22 11
   1CCB DD F1 1E 11       11734 	pop	[.+lxofc]		;DD F1 1E 11
   1CCF DD C1             11735 	pop	(hl)			;DD C1
                          11736 
                          11737 ;*******************************************************************
                          11738 ;	PUSH	
                          11739 ;*******************************************************************
                          11740 	;***********************************************************
                          11741 	; put source on stack
                          11742 	.z80
   1CD1 F5                11743 	push	af			;F5
   1CD2 C5                11744 	push	bc			;C5
   1CD3 D5                11745 	push	de			;D5
   1CD4 E5                11746 	push	hl			;E5
   1CD5 DD E5             11747 	push	ix			;DD E5
   1CD7 FD E5             11748 	push	iy			;FD E5
                          11749 	.z280
   1CD9 DD D5 44 33       11765 	push	(daddr)			;DD D5 44 33
   1CDD FD F5 84 05       11766 	push	#nn			;FD F5 84 05
   1CE1 DD F5 22 11       11841 	push	pcr_ofst(pc)		;DD F5 22 11
   1CE5 DD F5 22 11       11845 	push	(pc+pcr_ofst)		;DD F5 22 11
   1CE9 DD F5 22 11       11849 	push	[pcr_ofst]		;DD F5 22 11
   1CED DD F5 1E 11       11853 	push	[.+lxofc]		;DD F5 1E 11
   1CF1 DD C5             11854 	push	(hl)			;DD C5
                          11855 
                          11856 ;*******************************************************************
                          11857 ;	RES	
                          11858 ;*******************************************************************
                          11859 	;***********************************************************
                          11860 	; reset bit of location or register
                          11861 	.z80
   1CF3 CB 86             11862 	res	0,(hl)			;CB 86
   1CF5 DD CB 55 86       11882 	res	0,offset(ix)		;DD CB 55 86
   1CF9 FD CB 55 86       11883 	res	0,offset(iy)		;FD CB 55 86
   1CFD DD CB 55 86       11884 	res	0,(ix+offset)		;DD CB 55 86
   1D01 FD CB 55 86       11885 	res	0,(iy+offset)		;FD CB 55 86
   1D05 CB 87             11889 	res	0,a			;CB 87
   1D07 CB 80             11890 	res	0,b			;CB 80
   1D09 CB 81             11891 	res	0,c			;CB 81
   1D0B CB 82             11892 	res	0,d			;CB 82
   1D0D CB 83             11893 	res	0,e			;CB 83
   1D0F CB 84             11894 	res	0,h			;CB 84
   1D11 CB 85             11895 	res	0,l			;CB 85
   1D13 CB 8E             11896 	res	1,(hl)			;CB 8E
   1D15 DD CB 55 8E       11916 	res	1,offset(ix)		;DD CB 55 8E
   1D19 FD CB 55 8E       11917 	res	1,offset(iy)		;FD CB 55 8E
   1D1D DD CB 55 8E       11918 	res	1,(ix+offset)		;DD CB 55 8E
   1D21 FD CB 55 8E       11919 	res	1,(iy+offset)		;FD CB 55 8E
   1D25 CB 8F             11923 	res	1,a			;CB 8F
   1D27 CB 88             11924 	res	1,b			;CB 88
   1D29 CB 89             11925 	res	1,c			;CB 89
   1D2B CB 8A             11926 	res	1,d			;CB 8A
   1D2D CB 8B             11927 	res	1,e			;CB 8B
   1D2F CB 8C             11928 	res	1,h			;CB 8C
   1D31 CB 8D             11929 	res	1,l			;CB 8D
   1D33 CB 96             11930 	res	2,(hl)			;CB 96
   1D35 DD CB 55 96       11950 	res	2,offset(ix)		;DD CB 55 96
   1D39 FD CB 55 96       11951 	res	2,offset(iy)		;FD CB 55 96
   1D3D DD CB 55 96       11952 	res	2,(ix+offset)		;DD CB 55 96
   1D41 FD CB 55 96       11953 	res	2,(iy+offset)		;FD CB 55 96
   1D45 CB 97             11957 	res	2,a			;CB 97
   1D47 CB 90             11958 	res	2,b			;CB 90
   1D49 CB 91             11959 	res	2,c			;CB 91
   1D4B CB 92             11960 	res	2,d			;CB 92
   1D4D CB 93             11961 	res	2,e			;CB 93
   1D4F CB 94             11962 	res	2,h			;CB 94
   1D51 CB 95             11963 	res	2,l			;CB 95
   1D53 CB 9E             11964 	res	3,(hl)			;CB 9E
   1D55 DD CB 55 9E       11984 	res	3,offset(ix)		;DD CB 55 9E
   1D59 FD CB 55 9E       11985 	res	3,offset(iy)		;FD CB 55 9E
   1D5D DD CB 55 9E       11986 	res	3,(ix+offset)		;DD CB 55 9E
   1D61 FD CB 55 9E       11987 	res	3,(iy+offset)		;FD CB 55 9E
   1D65 CB 9F             11991 	res	3,a			;CB 9F
   1D67 CB 98             11992 	res	3,b			;CB 98
   1D69 CB 99             11993 	res	3,c			;CB 99
   1D6B CB 9A             11994 	res	3,d			;CB 9A
   1D6D CB 9B             11995 	res	3,e			;CB 9B
   1D6F CB 9C             11996 	res	3,h			;CB 9C
   1D71 CB 9D             11997 	res	3,l			;CB 9D
   1D73 CB A6             11998 	res	4,(hl)			;CB A6
   1D75 DD CB 55 A6       12018 	res	4,offset(ix)		;DD CB 55 A6
   1D79 FD CB 55 A6       12019 	res	4,offset(iy)		;FD CB 55 A6
   1D7D DD CB 55 A6       12020 	res	4,(ix+offset)		;DD CB 55 A6
   1D81 FD CB 55 A6       12021 	res	4,(iy+offset)		;FD CB 55 A6
   1D85 CB A7             12025 	res	4,a			;CB A7
   1D87 CB A0             12026 	res	4,b			;CB A0
   1D89 CB A1             12027 	res	4,c			;CB A1
   1D8B CB A2             12028 	res	4,d			;CB A2
   1D8D CB A3             12029 	res	4,e			;CB A3
   1D8F CB A4             12030 	res	4,h			;CB A4
   1D91 CB A5             12031 	res	4,l			;CB A5
   1D93 CB AE             12032 	res	5,(hl)			;CB AE
   1D95 DD CB 55 AE       12052 	res	5,offset(ix)		;DD CB 55 AE
   1D99 FD CB 55 AE       12053 	res	5,offset(iy)		;FD CB 55 AE
   1D9D DD CB 55 AE       12054 	res	5,(ix+offset)		;DD CB 55 AE
   1DA1 FD CB 55 AE       12055 	res	5,(iy+offset)		;FD CB 55 AE
   1DA5 CB AF             12059 	res	5,a			;CB AF
   1DA7 CB A8             12060 	res	5,b			;CB A8
   1DA9 CB A9             12061 	res	5,c			;CB A9
   1DAB CB AA             12062 	res	5,d			;CB AA
   1DAD CB AB             12063 	res	5,e			;CB AB
   1DAF CB AC             12064 	res	5,h			;CB AC
   1DB1 CB AD             12065 	res	5,l			;CB AD
   1DB3 CB B6             12066 	res	6,(hl)			;CB B6
   1DB5 DD CB 55 B6       12086 	res	6,offset(ix)		;DD CB 55 B6
   1DB9 FD CB 55 B6       12087 	res	6,offset(iy)		;FD CB 55 B6
   1DBD DD CB 55 B6       12088 	res	6,(ix+offset)		;DD CB 55 B6
   1DC1 FD CB 55 B6       12089 	res	6,(iy+offset)		;FD CB 55 B6
   1DC5 CB B7             12093 	res	6,a			;CB B7
   1DC7 CB B0             12094 	res	6,b			;CB B0
   1DC9 CB B1             12095 	res	6,c			;CB B1
   1DCB CB B2             12096 	res	6,d			;CB B2
   1DCD CB B3             12097 	res	6,e			;CB B3
   1DCF CB B4             12098 	res	6,h			;CB B4
   1DD1 CB B5             12099 	res	6,l			;CB B5
   1DD3 CB BE             12100 	res	7,(hl)			;CB BE
   1DD5 DD CB 55 BE       12120 	res	7,offset(ix)		;DD CB 55 BE
   1DD9 FD CB 55 BE       12121 	res	7,offset(iy)		;FD CB 55 BE
   1DDD DD CB 55 BE       12122 	res	7,(ix+offset)		;DD CB 55 BE
   1DE1 FD CB 55 BE       12123 	res	7,(iy+offset)		;FD CB 55 BE
   1DE5 CB BF             12127 	res	7,a			;CB BF
   1DE7 CB B8             12128 	res	7,b			;CB B8
   1DE9 CB B9             12129 	res	7,c			;CB B9
   1DEB CB BA             12130 	res	7,d			;CB BA
   1DED CB BB             12131 	res	7,e			;CB BB
   1DEF CB BC             12132 	res	7,h			;CB BC
   1DF1 CB BD             12133 	res	7,l			;CB BD
                          12134 
                          12135 ;*******************************************************************
                          12136 ;	RET	
                          12137 ;*******************************************************************
                          12138 	;***********************************************************
                          12139 	; return from subroutine
                          12140 	.z80
   1DF3 C9                12141 	ret				;C9
                          12142 	;***********************************************************
                          12143 	; return from subroutine if condition is true
   1DF4 D8                12144 	ret	C			;D8
   1DF5 F8                12145 	ret	M			;F8
   1DF6 D0                12146 	ret	NC			;D0
   1DF7 C0                12147 	ret	NZ			;C0
   1DF8 F0                12148 	ret	P			;F0
   1DF9 E8                12149 	ret	PE			;E8
   1DFA E0                12150 	ret	PO			;E0
   1DFB C8                12151 	ret	Z			;C8
                          12152 
                          12153 ;*******************************************************************
                          12154 ;	RETI	
                          12155 ;*******************************************************************
                          12156 	;***********************************************************
                          12157 	; return from interrupt (privileged)
                          12158 	.z80
   1DFC ED 4D             12159 	reti				;ED 4D
                          12160 
                          12161 ;*******************************************************************
                          12162 ;	RETN	
                          12163 ;*******************************************************************
                          12164 	;***********************************************************
                          12165 	; return from non-maskable interrupt (privileged)
                          12166 	.z80
   1DFE ED 45             12167 	retn				;ED 45
                          12168 
                          12169 ;*******************************************************************
                          12170 ;	RETIL	
                          12171 ;*******************************************************************
                          12172 	;***********************************************************
                          12173 	; return from interrupt (long)
                          12174 	.z280p
   1E00 ED 55             12175 	retil				;ED 55
                          12176 
                          12177 ;*******************************************************************
                          12178 ;	RL	
                          12179 ;*******************************************************************
                          12224 	;***********************************************************
                          12225 	; rotate left through carry
                          12226 	.z80
   1E02 CB 16             12227 	rl	(hl)			;CB 16
   1E04 DD CB 55 16       12247 	rl	offset(ix)		;DD CB 55 16
   1E08 FD CB 55 16       12248 	rl	offset(iy)		;FD CB 55 16
   1E0C DD CB 55 16       12249 	rl	(ix+offset)		;DD CB 55 16
   1E10 FD CB 55 16       12250 	rl	(iy+offset)		;FD CB 55 16
   1E14 CB 17             12254 	rl	a			;CB 17
   1E16 CB 10             12255 	rl	b			;CB 10
   1E18 CB 11             12256 	rl	c			;CB 11
   1E1A CB 12             12257 	rl	d			;CB 12
   1E1C CB 13             12258 	rl	e			;CB 13
   1E1E CB 14             12259 	rl	h			;CB 14
   1E20 CB 15             12260 	rl	l			;CB 15
                          12261 
                          12262 ;*******************************************************************
                          12263 ;	RLA	
                          12264 ;*******************************************************************
                          12265 	;***********************************************************
                          12266 	; rotate left 'a' with carry
                          12267 	.z80
   1E22 17                12268 	rla				;17
                          12269 
                          12270 ;*******************************************************************
                          12271 ;	RLC	
                          12272 ;*******************************************************************
                          12317 	;***********************************************************
                          12318 	; rotate left circular
                          12319 	.z80
   1E23 CB 06             12320 	rlc	(hl)			;CB 06
   1E25 DD CB 55 06       12340 	rlc	offset(ix)		;DD CB 55 06
   1E29 FD CB 55 06       12341 	rlc	offset(iy)		;FD CB 55 06
   1E2D DD CB 55 06       12342 	rlc	(ix+offset)		;DD CB 55 06
   1E31 FD CB 55 06       12343 	rlc	(iy+offset)		;FD CB 55 06
   1E35 CB 07             12347 	rlc	a			;CB 07
   1E37 CB 00             12348 	rlc	b			;CB 00
   1E39 CB 01             12349 	rlc	c			;CB 01
   1E3B CB 02             12350 	rlc	d			;CB 02
   1E3D CB 03             12351 	rlc	e			;CB 03
   1E3F CB 04             12352 	rlc	h			;CB 04
   1E41 CB 05             12353 	rlc	l			;CB 05
                          12354 
                          12355 ;*******************************************************************
                          12356 ;	RLCA	
                          12357 ;*******************************************************************
                          12358 	;***********************************************************
                          12359 	; rotate left 'a' circular
                          12360 	.z80
   1E43 07                12361 	rlca				;07
                          12362 
                          12363 ;*******************************************************************
                          12364 ;	RLD	
                          12365 ;*******************************************************************
                          12366 	;***********************************************************
                          12367 	; rotate digit left and right
                          12368 	; between 'a' and location (hl)
                          12369 	.z80
   1E44 ED 6F             12370 	rld				;ED 6F
                          12371 
                          12372 ;*******************************************************************
                          12373 ;	RR	
                          12374 ;*******************************************************************
                          12419 	;***********************************************************
                          12420 	; rotate right through carry
                          12421 	.z80
   1E46 CB 1E             12422 	rr	(hl)			;CB 1E
   1E48 DD CB 55 1E       12442 	rr	offset(ix)		;DD CB 55 1E
   1E4C FD CB 55 1E       12443 	rr	offset(iy)		;FD CB 55 1E
   1E50 DD CB 55 1E       12444 	rr	(ix+offset)		;DD CB 55 1E
   1E54 FD CB 55 1E       12445 	rr	(iy+offset)		;FD CB 55 1E
   1E58 CB 1F             12449 	rr	a			;CB 1F
   1E5A CB 18             12450 	rr	b			;CB 18
   1E5C CB 19             12451 	rr	c			;CB 19
   1E5E CB 1A             12452 	rr	d			;CB 1A
   1E60 CB 1B             12453 	rr	e			;CB 1B
   1E62 CB 1C             12454 	rr	h			;CB 1C
   1E64 CB 1D             12455 	rr	l			;CB 1D
                          12456 
                          12457 ;*******************************************************************
                          12458 ;	RRA	
                          12459 ;*******************************************************************
                          12460 	;***********************************************************
                          12461 	; rotate 'a' right with carry
                          12462 	.z80
   1E66 1F                12463 	rra				;1F
                          12464 
                          12465 ;*******************************************************************
                          12466 ;	RRC	
                          12467 ;*******************************************************************
                          12512 	;***********************************************************
                          12513 	; rotate right circular
                          12514 	.z80
   1E67 CB 0E             12515 	rrc	(hl)			;CB 0E
   1E69 DD CB 55 0E       12535 	rrc	offset(ix)		;DD CB 55 0E
   1E6D FD CB 55 0E       12536 	rrc	offset(iy)		;FD CB 55 0E
   1E71 DD CB 55 0E       12537 	rrc	(ix+offset)		;DD CB 55 0E
   1E75 FD CB 55 0E       12538 	rrc	(iy+offset)		;FD CB 55 0E
   1E79 CB 0F             12542 	rrc	a			;CB 0F
   1E7B CB 08             12543 	rrc	b			;CB 08
   1E7D CB 09             12544 	rrc	c			;CB 09
   1E7F CB 0A             12545 	rrc	d			;CB 0A
   1E81 CB 0B             12546 	rrc	e			;CB 0B
   1E83 CB 0C             12547 	rrc	h			;CB 0C
   1E85 CB 0D             12548 	rrc	l			;CB 0D
                          12549 
                          12550 ;*******************************************************************
                          12551 ;	RRCA	
                          12552 ;*******************************************************************
                          12553 	.z80
                          12554 	;***********************************************************
                          12555 	; rotate 'a' right circular
   1E87 0F                12556 	rrca				;0F
                          12557 
                          12558 ;*******************************************************************
                          12559 ;	RRD	
                          12560 ;*******************************************************************
                          12561 	;***********************************************************
                          12562 	; rotate digit right and left
                          12563 	; between 'a' and location (hl)
                          12564 	.z80
   1E88 ED 67             12565 	rrd				;ED 67
                          12566 
                          12567 ;*******************************************************************
                          12568 ;	RST	
                          12569 ;*******************************************************************
                          12570 	;***********************************************************
                          12571 	; restart location
                          12572 	.z80
   1E8A C7                12573 	rst	0x00			;C7
   1E8B CF                12574 	rst	0x08			;CF
   1E8C D7                12575 	rst	0x10			;D7
   1E8D DF                12576 	rst	0x18			;DF
   1E8E E7                12577 	rst	0x20			;E7
   1E8F EF                12578 	rst	0x28			;EF
   1E90 F7                12579 	rst	0x30			;F7
   1E91 FF                12580 	rst	0x38			;FF
                          12581 
                          12582 ;*******************************************************************
                          12583 ;	SBC	
                          12584 ;		Leading 'a' operand is optional.
                          12585 ;		If offset is ommitted 0 is assumed.
                          12586 ;*******************************************************************
                          12587 	;***********************************************************
                          12588 	; subtract with carry to 'a'
                          12589 	.z80
   1E92 9E                12590 	sbc	a,(hl)			;9E
   1E93 DD 9E 55          12610 	sbc	a,offset(ix)		;DD 9E 55
   1E96 FD 9E 55          12611 	sbc	a,offset(iy)		;FD 9E 55
   1E99 DD 9E 55          12612 	sbc	a,(ix+offset)		;DD 9E 55
   1E9C FD 9E 55          12613 	sbc	a,(iy+offset)		;FD 9E 55
   1E9F 9F                12617 	sbc	a,a			;9F
   1EA0 98                12618 	sbc	a,b			;98
   1EA1 99                12619 	sbc	a,c			;99
   1EA2 9A                12620 	sbc	a,d			;9A
   1EA3 9B                12621 	sbc	a,e			;9B
   1EA4 9C                12622 	sbc	a,h			;9C
   1EA5 9D                12623 	sbc	a,l			;9D
   1EA6 DE 20             12639 	sbc	a,#n			;DE 20
   1EA8 DE 20             12640 	sbc	a, n			;DE 20
                          12644 	;***********************************************************
                          12645 	; subtract with carry to 'a'
                          12646 	.z80
   1EAA 9E                12647 	sbc	(hl)			;9E
   1EAB DD 9E 55          12667 	sbc	offset(ix)		;DD 9E 55
   1EAE FD 9E 55          12668 	sbc	offset(iy)		;FD 9E 55
   1EB1 DD 9E 55          12669 	sbc	(ix+offset)		;DD 9E 55
   1EB4 FD 9E 55          12670 	sbc	(iy+offset)		;FD 9E 55
   1EB7 9F                12674 	sbc	a			;9F
   1EB8 98                12675 	sbc	b			;98
   1EB9 99                12676 	sbc	c			;99
   1EBA 9A                12677 	sbc	d			;9A
   1EBB 9B                12678 	sbc	e			;9B
   1EBC 9C                12679 	sbc	h			;9C
   1EBD 9D                12680 	sbc	l			;9D
   1EBE DE 20             12696 	sbc	#n			;DE 20
   1EC0 DE 20             12697 	sbc	 n			;DE 20
                          12701 	;***********************************************************
                          12702 	; add with carry register pair to 'hl'
   1EC2 ED 42             12703 	sbc	hl,bc			;ED 42
   1EC4 ED 52             12704 	sbc	hl,de			;ED 52
   1EC6 ED 62             12705 	sbc	hl,hl			;ED 62
   1EC8 ED 72             12706 	sbc	hl,sp			;ED 72
                          12707 	;***********************************************************
                          12708 	;  p. 5-130
                          12709 	.z280
   1ECA DD 9C             12710 	sbc	a,ixh			;DD 9C
   1ECC DD 9D             12711 	sbc	a,ixl			;DD 9D
   1ECE FD 9C             12712 	sbc	a,iyh			;FD 9C
   1ED0 FD 9D             12713 	sbc	a,iyl			;FD 9D
   1ED2 DE 20             12761 	sbc	a,#n			;DE 20
   1ED4 DD 9F 44 33       12762 	sbc	a,(daddr)		;DD 9F 44 33
   1ED8 DD 9E 55          12773 	sbc	a,sxoff(ix)		;DD 9E 55
   1EDB DD 9E 55          12774 	sbc	a,(ix+sxoff)		;DD 9E 55
   1EDE FD 9E 55          12775 	sbc	a,sxoff(iy)		;FD 9E 55
   1EE1 FD 9E 55          12776 	sbc	a,(iy+sxoff)		;FD 9E 55
   1EE4 FD 9B 55 00       12780 	sbc	a,sxoff(hl)		;FD 9B 55 00
   1EE8 FD 9B 55 00       12781 	sbc	a,(hl+sxoff)		;FD 9B 55 00
   1EEC DD 98 55 00       12782 	sbc	a,sxoff(sp)		;DD 98 55 00
   1EF0 DD 98 55 00       12783 	sbc	a,(sp+sxoff)		;DD 98 55 00
   1EF4 FD 99 22 11       12784 	sbc	a,lxoff(ix)		;FD 99 22 11
   1EF8 FD 99 22 11       12785 	sbc	a,(ix+lxoff)		;FD 99 22 11
   1EFC FD 9A 22 11       12786 	sbc	a,lxoff(iy)		;FD 9A 22 11
   1F00 FD 9A 22 11       12787 	sbc	a,(iy+lxoff)		;FD 9A 22 11
   1F04 FD 9B 22 11       12788 	sbc	a,lxoff(hl)		;FD 9B 22 11
   1F08 FD 9B 22 11       12789 	sbc	a,(hl+lxoff)		;FD 9B 22 11
   1F0C DD 98 22 11       12790 	sbc	a,lxoff(sp)		;DD 98 22 11
   1F10 DD 98 22 11       12791 	sbc	a,(sp+lxoff)		;DD 98 22 11
   1F14 DD 9E 00          12795 	sbc	a,(ix)			;DD 9E 00
   1F17 FD 9E 00          12796 	sbc	a,(iy)			;FD 9E 00
   1F1A 9E                12797 	sbc	a,(hl)			;9E
   1F1B DD 98 00 00       12798 	sbc	a,(sp)			;DD 98 00 00
   1F1F FD 98 34 12       12870 	sbc	a,pcr_ofst(pc)		;FD 98 34 12
   1F23 FD 98 34 12       12874 	sbc	a,(pc+pcr_ofst)	;FD 98 34 12
   1F27 FD 98 34 12       12878 	sbc	a,[pcr_ofst]		;FD 98 34 12
   1F2B FD 98 1C 00       12882 	sbc	a,[.+nc]		;FD 98 1C 00
   1F2F DD 99             12883 	sbc	a,(hl+ix)		;DD 99
   1F31 DD 9A             12884 	sbc	a,(hl+iy)		;DD 9A
   1F33 DD 9B             12885 	sbc	a,(ix+iy)		;DD 9B
                          12886 	;***********************************************************
                          12887 	;  p. 5-130
                          12888 	.z280
   1F35 DD 9C             12889 	sbc	ixh			;DD 9C
   1F37 DD 9D             12890 	sbc	ixl			;DD 9D
   1F39 FD 9C             12891 	sbc	iyh			;FD 9C
   1F3B FD 9D             12892 	sbc	iyl			;FD 9D
   1F3D DE 20             12940 	sbc	a,#n			;DE 20
   1F3F DD 9F 44 33       12941 	sbc	(daddr)			;DD 9F 44 33
   1F43 DD 9E 55          12952 	sbc	sxoff(ix)		;DD 9E 55
   1F46 DD 9E 55          12953 	sbc	(ix+sxoff)		;DD 9E 55
   1F49 FD 9E 55          12954 	sbc	sxoff(iy)		;FD 9E 55
   1F4C FD 9E 55          12955 	sbc	(iy+sxoff)		;FD 9E 55
   1F4F FD 9B 55 00       12959 	sbc	sxoff(hl)		;FD 9B 55 00
   1F53 FD 9B 55 00       12960 	sbc	(hl+sxoff)		;FD 9B 55 00
   1F57 DD 98 55 00       12961 	sbc	sxoff(sp)		;DD 98 55 00
   1F5B DD 98 55 00       12962 	sbc	(sp+sxoff)		;DD 98 55 00
   1F5F FD 99 22 11       12963 	sbc	lxoff(ix)		;FD 99 22 11
   1F63 FD 99 22 11       12964 	sbc	(ix+lxoff)		;FD 99 22 11
   1F67 FD 9A 22 11       12965 	sbc	lxoff(iy)		;FD 9A 22 11
   1F6B FD 9A 22 11       12966 	sbc	(iy+lxoff)		;FD 9A 22 11
   1F6F FD 9B 22 11       12967 	sbc	lxoff(hl)		;FD 9B 22 11
   1F73 FD 9B 22 11       12968 	sbc	(hl+lxoff)		;FD 9B 22 11
   1F77 DD 98 22 11       12969 	sbc	lxoff(sp)		;DD 98 22 11
   1F7B DD 98 22 11       12970 	sbc	(sp+lxoff)		;DD 98 22 11
   1F7F 9E                12974 	sbc	(hl)			;9E
   1F80 DD 9E 00          12975 	sbc	(ix)			;DD 9E 00
   1F83 FD 9E 00          12976 	sbc	(iy)			;FD 9E 00
   1F86 DD 98 00 00       12977 	sbc	(sp)			;DD 98 00 00
   1F8A FD 98 34 12       13049 	sbc	pcr_ofst(pc)		;FD 98 34 12
   1F8E FD 98 34 12       13053 	sbc	(pc+pcr_ofst)		;FD 98 34 12
   1F92 FD 98 34 12       13057 	sbc	[pcr_ofst]		;FD 98 34 12
   1F96 FD 98 1C 00       13061 	sbc	[.+nc]			;FD 98 1C 00
   1F9A DD 99             13062 	sbc	(hl+ix)			;DD 99
   1F9C DD 9A             13063 	sbc	(hl+iy)			;DD 9A
   1F9E DD 9B             13064 	sbc	(ix+iy)			;DD 9B
                          13065 	;***********************************************************
                          13066 	;  p. 5-131
   1FA0 DD ED 42          13067 	sbc	ix,bc			;DD ED 42
   1FA3 DD ED 52          13068 	sbc	ix,de			;DD ED 52
   1FA6 DD ED 62          13069 	sbc	ix,ix			;DD ED 62
   1FA9 DD ED 72          13070 	sbc	ix,sp			;DD ED 72
   1FAC FD ED 42          13071 	sbc	iy,bc			;FD ED 42
   1FAF FD ED 52          13072 	sbc	iy,de			;FD ED 52
   1FB2 FD ED 62          13073 	sbc	iy,iy			;FD ED 62
   1FB5 FD ED 72          13074 	sbc	iy,sp			;FD ED 72
                          13075 
                          13076 ;*******************************************************************
                          13077 ;	SC	
                          13078 ;*******************************************************************
                          13079 	;***********************************************************
                          13080 	; Z280 system call
                          13081 	.z280
   1FB8 ED 71 20 00       13099 	sc	n			;ED 71 20 00
   1FBC ED 71 20 00       13100 	sc	#n			;ED 71 20 00
   1FC0 ED 71 20 00       13101 	sc	(n)			;ED 71 20 00
                          13105 
                          13106 ;*******************************************************************
                          13107 ;	SCF	
                          13108 ;*******************************************************************
                          13109 	;***********************************************************
                          13110 	; set carry flag (C=1)
                          13111 	.z80
   1FC4 37                13112 	scf				;37
                          13113 
                          13114 ;*******************************************************************
                          13115 ;	SET	
                          13116 ;*******************************************************************
                          13117 	;***********************************************************
                          13118 	; set bit of location or register
                          13119 	.z80
   1FC5 CB C6             13120 	set	0,(hl)			;CB C6
   1FC7 DD CB 55 C6       13140 	set	0,offset(ix)		;DD CB 55 C6
   1FCB FD CB 55 C6       13141 	set	0,offset(iy)		;FD CB 55 C6
   1FCF DD CB 55 C6       13142 	set	0,(ix+offset)		;DD CB 55 C6
   1FD3 FD CB 55 C6       13143 	set	0,(iy+offset)		;FD CB 55 C6
   1FD7 CB C7             13147 	set	0,a			;CB C7
   1FD9 CB C0             13148 	set	0,b			;CB C0
   1FDB CB C1             13149 	set	0,c			;CB C1
   1FDD CB C2             13150 	set	0,d			;CB C2
   1FDF CB C3             13151 	set	0,e			;CB C3
   1FE1 CB C4             13152 	set	0,h			;CB C4
   1FE3 CB C5             13153 	set	0,l			;CB C5
   1FE5 CB CE             13154 	set	1,(hl)			;CB CE
   1FE7 DD CB 55 CE       13174 	set	1,offset(ix)		;DD CB 55 CE
   1FEB FD CB 55 CE       13175 	set	1,offset(iy)		;FD CB 55 CE
   1FEF DD CB 55 CE       13176 	set	1,(ix+offset)		;DD CB 55 CE
   1FF3 FD CB 55 CE       13177 	set	1,(iy+offset)		;FD CB 55 CE
   1FF7 CB CF             13181 	set	1,a			;CB CF
   1FF9 CB C8             13182 	set	1,b			;CB C8
   1FFB CB C9             13183 	set	1,c			;CB C9
   1FFD CB CA             13184 	set	1,d			;CB CA
   1FFF CB CB             13185 	set	1,e			;CB CB
   2001 CB CC             13186 	set	1,h			;CB CC
   2003 CB CD             13187 	set	1,l			;CB CD
   2005 CB D6             13188 	set	2,(hl)			;CB D6
   2007 DD CB 55 D6       13208 	set	2,offset(ix)		;DD CB 55 D6
   200B FD CB 55 D6       13209 	set	2,offset(iy)		;FD CB 55 D6
   200F DD CB 55 D6       13210 	set	2,(ix+offset)		;DD CB 55 D6
   2013 FD CB 55 D6       13211 	set	2,(iy+offset)		;FD CB 55 D6
   2017 CB D7             13215 	set	2,a			;CB D7
   2019 CB D0             13216 	set	2,b			;CB D0
   201B CB D1             13217 	set	2,c			;CB D1
   201D CB D2             13218 	set	2,d			;CB D2
   201F CB D3             13219 	set	2,e			;CB D3
   2021 CB D4             13220 	set	2,h			;CB D4
   2023 CB D5             13221 	set	2,l			;CB D5
   2025 CB DE             13222 	set	3,(hl)			;CB DE
   2027 DD CB 55 DE       13242 	set	3,offset(ix)		;DD CB 55 DE
   202B FD CB 55 DE       13243 	set	3,offset(iy)		;FD CB 55 DE
   202F DD CB 55 DE       13244 	set	3,(ix+offset)		;DD CB 55 DE
   2033 FD CB 55 DE       13245 	set	3,(iy+offset)		;FD CB 55 DE
   2037 CB DF             13249 	set	3,a			;CB DF
   2039 CB D8             13250 	set	3,b			;CB D8
   203B CB D9             13251 	set	3,c			;CB D9
   203D CB DA             13252 	set	3,d			;CB DA
   203F CB DB             13253 	set	3,e			;CB DB
   2041 CB DC             13254 	set	3,h			;CB DC
   2043 CB DD             13255 	set	3,l			;CB DD
   2045 CB E6             13256 	set	4,(hl)			;CB E6
   2047 DD CB 55 E6       13276 	set	4,offset(ix)		;DD CB 55 E6
   204B FD CB 55 E6       13277 	set	4,offset(iy)		;FD CB 55 E6
   204F DD CB 55 E6       13278 	set	4,(ix+offset)		;DD CB 55 E6
   2053 FD CB 55 E6       13279 	set	4,(iy+offset)		;FD CB 55 E6
   2057 CB E7             13283 	set	4,a			;CB E7
   2059 CB E0             13284 	set	4,b			;CB E0
   205B CB E1             13285 	set	4,c			;CB E1
   205D CB E2             13286 	set	4,d			;CB E2
   205F CB E3             13287 	set	4,e			;CB E3
   2061 CB E4             13288 	set	4,h			;CB E4
   2063 CB E5             13289 	set	4,l			;CB E5
   2065 CB EE             13290 	set	5,(hl)			;CB EE
   2067 DD CB 55 EE       13310 	set	5,offset(ix)		;DD CB 55 EE
   206B FD CB 55 EE       13311 	set	5,offset(iy)		;FD CB 55 EE
   206F DD CB 55 EE       13312 	set	5,(ix+offset)		;DD CB 55 EE
   2073 FD CB 55 EE       13313 	set	5,(iy+offset)		;FD CB 55 EE
   2077 CB EF             13317 	set	5,a			;CB EF
   2079 CB E8             13318 	set	5,b			;CB E8
   207B CB E9             13319 	set	5,c			;CB E9
   207D CB EA             13320 	set	5,d			;CB EA
   207F CB EB             13321 	set	5,e			;CB EB
   2081 CB EC             13322 	set	5,h			;CB EC
   2083 CB ED             13323 	set	5,l			;CB ED
   2085 CB F6             13324 	set	6,(hl)			;CB F6
   2087 DD CB 55 F6       13344 	set	6,offset(ix)		;DD CB 55 F6
   208B FD CB 55 F6       13345 	set	6,offset(iy)		;FD CB 55 F6
   208F DD CB 55 F6       13346 	set	6,(ix+offset)		;DD CB 55 F6
   2093 FD CB 55 F6       13347 	set	6,(iy+offset)		;FD CB 55 F6
   2097 CB F7             13351 	set	6,a			;CB F7
   2099 CB F0             13352 	set	6,b			;CB F0
   209B CB F1             13353 	set	6,c			;CB F1
   209D CB F2             13354 	set	6,d			;CB F2
   209F CB F3             13355 	set	6,e			;CB F3
   20A1 CB F4             13356 	set	6,h			;CB F4
   20A3 CB F5             13357 	set	6,l			;CB F5
   20A5 CB FE             13358 	set	7,(hl)			;CB FE
   20A7 DD CB 55 FE       13378 	set	7,offset(ix)		;DD CB 55 FE
   20AB FD CB 55 FE       13379 	set	7,offset(iy)		;FD CB 55 FE
   20AF DD CB 55 FE       13380 	set	7,(ix+offset)		;DD CB 55 FE
   20B3 FD CB 55 FE       13381 	set	7,(iy+offset)		;FD CB 55 FE
   20B7 CB FF             13385 	set	7,a			;CB FF
   20B9 CB F8             13386 	set	7,b			;CB F8
   20BB CB F9             13387 	set	7,c			;CB F9
   20BD CB FA             13388 	set	7,d			;CB FA
   20BF CB FB             13389 	set	7,e			;CB FB
   20C1 CB FC             13390 	set	7,h			;CB FC
   20C3 CB FD             13391 	set	7,l			;CB FD
                          13392 
                          13393 ;*******************************************************************
                          13394 ;	SLA	
                          13395 ;*******************************************************************
                          13440 	;***********************************************************
                          13441 	; shift operand left arithmetic
                          13442 	.z80
   20C5 CB 26             13443 	sla	(hl)			;CB 26
   20C7 DD CB 55 26       13463 	sla	offset(ix)		;DD CB 55 26
   20CB FD CB 55 26       13464 	sla	offset(iy)		;FD CB 55 26
   20CF DD CB 55 26       13465 	sla	(ix+offset)		;DD CB 55 26
   20D3 FD CB 55 26       13466 	sla	(iy+offset)		;FD CB 55 26
   20D7 CB 27             13470 	sla	a			;CB 27
   20D9 CB 20             13471 	sla	b			;CB 20
   20DB CB 21             13472 	sla	c			;CB 21
   20DD CB 22             13473 	sla	d			;CB 22
   20DF CB 23             13474 	sla	e			;CB 23
   20E1 CB 24             13475 	sla	h			;CB 24
   20E3 CB 25             13476 	sla	l			;CB 25
                          13477 
                          13478 ;*******************************************************************
                          13479 ;	SRA	
                          13480 ;*******************************************************************
                          13525 	;***********************************************************
                          13526 	; shift operand right arithmetic
                          13527 	.z80
   20E5 CB 2E             13528 	sra	(hl)			;CB 2E
   20E7 DD CB 55 2E       13548 	sra	offset(ix)		;DD CB 55 2E
   20EB FD CB 55 2E       13549 	sra	offset(iy)		;FD CB 55 2E
   20EF DD CB 55 2E       13550 	sra	(ix+offset)		;DD CB 55 2E
   20F3 FD CB 55 2E       13551 	sra	(iy+offset)		;FD CB 55 2E
   20F7 CB 2F             13555 	sra	a			;CB 2F
   20F9 CB 28             13556 	sra	b			;CB 28
   20FB CB 29             13557 	sra	c			;CB 29
   20FD CB 2A             13558 	sra	d			;CB 2A
   20FF CB 2B             13559 	sra	e			;CB 2B
   2101 CB 2C             13560 	sra	h			;CB 2C
   2103 CB 2D             13561 	sra	l			;CB 2D
                          13562 
                          13563 ;*******************************************************************
                          13564 ;	SRL	
                          13565 ;*******************************************************************
                          13610 	;***********************************************************
                          13611 	; shift operand right logical
                          13612 	.z80
   2105 CB 3E             13613 	srl	(hl)			;CB 3E
   2107 DD CB 55 3E       13633 	srl	offset(ix)		;DD CB 55 3E
   210B FD CB 55 3E       13634 	srl	offset(iy)		;FD CB 55 3E
   210F DD CB 55 3E       13635 	srl	(ix+offset)		;DD CB 55 3E
   2113 FD CB 55 3E       13636 	srl	(iy+offset)		;FD CB 55 3E
   2117 CB 3F             13640 	srl	a			;CB 3F
   2119 CB 38             13641 	srl	b			;CB 38
   211B CB 39             13642 	srl	c			;CB 39
   211D CB 3A             13643 	srl	d			;CB 3A
   211F CB 3B             13644 	srl	e			;CB 3B
   2121 CB 3C             13645 	srl	h			;CB 3C
   2123 CB 3D             13646 	srl	l			;CB 3D
                          13647 
                          13648 ;*******************************************************************
                          13649 ;	SUB	
                          13650 ;		Leading 'a' operand is optional.
                          13651 ;		If offset is ommitted 0 is assumed.
                          13652 ;*******************************************************************
                          13653 	;***********************************************************
                          13654 	; subtract operand from 'a'
                          13655 	.z80
   2125 96                13656 	sub	a,(hl)			;96
   2126 DD 96 55          13676 	sub	a,offset(ix)		;DD 96 55
   2129 FD 96 55          13677 	sub	a,offset(iy)		;FD 96 55
   212C DD 96 55          13678 	sub	a,(ix+offset)		;DD 96 55
   212F FD 96 55          13679 	sub	a,(iy+offset)		;FD 96 55
   2132 97                13683 	sub	a,a			;97
   2133 90                13684 	sub	a,b			;90
   2134 91                13685 	sub	a,c			;91
   2135 92                13686 	sub	a,d			;92
   2136 93                13687 	sub	a,e			;93
   2137 94                13688 	sub	a,h			;94
   2138 95                13689 	sub	a,l			;95
   2139 D6 20             13705 	sub	a,#n			;D6 20
   213B D6 20             13706 	sub	a, n			;D6 20
                          13710 	;***********************************************************
                          13711 	; subtract operand from 'a'
                          13712 	.z80
   213D 96                13713 	sub	(hl)			;96
   213E DD 96 55          13733 	sub	offset(ix)		;DD 96 55
   2141 FD 96 55          13734 	sub	offset(iy)		;FD 96 55
   2144 DD 96 55          13735 	sub	(ix+offset)		;DD 96 55
   2147 FD 96 55          13736 	sub	(iy+offset)		;FD 96 55
   214A 97                13740 	sub	a			;97
   214B 90                13741 	sub	b			;90
   214C 91                13742 	sub	c			;91
   214D 92                13743 	sub	d			;92
   214E 93                13744 	sub	e			;93
   214F 94                13745 	sub	h			;94
   2150 95                13746 	sub	l			;95
   2151 D6 20             13762 	sub	#n			;D6 20
   2153 D6 20             13763 	sub	 n			;D6 20
                          13767 	;***********************************************************
                          13768 	;  p. 5-139
                          13769 	.z280
   2155 DD 94             13770 	sub	a,ixh			;DD 94
   2157 DD 95             13771 	sub	a,ixl			;DD 95
   2159 FD 94             13772 	sub	a,iyh			;FD 94
   215B FD 95             13773 	sub	a,iyl			;FD 95
   215D D6 20             13821 	sub	a,#n			;D6 20
   215F DD 97 44 33       13822 	sub	a,(daddr)		;DD 97 44 33
   2163 DD 96 55          13833 	sub	a,sxoff(ix)		;DD 96 55
   2166 DD 96 55          13834 	sub	a,(ix+sxoff)		;DD 96 55
   2169 FD 96 55          13835 	sub	a,sxoff(iy)		;FD 96 55
   216C FD 96 55          13836 	sub	a,(iy+sxoff)		;FD 96 55
   216F FD 93 55 00       13840 	sub	a,sxoff(hl)		;FD 93 55 00
   2173 FD 93 55 00       13841 	sub	a,(hl+sxoff)		;FD 93 55 00
   2177 DD 90 55 00       13842 	sub	a,sxoff(sp)		;DD 90 55 00
   217B DD 90 55 00       13843 	sub	a,(sp+sxoff)		;DD 90 55 00
   217F FD 91 22 11       13844 	sub	a,lxoff(ix)		;FD 91 22 11
   2183 FD 91 22 11       13845 	sub	a,(ix+lxoff)		;FD 91 22 11
   2187 FD 92 22 11       13846 	sub	a,lxoff(iy)		;FD 92 22 11
   218B FD 92 22 11       13847 	sub	a,(iy+lxoff)		;FD 92 22 11
   218F FD 93 22 11       13848 	sub	a,lxoff(hl)		;FD 93 22 11
   2193 FD 93 22 11       13849 	sub	a,(hl+lxoff)		;FD 93 22 11
   2197 DD 90 22 11       13850 	sub	a,lxoff(sp)		;DD 90 22 11
   219B DD 90 22 11       13851 	sub	a,(sp+lxoff)		;DD 90 22 11
   219F 96                13855 	sub	a,(hl)			;96
   21A0 DD 96 00          13856 	sub	a,(ix)			;DD 96 00
   21A3 FD 96 00          13857 	sub	a,(iy)			;FD 96 00
   21A6 DD 90 00 00       13858 	sub	a,(sp)			;DD 90 00 00
   21AA FD 90 34 12       13930 	sub	a,pcr_ofst(pc)		;FD 90 34 12
   21AE FD 90 34 12       13934 	sub	a,(pc+pcr_ofst)		;FD 90 34 12
   21B2 FD 90 34 12       13938 	sub	a,[pcr_ofst]		;FD 90 34 12
   21B6 FD 90 80 05       13942 	sub	a,[.+nnc]		;FD 90 80 05
   21BA DD 91             13943 	sub	a,(hl+ix)		;DD 91
   21BC DD 92             13944 	sub	a,(hl+iy)		;DD 92
   21BE DD 93             13945 	sub	a,(ix+iy)		;DD 93
                          13946 	;***********************************************************
                          13947 	;  p. 5-139
                          13948 	.z280
   21C0 DD 94             13949 	sub	ixh			;DD 94
   21C2 DD 95             13950 	sub	ixl			;DD 95
   21C4 FD 94             13951 	sub	iyh			;FD 94
   21C6 FD 95             13952 	sub	iyl			;FD 95
   21C8 D6 20             14000 	sub	#n			;D6 20
   21CA DD 97 44 33       14001 	sub	(daddr)			;DD 97 44 33
   21CE DD 96 55          14012 	sub	sxoff(ix)		;DD 96 55
   21D1 DD 96 55          14013 	sub	(ix+sxoff)		;DD 96 55
   21D4 FD 96 55          14014 	sub	sxoff(iy)		;FD 96 55
   21D7 FD 96 55          14015 	sub	(iy+sxoff)		;FD 96 55
   21DA FD 93 55 00       14019 	sub	sxoff(hl)		;FD 93 55 00
   21DE FD 93 55 00       14020 	sub	(hl+sxoff)		;FD 93 55 00
   21E2 DD 90 55 00       14021 	sub	sxoff(sp)		;DD 90 55 00
   21E6 DD 90 55 00       14022 	sub	(sp+sxoff)		;DD 90 55 00
   21EA FD 91 22 11       14023 	sub	lxoff(ix)		;FD 91 22 11
   21EE FD 91 22 11       14024 	sub	(ix+lxoff)		;FD 91 22 11
   21F2 FD 92 22 11       14025 	sub	lxoff(iy)		;FD 92 22 11
   21F6 FD 92 22 11       14026 	sub	(iy+lxoff)		;FD 92 22 11
   21FA FD 93 22 11       14027 	sub	lxoff(hl)		;FD 93 22 11
   21FE FD 93 22 11       14028 	sub	(hl+lxoff)		;FD 93 22 11
   2202 DD 90 22 11       14029 	sub	lxoff(sp)		;DD 90 22 11
   2206 DD 90 22 11       14030 	sub	(sp+lxoff)		;DD 90 22 11
   220A DD 96 00          14034 	sub	(ix)			;DD 96 00
   220D FD 96 00          14035 	sub	(iy)			;FD 96 00
   2210 96                14036 	sub	(hl)			;96
   2211 DD 90 00 00       14037 	sub	(sp)			;DD 90 00 00
   2215 FD 90 34 12       14109 	sub	pcr_ofst(pc)		;FD 90 34 12
   2219 FD 90 34 12       14113 	sub	(pc+pcr_ofst)		;FD 90 34 12
   221D FD 90 34 12       14117 	sub	[pcr_ofst]		;FD 90 34 12
   2221 FD 90 80 05       14121 	sub	[.+nnc]			;FD 90 80 05
   2225 DD 91             14122 	sub	a,(hl+ix)		;DD 91
   2227 DD 92             14123 	sub	a,(hl+iy)		;DD 92
   2229 DD 93             14124 	sub	a,(ix+iy)		;DD 93
                          14125 	;***********************************************************
                          14126 	;  p. 5-140
                          14127 	.z280
   222B DD ED CE          14128 	sub	hl,(hl)			;DD ED CE
   222E FD ED CE 00 00    14129 	sub	hl,(ix)			;FD ED CE 00 00
   2233 FD ED DE 00 00    14130 	sub	hl,(iy)			;FD ED DE 00 00
   2238 FD ED FE 84 05    14162 	sub	hl,#nn			;FD ED FE 84 05
   223D DD ED DE 44 33    14163 	sub	hl,(daddr)		;DD ED DE 44 33
   2242 FD ED CE 55 00    14164 	sub	hl,sxoff(ix)		;FD ED CE 55 00
   2247 FD ED CE 55 00    14165 	sub	hl,(ix+sxoff)		;FD ED CE 55 00
   224C FD ED CE 22 11    14166 	sub	hl,lxoff(ix)		;FD ED CE 22 11
   2251 FD ED CE 22 11    14167 	sub	hl,(ix+lxoff)		;FD ED CE 22 11
   2256 FD ED DE 55 00    14168 	sub	hl,sxoff(iy)		;FD ED DE 55 00
   225B FD ED DE 55 00    14169 	sub	hl,(iy+sxoff)		;FD ED DE 55 00
   2260 FD ED DE 22 11    14170 	sub	hl,lxoff(iy)		;FD ED DE 22 11
   2265 FD ED DE 22 11    14171 	sub	hl,(iy+lxoff)		;FD ED DE 22 11
   226A DD ED FE 34 12    14246 	sub	hl,pcr_ofst(pc)		;DD ED FE 34 12
   226F DD ED FE 34 12    14250 	sub	hl,(pc+pcr_ofst)	;DD ED FE 34 12
   2274 DD ED FE 34 12    14254 	sub	hl,[pcr_ofst]		;DD ED FE 34 12
   2279 DD ED FE 1B 00    14258 	sub	hl,[.+nc]		;DD ED FE 1B 00
   227E ED CE             14259 	sub	hl,bc			;ED CE
   2280 ED DE             14260 	sub	hl,de			;ED DE
   2282 ED EE             14261 	sub	hl,hl			;ED EE
   2284 DD ED EE          14262 	sub	hl,ix			;DD ED EE
   2287 FD ED EE          14263 	sub	hl,iy			;FD ED EE
   228A ED FE             14264 	sub	hl,sp			;ED FE
                          14265 ;*******************************************************************
                          14266 ;	SUBW	
                          14267 ;*******************************************************************
                          14268 	;***********************************************************
                          14269 	; subtract operand from 'hl'
                          14270 	.z280
   228C ED CE             14271 	subw	hl,bc			;ED CE
   228E ED DE             14272 	subw	hl,de			;ED DE
   2290 ED EE             14273 	subw	hl,hl			;ED EE
   2292 DD ED EE          14274 	subw	hl,ix			;DD ED EE
   2295 FD ED EE          14275 	subw	hl,iy			;FD ED EE
   2298 ED FE             14276 	subw	hl,sp			;ED FE
   229A FD ED FE 84 05    14308 	subw	hl,#nn			;FD ED FE 84 05
   229F DD ED DE 44 33    14309 	subw	hl,(daddr)		;DD ED DE 44 33
   22A4 FD ED CE 55 00    14310 	subw	hl,sxoff(ix)		;FD ED CE 55 00
   22A9 FD ED CE 55 00    14311 	subw	hl,(ix+sxoff)		;FD ED CE 55 00
   22AE FD ED DE 55 00    14312 	subw	hl,sxoff(iy)		;FD ED DE 55 00
   22B3 FD ED DE 55 00    14313 	subw	hl,(iy+sxoff)		;FD ED DE 55 00
   22B8 FD ED CE 22 11    14314 	subw	hl,lxoff(ix)		;FD ED CE 22 11
   22BD FD ED CE 22 11    14315 	subw	hl,(ix+lxoff)		;FD ED CE 22 11
   22C2 FD ED DE 22 11    14316 	subw	hl,lxoff(iy)		;FD ED DE 22 11
   22C7 FD ED DE 22 11    14317 	subw	hl,(iy+lxoff)		;FD ED DE 22 11
   22CC DD ED CE          14321 	subw	hl,(hl)			;DD ED CE
   22CF FD ED CE 00 00    14322 	subw	hl,(ix)			;FD ED CE 00 00
   22D4 FD ED DE 00 00    14323 	subw	hl,(iy)			;FD ED DE 00 00
   22D9 DD ED FE 34 12    14395 	subw	hl,pcr_ofst(pc)		;DD ED FE 34 12
   22DE DD ED FE 34 12    14399 	subw	hl,(pc+pcr_ofst)	;DD ED FE 34 12
   22E3 DD ED FE 34 12    14403 	subw	hl,[pcr_ofst]		;DD ED FE 34 12
   22E8 DD ED FE 1B 00    14407 	subw	hl,[.+nc]		;DD ED FE 1B 00
                          14408 
                          14409 ;*******************************************************************
                          14410 ;	TSET	
                          14411 ;*******************************************************************
                          14412 	;***********************************************************
                          14413 	; Z280 test and set
                          14414 	;  p. 5-141
                          14415 	.z280
   22ED CB 30             14416 	tset	b			;CB 30
   22EF CB 31             14417 	tset	c			;CB 31
   22F1 CB 32             14418 	tset	d			;CB 32
   22F3 CB 33             14419 	tset	e			;CB 33
   22F5 CB 34             14420 	tset	h			;CB 34
   22F7 CB 35             14421 	tset	l			;CB 35
   22F9 CB 36             14422 	tset	(hl)			;CB 36
   22FB CB 37             14423 	tset	a			;CB 37
   22FD DD CB 55 36       14443 	tset	sxoff(ix)		;DD CB 55 36
   2301 DD CB 55 36       14444 	tset	(ix+sxoff)		;DD CB 55 36
   2305 FD CB 55 36       14445 	tset	sxoff(iy)		;FD CB 55 36
   2309 FD CB 55 36       14446 	tset	(iy+sxoff)		;FD CB 55 36
                          14450 
                          14451 ;*******************************************************************
                          14452 ;	TSTI	
                          14453 ;*******************************************************************
                          14454 	;***********************************************************
                          14455 	; Z280 test input
                          14456 	.z280
   230D ED 70             14457 	tsti	(c)			;ED 70
                          14458 
                          14459 ;*******************************************************************
                          14460 ;	XOR	
                          14461 ;		Leading 'a' operand is optional.
                          14462 ;		If offset is ommitted 0 is assumed.
                          14463 ;*******************************************************************
                          14464 	;***********************************************************
                          14465 	; logical 'xor' operand with 'a'
                          14466 	.z80
   230F AE                14467 	xor	a,(hl)			;AE
   2310 DD AE 55          14487 	xor	a,offset(ix)		;DD AE 55
   2313 FD AE 55          14488 	xor	a,offset(iy)		;FD AE 55
   2316 DD AE 55          14489 	xor	a,(ix+offset)		;DD AE 55
   2319 FD AE 55          14490 	xor	a,(iy+offset)		;FD AE 55
   231C AF                14494 	xor	a,a			;AF
   231D A8                14495 	xor	a,b			;A8
   231E A9                14496 	xor	a,c			;A9
   231F AA                14497 	xor	a,d			;AA
   2320 AB                14498 	xor	a,e			;AB
   2321 AC                14499 	xor	a,h			;AC
   2322 AD                14500 	xor	a,l			;AD
   2323 EE 20             14516 	xor	a,#n			;EE 20
   2325 EE 20             14517 	xor	a, n			;EE 20
                          14521 	;***********************************************************
                          14522 	; logical 'xor' operand without 'a'
                          14523 	.z80
   2327 AE                14524 	xor	(hl)			;AE
   2328 DD AE 55          14544 	xor	offset(ix)		;DD AE 55
   232B FD AE 55          14545 	xor	offset(iy)		;FD AE 55
   232E DD AE 55          14546 	xor	(ix+offset)		;DD AE 55
   2331 FD AE 55          14547 	xor	(iy+offset)		;FD AE 55
   2334 AF                14551 	xor	a			;AF
   2335 A8                14552 	xor	b			;A8
   2336 A9                14553 	xor	c			;A9
   2337 AA                14554 	xor	d			;AA
   2338 AB                14555 	xor	e			;AB
   2339 AC                14556 	xor	h			;AC
   233A AD                14557 	xor	l			;AD
   233B EE 20             14573 	xor	#n			;EE 20
   233D EE 20             14574 	xor	 n			;EE 20
                          14578 	;***********************************************************
                          14579 	;  p. 5-143
                          14580 	.z280
   233F DD AC             14581 	xor	a,ixh			;DD AC
   2341 DD AD             14582 	xor	a,ixl			;DD AD
   2343 FD AC             14583 	xor	a,iyh			;FD AC
   2345 FD AD             14584 	xor	a,iyl			;FD AD
   2347 EE 20             14632 	xor	a,#n			;EE 20
   2349 DD AF 44 33       14633 	xor	a,(daddr)		;DD AF 44 33
   234D DD AE 55          14644 	xor	a,sxoff(ix)		;DD AE 55
   2350 DD AE 55          14645 	xor	a,(ix+sxoff)		;DD AE 55
   2353 FD AE 55          14646 	xor	a,sxoff(iy)		;FD AE 55
   2356 FD AE 55          14647 	xor	a,(iy+sxoff)		;FD AE 55
   2359 FD AB 55 00       14651 	xor	a,sxoff(hl)		;FD AB 55 00
   235D FD AB 55 00       14652 	xor	a,(hl+sxoff)		;FD AB 55 00
   2361 DD A8 55 00       14653 	xor	a,sxoff(sp)		;DD A8 55 00
   2365 DD A8 55 00       14654 	xor	a,(sp+sxoff)		;DD A8 55 00
   2369 FD A9 22 11       14655 	xor	a,lxoff(ix)		;FD A9 22 11
   236D FD A9 22 11       14656 	xor	a,(ix+lxoff)		;FD A9 22 11
   2371 FD AA 22 11       14657 	xor	a,lxoff(iy)		;FD AA 22 11
   2375 FD AA 22 11       14658 	xor	a,(iy+lxoff)		;FD AA 22 11
   2379 FD AB 22 11       14659 	xor	a,lxoff(hl)		;FD AB 22 11
   237D FD AB 22 11       14660 	xor	a,(hl+lxoff)		;FD AB 22 11
   2381 DD A8 22 11       14661 	xor	a,lxoff(sp)		;DD A8 22 11
   2385 DD A8 22 11       14662 	xor	a,(sp+lxoff)		;DD A8 22 11
   2389 AE                14666 	xor	a,(hl)			;AE
   238A DD AE 00          14667 	xor	a,(ix)			;DD AE 00
   238D FD AE 00          14668 	xor	a,(iy)			;FD AE 00
   2390 DD A8 00 00       14669 	xor	a,(sp)			;DD A8 00 00
   2394 FD A8 34 12       14741 	xor	a,pcr_ofst(pc)		;FD A8 34 12
   2398 FD A8 34 12       14745 	xor	a,(pc+pcr_ofst)		;FD A8 34 12
   239C FD A8 34 12       14749 	xor	a,[pcr_ofst]		;FD A8 34 12
   23A0 FD A8 1C 00       14753 	xor	a,[.+nc]		;FD A8 1C 00
   23A4 DD A9             14754 	xor	a,(hl+ix)		;DD A9
   23A6 DD AA             14755 	xor	a,(hl+iy)		;DD AA
   23A8 DD AB             14756 	xor	a,(ix+iy)		;DD AB
                          14757 	;***********************************************************
                          14758 	;  p. 5-143
                          14759 	.z280
   23AA DD AC             14760 	xor	ixh			;DD AC
   23AC DD AD             14761 	xor	ixl			;DD AD
   23AE FD AC             14762 	xor	iyh			;FD AC
   23B0 FD AD             14763 	xor	iyl			;FD AD
   23B2 EE 20             14811 	xor	#n			;EE 20
   23B4 DD AF 44 33       14812 	xor	(daddr)			;DD AF 44 33
   23B8 DD AE 55          14823 	xor	sxoff(ix)		;DD AE 55
   23BB DD AE 55          14824 	xor	(ix+sxoff)		;DD AE 55
   23BE FD AE 55          14825 	xor	sxoff(iy)		;FD AE 55
   23C1 FD AE 55          14826 	xor	(iy+sxoff)		;FD AE 55
   23C4 FD AB 55 00       14830 	xor	sxoff(hl)		;FD AB 55 00
   23C8 FD AB 55 00       14831 	xor	(hl+sxoff)		;FD AB 55 00
   23CC DD A8 55 00       14832 	xor	sxoff(sp)		;DD A8 55 00
   23D0 DD A8 55 00       14833 	xor	(sp+sxoff)		;DD A8 55 00
   23D4 FD A9 22 11       14834 	xor	lxoff(ix)		;FD A9 22 11
   23D8 FD A9 22 11       14835 	xor	(ix+lxoff)		;FD A9 22 11
   23DC FD AA 22 11       14836 	xor	lxoff(iy)		;FD AA 22 11
   23E0 FD AA 22 11       14837 	xor	(iy+lxoff)		;FD AA 22 11
   23E4 FD AB 22 11       14838 	xor	lxoff(hl)		;FD AB 22 11
   23E8 FD AB 22 11       14839 	xor	(hl+lxoff)		;FD AB 22 11
   23EC DD A8 22 11       14840 	xor	lxoff(sp)		;DD A8 22 11
   23F0 DD A8 22 11       14841 	xor	(sp+lxoff)		;DD A8 22 11
   23F4 AE                14845 	xor	(hl)			;AE
   23F5 DD AE 00          14846 	xor	(ix)			;DD AE 00
   23F8 FD AE 00          14847 	xor	(iy)			;FD AE 00
   23FB DD A8 00 00       14848 	xor	(sp)			;DD A8 00 00
   23FF FD A8 34 12       14920 	xor	pcr_ofst(pc)		;FD A8 34 12
   2403 FD A8 34 12       14924 	xor	(pc+pcr_ofst)		;FD A8 34 12
   2407 FD A8 34 12       14928 	xor	[pcr_ofst]		;FD A8 34 12
   240B FD A8 1C 00       14932 	xor	[.+nc]			;FD A8 1C 00
   240F DD A9             14933 	xor	(hl+ix)			;DD A9
   2411 DD AA             14934 	xor	(hl+iy)			;DD AA
   2413 DD AB             14935 	xor	(ix+iy)			;DD AB
                          14936 
                          14937 	;***********************************************************
                          14938 	; Hitachi HD64180 Codes
                          14939 	;***********************************************************
                          14940 
                          14941 	.hd64
                          14942 
                          14943 	;***********************************************************
                          14944 	; start of the Z180 section
                          14945 	;***********************************************************
                          14946 	
                          14947 
                          14948 ;*******************************************************************
                          14949 ;	IN0	
                          14950 ;*******************************************************************
                          14951 	;***********************************************************
                          14952 	; load register with input from port (n)
   2415 ED 38 20          14978 	in0	a,(n)			;ED 38 20
   2418 ED 00 20          14979 	in0	b,(n)			;ED 00 20
   241B ED 08 20          14980 	in0	c,(n)			;ED 08 20
   241E ED 10 20          14981 	in0	d,(n)			;ED 10 20
   2421 ED 18 20          14982 	in0	e,(n)			;ED 18 20
   2424 ED 20 20          14983 	in0	h,(n)			;ED 20 20
   2427 ED 28 20          14984 	in0	l,(n)			;ED 28 20
                          14988 
                          14989 ;*******************************************************************
                          14990 ;	mlt	
                          14991 ;*******************************************************************
                          14992 	;***********************************************************
                          14993 	; multiplication of each half
                          14994 	; of the specified register pair
                          14995 	; with the 16-bit result going to
                          14996 	; the specified register pair
   242A ED 4C             14997 	mlt	bc			;ED 4C
   242C ED 5C             14998 	mlt	de			;ED 5C
   242E ED 6C             14999 	mlt	hl			;ED 6C
   2430 ED 7C             15000 	mlt	sp			;ED 7C
                          15001 
                          15002 ;*******************************************************************
                          15003 ;	OTDM	
                          15004 ;*******************************************************************
                          15005 	;***********************************************************
                          15006 	; load output port (c) with
                          15007 	; location (hl),
                          15008 	; decrement hl and b
                          15009 	; decrement c
   2432 ED 8B             15010 	otdm				;ED 8B
                          15011 
                          15012 ;*******************************************************************
                          15013 ;	OTDMR	
                          15014 ;*******************************************************************
                          15015 	;***********************************************************
                          15016 	; load output port (c) with
                          15017 	; location (hl),
                          15018 	; decrement hl and c
                          15019 	; decrement b
                          15020 	; repeat until b = 0
   2434 ED 9B             15021 	otdmr				;ED 9B
                          15022 
                          15023 ;*******************************************************************
                          15024 ;	OTIM	
                          15025 ;*******************************************************************
                          15026 	;***********************************************************
                          15027 	; load output port (c) with
                          15028 	; location (hl),
                          15029 	; increment hl and b
                          15030 	; decrement c
   2436 ED 83             15031 	otim				;ED 83
                          15032 
                          15033 ;*******************************************************************
                          15034 ;	OTIMR	
                          15035 ;*******************************************************************
                          15036 	;***********************************************************
                          15037 	; load output port (c) with
                          15038 	; location (hl),
                          15039 	; increment hl and c
                          15040 	; decrement b
                          15041 	; repeat until b = 0
   2438 ED 93             15042 	otimr				;ED 93
                          15043 
                          15044 ;*******************************************************************
                          15045 ;	OUT0	
                          15046 ;*******************************************************************
                          15047 	;***********************************************************
                          15048 	; load output port (n) from register
   243A ED 39 20          15074 	out0	(n),a			;ED 39 20
   243D ED 01 20          15075 	out0	(n),b			;ED 01 20
   2440 ED 09 20          15076 	out0	(n),c			;ED 09 20
   2443 ED 11 20          15077 	out0	(n),d			;ED 11 20
   2446 ED 19 20          15078 	out0	(n),e			;ED 19 20
   2449 ED 21 20          15079 	out0	(n),h			;ED 21 20
   244C ED 29 20          15080 	out0	(n),l			;ED 29 20
                          15084 
                          15085 ;*******************************************************************
                          15086 ;	SLP	
                          15087 ;*******************************************************************
                          15088 	;***********************************************************
                          15089 	; enter sleep mode
   244F ED 76             15090 	slp				;ED 76
                          15091 
                          15092 ;*******************************************************************
                          15093 ;	TST	
                          15094 ;*******************************************************************
                          15095 	;***********************************************************
                          15096 	; non-destructive'and' with accumulator and specified operand
   2451 ED 3C             15097 	tst	a,a			;ED 3C
   2453 ED 04             15098 	tst	a,b			;ED 04
   2455 ED 0C             15099 	tst	a,c			;ED 0C
   2457 ED 14             15100 	tst	a,d			;ED 14
   2459 ED 1C             15101 	tst	a,e			;ED 1C
   245B ED 24             15102 	tst	a,h			;ED 24
   245D ED 2C             15103 	tst	a,l			;ED 2C
   245F ED 64 20          15119 	tst	a,#n			;ED 64 20
   2462 ED 64 20          15120 	tst	a, n			;ED 64 20
   2465 ED 34             15124 	tst	a,(hl)			;ED 34
                          15125 	;***********************************************************
   2467 ED 3C             15126 	tst	a			;ED 3C
   2469 ED 04             15127 	tst	b			;ED 04
   246B ED 0C             15128 	tst	c			;ED 0C
   246D ED 14             15129 	tst	d			;ED 14
   246F ED 1C             15130 	tst	e			;ED 1C
   2471 ED 24             15131 	tst	h			;ED 24
   2473 ED 2C             15132 	tst	l			;ED 2C
   2475 ED 64 20          15148 	tst	#n			;ED 64 20
   2478 ED 64 20          15149 	tst	 n			;ED 64 20
   247B ED 34             15153 	tst	(hl)			;ED 34
                          15154 
                          15155 ;*******************************************************************
                          15156 ;	TSTIO	
                          15157 ;*******************************************************************
                          15158 	;***********************************************************
                          15159 	; non-destructive 'and' of n and the contents of port (c)
   247D ED 74 20          15179 	tstio	#n,(c)			;ED 74 20
   2480 ED 74 20          15180 	tstio	(c),#n			;ED 74 20
   2483 ED 74 20          15181 	tstio	#n			;ED 74 20
   2486 ED 74 20          15182 	tstio	 n			;ED 74 20
                          15186 	;***********************************************************
                          15187 	; end of the Z180 section
                          15188 	;***********************************************************
                          15189 	
                          15190 ;*******************************************************************
                          15191 ;	UNDOCUMENTED	
                          15192 ;*******************************************************************
                          15193 	;***********************************************************
                          15194 	; start of the Z80 undocumented section
                          15195 	;***********************************************************
                          15196 	.z80u
   2489 DD 8C             15197 	adc	a,ixh			;DD 8C
   248B DD 8D             15198 	adc	a,ixl			;DD 8D
   248D FD 8C             15199 	adc	a,iyh			;FD 8C
   248F FD 8D             15200 	adc	a,iyl			;FD 8D
   2491 DD 84             15201 	add	a,ixh			;DD 84
   2493 DD 85             15202 	add	a,ixl			;DD 85
   2495 FD 84             15203 	add	a,iyh			;FD 84
   2497 FD 85             15204 	add	a,iyl			;FD 85
   2499 DD A4             15205 	and	a,ixh			;DD A4
   249B DD A5             15206 	and	a,ixl			;DD A5
   249D FD A4             15207 	and	a,iyh			;FD A4
   249F FD A5             15208 	and	a,iyl			;FD A5
   24A1 DD BC             15209 	cp	a,ixh			;DD BC
   24A3 DD BD             15210 	cp	a,ixl			;DD BD
   24A5 FD BC             15211 	cp	a,iyh			;FD BC
   24A7 FD BD             15212 	cp	a,iyl			;FD BD
   24A9 DD B4             15213 	or	a,ixh			;DD B4
   24AB DD B5             15214 	or	a,ixl			;DD B5
   24AD FD B4             15215 	or	a,iyh			;FD B4
   24AF FD B5             15216 	or	a,iyl			;FD B5
   24B1 DD 9C             15217 	sbc	a,ixh			;DD 9C
   24B3 DD 9D             15218 	sbc	a,ixl			;DD 9D
   24B5 FD 9C             15219 	sbc	a,iyh			;FD 9C
   24B7 FD 9D             15220 	sbc	a,iyl			;FD 9D
   24B9 DD 94             15221 	sub	a,ixh			;DD 94
   24BB DD 95             15222 	sub	a,ixl			;DD 95
   24BD FD 94             15223 	sub	a,iyh			;FD 94
   24BF FD 95             15224 	sub	a,iyl			;FD 95
   24C1 DD AC             15225 	xor	a,ixh			;DD AC
   24C3 DD AD             15226 	xor	a,ixl			;DD AD
   24C5 FD AC             15227 	xor	a,iyh			;FD AC
   24C7 FD AD             15228 	xor	a,iyl			;FD AD
                          15229 					;
   24C9 DD 25             15230 	dec	ixh			;DD 25
   24CB DD 2D             15231 	dec	ixl			;DD 2D
   24CD FD 25             15232 	dec	iyh			;FD 25
   24CF FD 2D             15233 	dec	iyl			;FD 2D
   24D1 DD 24             15234 	inc	ixh			;DD 24
   24D3 DD 2C             15235 	inc	ixl			;DD 2C
   24D5 FD 24             15236 	inc	iyh			;FD 24
   24D7 FD 2C             15237 	inc 	iyl			;FD 2C
                          15238 					;
   24D9 DD ED 60          15239 	in	ixh,(c)			;DD ED 60
   24DC DD ED 68          15240 	in	ixl,(c)			;DD ED 68
   24DF FD ED 60          15241 	in	iyh,(c)			;FD ED 60
   24E2 FD ED 68          15242 	in	iyl,(c)			;FD ED 68
                          15243 					;
   24E5 DD 67             15244 	ld	ixh,a			;DD 67
   24E7 DD 6F             15245 	ld	ixl,a			;DD 6F
   24E9 FD 67             15246 	ld	iyh,a			;FD 67
   24EB FD 6F             15247 	ld	iyl,a			;FD 6F
   24ED DD 60             15248 	ld	ixh,b			;DD 60
   24EF DD 68             15249 	ld	ixl,b			;DD 68
   24F1 FD 60             15250 	ld	iyh,b			;FD 60
   24F3 FD 68             15251 	ld	iyl,b			;FD 68
   24F5 DD 61             15252 	ld	ixh,c			;DD 61
   24F7 DD 69             15253 	ld	ixl,c			;DD 69
   24F9 FD 61             15254 	ld	iyh,c			;FD 61
   24FB FD 69             15255 	ld	iyl,c			;FD 69
   24FD DD 62             15256 	ld	ixh,d			;DD 62
   24FF DD 6A             15257 	ld	ixl,d			;DD 6A
   2501 FD 62             15258 	ld	iyh,d			;FD 62
   2503 FD 6A             15259 	ld	iyl,d			;FD 6A
   2505 DD 63             15260 	ld	ixh,e			;DD 63
   2507 DD 6B             15261 	ld	ixl,e			;DD 6B
   2509 FD 63             15262 	ld	iyh,e			;FD 63
   250B FD 6B             15263 	ld	iyl,e			;FD 6B
                          15264 					;
   250D DD 7C             15265 	ld	a,ixh			;DD 7C
   250F DD 7D             15266 	ld	a,ixl			;DD 7D
   2511 FD 7C             15267 	ld	a,iyh			;FD 7C
   2513 FD 7D             15268 	ld	a,iyl			;FD 7D
   2515 DD 44             15269 	ld	b,ixh			;DD 44
   2517 DD 45             15270 	ld	b,ixl			;DD 45
   2519 FD 44             15271 	ld	b,iyh			;FD 44
   251B FD 45             15272 	ld	b,iyl			;FD 45
   251D DD 4C             15273 	ld	c,ixh			;DD 4C
   251F DD 4D             15274 	ld	c,ixl			;DD 4D
   2521 FD 4C             15275 	ld	c,iyh			;FD 4C
   2523 FD 4D             15276 	ld	c,iyl			;FD 4D
   2525 DD 54             15277 	ld	d,ixh			;DD 54
   2527 DD 55             15278 	ld	d,ixl			;DD 55
   2529 FD 54             15279 	ld	d,iyh			;FD 54
   252B FD 55             15280 	ld	d,iyl			;FD 55
   252D DD 5C             15281 	ld	e,ixh			;DD 5C
   252F DD 5D             15282 	ld	e,ixl			;DD 5D
   2531 FD 5C             15283 	ld	e,iyh			;FD 5C
   2533 FD 5D             15284 	ld	e,iyl			;FD 5D
                     0001 15285 .if 1
                          15286 					;
   2535 DD 64             15287 	ld	ixh,ixh			;DD 64
   2537 DD 65             15288 	ld	ixh,ixl			;DD 65
   2539 DD 6C             15289 	ld	ixl,ixh			;DD 6C
   253B DD 6D             15290 	ld	ixl,ixl			;DD 6D
   253D FD 64             15291 	ld	iyh,iyh			;FD 64
   253F FD 65             15292 	ld	iyh,iyl			;FD 65
   2541 FD 6C             15293 	ld	iyl,iyh			;FD 6C
   2543 FD 6D             15294 	ld	iyl,iyl			;FD 6D
                          15295 .endif
                          15296 					;
   2545 DD 26 20          15316 	ld	ixh,#n			;DD 26 20
   2548 DD 2E 20          15317 	ld	ixl,#n			;DD 2E 20
   254B FD 26 20          15318 	ld	iyh,#n			;FD 26 20
   254E FD 2E 20          15319 	ld	iyl,#n			;FD 2E 20
   2551 DD 26 20          15342 	ld	ixh,#n			;DD 26 20
   2554 DD 2E 23          15343 	ld	ixl,#n+3		;DD 2E 23
   2557 FD 26 1F          15344 	ld	iyh,#n-1		;FD 26 1F
   255A FD 2E 20          15345 	ld	iyl,#n			;FD 2E 20
                          15349 	;***********************************************************
                          15350 	; without 'a'
   255D DD 8C             15351 	adc	ixh			;DD 8C
   255F DD 8D             15352 	adc	ixl			;DD 8D
   2561 FD 8C             15353 	adc	iyh			;FD 8C
   2563 FD 8D             15354 	adc	iyl			;FD 8D
   2565 DD 84             15355 	add	ixh			;DD 84
   2567 DD 85             15356 	add	ixl			;DD 85
   2569 FD 84             15357 	add	iyh			;FD 84
   256B FD 85             15358 	add	iyl			;FD 85
   256D DD A4             15359 	and	ixh			;DD A4
   256F DD A5             15360 	and	ixl			;DD A5
   2571 FD A4             15361 	and	iyh			;FD A4
   2573 FD A5             15362 	and	iyl			;FD A5
   2575 DD BC             15363 	cp	ixh			;DD BC
   2577 DD BD             15364 	cp	ixl			;DD BD
   2579 FD BC             15365 	cp	iyh			;FD BC
   257B FD BD             15366 	cp	iyl			;FD BD
   257D DD B4             15367 	or	ixh			;DD B4
   257F DD B5             15368 	or	ixl			;DD B5
   2581 FD B4             15369 	or	iyh			;FD B4
   2583 FD B5             15370 	or	iyl			;FD B5
   2585 DD 9C             15371 	sbc	ixh			;DD 9C
   2587 DD 9D             15372 	sbc	ixl			;DD 9D
   2589 FD 9C             15373 	sbc	iyh			;FD 9C
   258B FD 9D             15374 	sbc	iyl			;FD 9D
   258D DD 94             15375 	sub	ixh			;DD 94
   258F DD 95             15376 	sub	ixl			;DD 95
   2591 FD 94             15377 	sub	iyh			;FD 94
   2593 FD 95             15378 	sub	iyl			;FD 95
   2595 DD AC             15379 	xor	ixh			;DD AC
   2597 DD AD             15380 	xor	ixl			;DD AD
   2599 FD AC             15381 	xor	iyh			;FD AC
   259B FD AD             15382 	xor	iyl			;FD AD
                          15383 	;***********************************************************
                          15384 	; c.f. 'tset' on Z280 (see above)
                          15385 	; shift left (like SLA), but shift a '1' into bit 0 !!!
   259D CB 36             15386 	sll	(hl)			;CB 36
   259F DD CB 55 36       15406 	sll	offset(ix)		;DD CB 55 36
   25A3 FD CB 55 36       15407 	sll	offset(iy)		;FD CB 55 36
   25A7 DD CB 55 36       15408 	sll	(ix+offset)		;DD CB 55 36
   25AB FD CB 55 36       15409 	sll	(iy+offset)		;FD CB 55 36
   25AF CB 37             15413 	sll	a			;CB 37
   25B1 CB 30             15414 	sll	b			;CB 30
   25B3 CB 31             15415 	sll	c			;CB 31
   25B5 CB 32             15416 	sll	d			;CB 32
   25B7 CB 33             15417 	sll	e			;CB 33
   25B9 CB 34             15418 	sll	h			;CB 34
   25BB CB 35             15419 	sll	l			;CB 35
                          15420 	;  sll a  ==  tset a	may be used to distinguish Z80 from Z280 with Areg = 0x41
                          15421 	;***********************************************************
                          15422 	; end of the Z80 undocumented section
                          15423 	;***********************************************************
                          15424 
                          15425 	.globl	z
   25BD 3E 12             15426 	ld	a,# >0x1234
   25BF 3E 34             15427 	ld	a,# <0x1234
   25C1 3E 13             15428 	ld	a,# >(z+0x1234)
   25C3 3E 35             15429 	ld	a,# <(z+0x1234)
                          15430 	
                          15431 
                          15432 	.end
                          15433 
ASxxxx Assembler V05.50  (2/14/17 Zilog Z80 / Z180 / HD64180 / Z280)    Page 1
Hexadecimal [16-Bits]                                 Sun Aug 27 19:25:33 2023
Test of Z280 assembler
Symbol Table

    .__.$$$.       =   2710 L   |     .__.ABS.       =   0000 G
    .__.CPU.       =   0087 L   |     .__.H$L.       =   0000 L
    CXLR           =   0009     |     CXL_           =   0002 
    CX_R           =   0000     |     C_LR           =   0000 
    C_L_           =   0001     |     C__R           =   0000 
    ODDBALL_SHIFT_ =   0000     |     _XLR           =   0004 
    _XL_           =   FFFD     |     _X_R           =   FFFC 
    _dot_          =   2407     |     daddc          =   3344 G
    daddr          =   3344     |   0 jmp1               0D79 R
  0 jr1                0DEF R   |   0 jr2                0DF1 R
  0 jr3                0DF3 R   |   0 jr4                0DF5 R
  0 ljr1               0DE5 R   |   0 ljr2               0DED R
    lxofc          =   1122 G   |     lxoff          =   1122 
    n              =   0020     |     nc             =   0020 G
    nn             =   0584     |     nnc            =   0584 G
    offset         =   0055     |     offsetc        =   0055 G
    pcr_ofst       =   363F     |     raofc          =   1234 G
    raoff          =   1234     |     sxofc          =   0055 G
    sxoff          =   0055     |     x                  **** GX
    z                  **** GX

ASxxxx Assembler V05.50  (2/14/17 Zilog Z80 / Z180 / HD64180 / Z280)    Page 2
Hexadecimal [16-Bits]                                 Sun Aug 27 19:25:33 2023
Test of Z280 assembler
Area Table

[_CSEG]
   0 _CODE            size 25C5   flags C180
[_DSEG]
   1 _DATA            size    0   flags C0C0

