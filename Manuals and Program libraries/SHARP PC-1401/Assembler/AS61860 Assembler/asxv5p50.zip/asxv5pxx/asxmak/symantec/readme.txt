The DOS executables created with the
Symantec Compiler are limited to 8.3
character file names.

make.bat and _makeall.bat use the
Symantec make utility SMAKE to rebuild
all the ASxxxx assemblers.

