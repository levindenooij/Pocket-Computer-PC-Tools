// Demo for include and defines
#org 33000

#include main.h

#define SPACE 32

main()
{
	return SPACE;	// makes no sense in main.c, but you see the symbol SPACE used here.
}
