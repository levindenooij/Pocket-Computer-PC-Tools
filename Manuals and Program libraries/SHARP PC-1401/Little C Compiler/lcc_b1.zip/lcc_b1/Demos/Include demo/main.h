// Demo for include and defines
#define ENTER 13
