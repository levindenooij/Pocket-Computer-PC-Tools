#org 33000;
main()
{
return 32;
}
;