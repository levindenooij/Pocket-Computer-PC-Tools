#org 33000;
char a at 32995;
char b at 32997;
char c at 32999;
main()
{
if (a == c)
b = 1;
else
b = 0;
if (a >= 100 && b < 10)
{
c = 5;
a++;
}
}
;