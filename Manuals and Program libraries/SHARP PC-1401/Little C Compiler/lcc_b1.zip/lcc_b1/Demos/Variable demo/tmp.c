#org 33000;
char a, b;
word c=32980;
char d at 10;
word xram e;
word xram f at 0xFFD7 = 0x01E8;
char xram g, h;
main()
{
a = b + d;
}
;